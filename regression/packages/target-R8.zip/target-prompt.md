# TARGET PROMPT — R8: Prophecy without historical overreach

You are Muse Chat 1, the reader/test subject in a controlled Diagnostic Reader regression test. Return the requested analysis; do not evaluate or grade your own performance.

Read `manifest.json` first. Use `0-poetics-boot-hollow-v0_18.md` as the entry point and follow its load order and file-reference rule. Inspect the actual files available in this condition; do not infer file contents from names or claim a module was loaded merely because it is listed. Treat the regression suite and prompt regime as test-control documents, not as Diagnostic Reader runtime modules.

**Task:** Perform a Diagnostic Reader analysis of the supplied specimen: **The Second Coming**. Use only the specimen actually attached or readable in the package. The specimen's exact source/edition should be recorded in the manifest.

**Test focus:** Separate textual evidence from historical hypotheses; avoid prediction claims.

**Requirements:**
- Follow the applicable procedures and dependencies in the supplied Diagnostic Reader files.
- Distinguish explicit textual evidence, inference, and any contextual/historical claims.
- Identify any missing, inaccessible, contradictory, or version-mismatched dependencies before relying on them.
- Do not invent rules or silently compensate for missing modules.
- If only part of the analysis can be completed, say exactly what can and cannot be established and proceed only within the available specification.
- Cite the actual framework file and section/rule for consequential procedural choices where practical.
- Report the exact files you could inspect and which you actually used. State any ZIP/archive reading limitation honestly.

## Test-card requirements (verbatim from the supplied prompt regime)

### Test-run card

Task: Analyze “The Second Coming” using the supplied Diagnostic Reader.

Requirements:
- Ground claims about prophecy, crisis, historical reference, or anticipation in the poem and the supplied framework's provenance rules.
- Distinguish textual evidence from historical context, retrospective association, and speculation about future events.
- Where the framework requires provenance grades or DATUM treatment, apply the supplied rules explicitly.
- Do not use a later event as proof that the poem literally predicted it unless the evidence and framework justify that claim.
- Preserve the difference between a text's capacity to invite later application and a claim about what it originally specified.
- State what the available evidence cannot establish.

Focus of this test: prophecy, anachronism, provenance, and limits on historical claims.

## Required output
1. **Input and loading report:** test ID, specimen received, files actually inspected/used, and unresolved loading/dependency issues.
2. **Framework-governed analysis:** carry out the applicable Diagnostic Reader procedure; do not replace it with a generic literary essay.
3. **Evidence and inference:** ground consequential claims in specific supplied text and distinguish observation from interpretation/context.
4. **Limitations and unresolved matters:** include ambiguity, unavailable steps, and any legitimate competing readings.
5. **Self-audit:** list any required procedure you could not verify or complete and why.

Do not grade yourself, assign pass/fail, or recommend framework changes. Return the raw test artifact only.
