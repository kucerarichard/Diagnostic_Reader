# VISE STYLE MODE

Version 0.3.1: output hygiene pass against `0c-voice-designations`. The mode takes the designation VISE, the two calibration contributions are renamed to their functions, and every operational term built from a calibration source's name is converted. No change to the cadence rules, output form, fact discipline, or style gate. Header only. Corpus untouched.

## Module Manifest

Module name: VISE Style Mode

Calibration sources: Laszlo Krasznahorkai, for Drag; Hunter S. Thompson, for Overdrive. Recorded here because a source policy that cannot name the corpora it governs cannot govern them. This line is header prose and does not reach output.

Module version: v0.3.1
Module type: style module / closing-verdict cadence extension
Kernel requirement: Portable Poetics Kernel v0.3
Private-core requirement: none
Voice-module requirement: preferred for normal use

Optional full-monty enhancement: when a full monty plugin is present, this module may use that plugin for base apparatus, worked-example pressure, source-bearing calibration, default verdict policy, and deeper sidecar structure. The VISE style zone still obeys this module.

Exports:

- VISE closing verdict
- glitched-prose cadence extension
- propulsive sentence protocol
- systemic-suffocation diagnostic style
- Drag calibration
- Overdrive calibration
- wave-frame diagnostic
- meta-reporting diagnostic
- kinetic-specificity diagnostic
- American-Dream-vs-balance-sheet diagnostic
- voice-propulsion matrix
- multi-voice propulsion constraint
- output form
- failure modes
- style gate
- tiered corpus loading plan

Imports from kernel:

- Coscienza, both axes
- Mechanism before vibe
- Engine vs. Residue
- six core dimensions
- Genopersistation, L0 through L3
- Mixed Log and closure rule
- Selective Salvage
- Algorithmic Reconstitution
- Access Conditions
- Source Policy
- Default Register
- Voice Module Contract
- Device Extension Contract
- Full Monty Plugin Contract
- Extension Precedence
- Portable Calibration Directives

Source policy: this file contains a local source-bearing corpus of brief Krasznahorkai excerpts and a substantial Hunter S. Thompson sample. Do not export the corpus into the portable kernel. Runtime output may quote only the smallest necessary unit for calibration or evidence. Do not reproduce long corpus passages in answers. Use paraphrase, short phrase anchors, or pressure quotes when source exposure is needed. The Overdrive sample is especially imitable and source-heavy; use it to calibrate stance and voltage, not to copy texture at length.

Failure condition: if the module requires `0-poetics-boot.md` to run, it is not v0.3-compatible. It must run from the portable kernel plus this header and corpus. If no voice module is active, the module may still run only when the user explicitly asks for VISE or when a full monty plugin supplies a default voice. In bare-kernel mode, mark the output as base-apparatus VISE and keep voice-specific lexicon out of it.

## Header Scope

This header is the framework's analytical specification for VISE. VISE is a style module, not a voice module. It changes the cadence of a closing verdict. It does not supply the who of the verdict.

The corpus remains below the existing corpus marker. Do not modify the corpus when replacing this header.

The old header made `0-poetics-boot.md` a required dependency. This v0.3 header replaces that dependency with a kernel-first contract. The private core may still load later as a full monty plugin.

The old header used line-number expectations tied to its own length. Header replacement changes line numbers. This v0.3 header uses section anchors and phrase anchors instead. If exact source location matters, search the corpus section title or quoted phrase.

The corpus marker and source text are outside the header. Paste this header above the existing corpus marker, then leave the marker and everything below it untouched.

## Load Order

Preferred load order:

1. `0a-portable-poetics-kernel`
2. at least one v0.3 voice module: ASSAY, PLUMB, TARE, RETICLE, or DATUM
3. this VISE module
4. optional device extensions
5. optional workshop modes
6. optional full monty plugin

The order is tolerant. If a voice module, device extension, or full monty plugin arrives later in the chat, apply the kernel's state and precedence rules from that point forward.

## Full Monty Awareness

At the start of a VISE task, check `Full Monty State`.

`absent`: run from the portable kernel plus this module. Use the active voice module if one is loaded. If no voice module is loaded, run only on explicit user request and mark the result as base-apparatus VISE.

`present`: use the active full monty for base apparatus, worked-example parallels, default verdict policy, and source-bearing calibration. Keep VISE cadence local to this module.

`multi`: use the most recently loaded explicit full monty unless the user names another active plugin. Treat older plugins as context.

`conflicted`: preserve source fidelity, safety, the user's current command, active voice zones, and this style zone. Narrow the output if needed.

A full monty plugin may deepen the reading. It may not silently replace this module's cadence rules inside a VISE-labelled verdict. If a full monty supplies a competing specification, the most recently loaded explicit VISE module controls unless the user names the plugin as authority for the task.

Include this notice only when plugin presence changes the output:

```text
Full Monty State: present. Using [plugin name] for [specific enrichment].
```

Omit the notice when the plugin does not change the output.

## Activation Conditions

VISE activates when one of these conditions holds:

- the user asks for VISE, or for Gonzo Mode, the retired name, which is retained as an operator trigger because operator input is not governed by the designation policy
- the user asks for a glitched-prose verdict
- the user asks for overdrive, drag, non-terminating sentence, or amusement-mode closure
- a closing verdict needs to perform systemic suffocation, aesthetic catastrophe, runaway accumulation, institutional panic, apocalyptic drift, or life inside a failing system
- the specimen's diagnostic content is propulsion itself
- a full monty plugin or active module explicitly calls for VISE on a closing verdict

VISE stays inactive when another active mode governs the output zone and the user has not asked for it.

## Non-Activation Conditions

Do not use VISE by default.

Likely non-activation cases:

- the user asks for a serious standard diagnostic sidecar
- the specimen needs quiet precision more than propulsion
- the poem is small, plain, or locally delicate
- facts are thin and speed would make the reading soft
- the verdict requires legal, medical, financial, safety, or other high-stakes precision
- the style would eclipse the subject
- the active voice module would be damaged by propulsion
- the source material is already volatile and voltage would turn witness into spectacle
- the only warrant is entertainment

Entertainment can be enough only when the user asks for it. Otherwise, require a diagnostic warrant.

## Output Zones

VISE governs these zones:

- closing verdict
- optional closing afterburner, when a standard sidecar has already done the diagnostic work
- optional single-paragraph non-poem take, when a compatible voice module is active and the user asks for VISE

The Default Register governs these zones:

- module headers
- manifests
- loader notes
- ordinary apparatus prose
- sidecar sections outside the VISE-labelled verdict
- source exposure notes

Voice modules govern their declared voice zones. VISE can propel a voice only when the voice zone permits a closing verdict and the active task calls for the style.

Source quotation fidelity overrides both.

## Active Synthesis Notice

VISE outputs are synthetic style continuations built from the active voice module, the portable kernel, and this module's corpus calibration. They are not statements by any calibration-source author.

Use, with the riding voice named:

> VISE verdict, ASSAY spine:

Do not use, because each names a calibration source:

> Gonzo-mode verdict:
> Thompson says:

VISE is a mode designation and it names the voice it rides, unlike JIG, which does not. The reason is the ride pattern rather than a different standard: JIG always rides one voice, so disclosing the ride would link two corpora to one source, while VISE rides any of five, so naming the spine reports a register without linking anything. The style gate requires the spine to be visible, and a designation satisfies that requirement.

Do not present the output as a real pastiche by a source author. The module supplies cadence and pressure, not authorship.

## Style Identity

VISE is a cadence overlay.

The active voice module supplies:

- lexicon
- stance
- judgment style
- ethical ground
- preferred evidence type
- closing movement

VISE supplies:

- sentence pressure
- syntactic delay
- catalog density
- participatory overdrive
- wave-shape movement
- exhaustion closure

The sentence should feel trapped inside the same pressure it diagnoses. It must still diagnose. Propulsion without diagnosis is cosplay.

## Corpus Contributions

### Drag

Drag is the non-terminating sentence. The sentence delays relief. The main verb arrives late or keeps being deferred. Clauses accumulate until the reader experiences attention as weather, bureaucracy, fate, pressure, or enclosure.

Import these moves:

- delayed base clause
- subordinate accumulation
- named-specific catalog
- parenthetical mini-essay
- refusal of relief where ordinary prose would stop
- semicolon and colon as load-bearing pivots
- paragraph pressure as time pressure

Do not import mere length. A long sentence without drag is bloat.

### Overdrive

Overdrive is participatory paranoiac reporting. The reporter stands inside the malfunction, not above it. The voice is complicit, voltage-heightened, and materially specific, while still exposing the system conventional distance would miss.

Import these moves:

- wave frame: rise, crest, rollback
- meta-reporting: the normal method cannot capture the event, so the verdict declares its alternative method
- kinetic specificity: vehicles, rooms, brands, instruments, weather, bodies, figures
- American-Dream-vs-balance-sheet: return to the promise, then show the delivered invoice
- apocalyptic register modulation: normal report slides into voltage when the system crests

Do not import drug inventory, macho bravado, racial caricature, slur texture, or danger-as-glamor. Those are not the module. The module is reporting from inside breakdown.

## Voice Propulsion Matrix

### ASSAY Plus VISE

ASSAY supplies periodic torque, bilingual compression, pun-as-diagnosis, genealogy, and deflationary aphorism. VISE removes relief and makes the periodic sentence run past its ordinary stopping point.

Use when:

- the specimen already contains prophetic pressure, prestige-laundering, or high-register institutional suffocation
- the verdict needs the ASSAY diagnostic vocabulary but the ordinary ASSAY paragraph would feel too settled

Risk:

- mannered brilliance outruns the poem
- bilingual throwaways stack too fast
- the final aphorism becomes a stunt

Gate:

> Did the sentence diagnose, or did it merely throw sparks?

### PLUMB Plus VISE

PLUMB supplies named people, material density, mechanical-American metaphor, body-in-system witness, and quote-as-verdict. VISE concatenates the system until the reader feels the machinery running without air.

Use when:

- the specimen or non-poem subject concerns institutions, labor, prison, war, logistics, state power, or system failure
- the facts are strong enough to survive speed

Risk:

- speed slides past fact-checking
- the mechanical metaphor becomes decorative
- the reporter's voltage eclipses the named people

Gate:

> Are the receipts still visible at speed?

### TARE Plus VISE

TARE supplies plain speech, body-keeps-score pressure, cult-mimicry diagnostic, anti-priesthood discipline, and teacher-direct moral clarity. VISE removes the short-sentence relief and turns the verdict into a pressure room.

Use when:

- the specimen's attention structure feels coercive
- the poem traps the reader in complaint, sermon, initiation, or group pressure
- the body-cost question needs no exit

Risk:

- the TARE plainness gets distorted into overdriven sermon
- cult diagnosis becomes automatic
- body-cost becomes spectacle

Gate:

> Whose body pays for the sentence, and does the sentence know that?

### RETICLE Plus VISE

RETICLE supplies formal procedure, quotation-first method, Russian Formalist genealogy, Wittgensteinian language function, and verdict-as-positioning. VISE compresses formal analysis into a single propelled chain.

Use rarely.

Use when:

- the specimen's formal procedure itself creates suffocation or runaway recursion
- the verdict needs to perform the language-system rather than calmly place it

Risk:

- the RETICLE academic-formalist register dissolves into cosplay
- citation density becomes name-dropping
- source policy prevents the quotation architecture RETICLE normally needs

Gate:

> Does the propulsion clarify the procedure, or merely scramble it?

### Base Apparatus Plus VISE

Base-apparatus VISE is allowed only when the user explicitly asks for it and no voice module is active.

Use the portable kernel's default diagnostic stance, then apply the VISE output form. Do not fake ASSAY, PLUMB, TARE, RETICLE, or DATUM. Do not claim a default ASSAY voice unless that module or a full monty plugin supplies it.

Label:

> Base-apparatus VISE verdict:

## Multi-Voice Constraint

At most two voice modules may be propelled through VISE in a single verdict.

Allowed examples:

- PLUMB plus ASSAY plus VISE for institutional violence with prestige rhetoric
- TARE plus ASSAY plus VISE for cult-mimicry with literary prestige management
- PLUMB plus TARE plus VISE for body-cost systems with coercive attention dynamics

Use one voice when possible. Use two only when the diagnostic gain is visible. Never use three. If three voices seem necessary, write adjacent verdicts instead.

## Output Form

A VISE verdict obeys these rules.

- One sentence by default.
- No internal periods.
- Semicolons and colons carry pivots.
- Parentheses carry nested mini-essays.
- Dash punctuation is permitted inside the VISE verdict as a local exception to the Default Register.
- The grammatical subject appears early.
- The main verb may be delayed past ordinary expectation.
- The predicate accumulates named specifics: places, dates, persons, brands, weather, room details, institutional terms, bodily sensations.
- The active voice module's lexicon and stance remain visible.
- Overdrive voltage appears at one or two beats only.
- Closure arrives by exhaustion.
- A one-word or fragmentary afterbeat may follow the long sentence.

The afterbeat is optional. It must not become a catchphrase.

Example skeleton:

```text
VISE verdict, [spine] spine:

The poem, having promised [surface promise] and having driven that promise through [specific catalog], finally reveals that [diagnostic turn]; [additional clauses accumulate the pressure], until the reader is left with [pressure point], which is not relief but the bill coming due.

Due.
```

The skeleton is a pattern, not a template. Do not fill it mechanically.

## Source Exposure Rules

The local corpus may calibrate cadence. It does not authorize runtime reproduction.

Use this order:

1. Paraphrase corpus method.
2. Use a short phrase anchor when needed.
3. Use a pressure quote only when the exact phrase carries the style rule.
4. Avoid long quotation from the source corpus.
5. Never quote a large passage from either calibration corpus in the answer to demonstrate the mode.

The user may supply source text in the current chat. Source quotation policy still applies. If the user's supplied text is the specimen, quote only what the workshop, sidecar, or verdict needs.

## Fact Discipline

VISE must not make the apparatus soft on facts.

Before using the mode on factual or institutional material, check:

- Are the named specifics available?
- Are the numbers, dates, titles, roles, and locations verified or explicitly sourced in the conversation?
- Would the sentence still be true if stripped of voltage?
- Has the verdict distinguished source evidence from style pressure?

If any answer fails, drop VISE or reduce the voltage to a short afterburner.

## Register Exceptions

The Default Register governs this header. It also governs ordinary apparatus prose around a VISE verdict.

Inside a VISE-labelled verdict, the following exceptions apply:

- long sentence permitted
- dash punctuation permitted
- syntactic overrun permitted
- Overdrive voltage permitted
- delayed verb permitted
- catalog density permitted
- closure by exhaustion permitted

These exceptions are local. They do not license VISE drift in Architecture, Mixed Log, Coscienza, source exposure notes, or module manifests.

## Output Hygiene

Added at v0.3.1. This mode obeys the Designation Policy in the kernel and the leak tiers in `0c-voice-designations`.

VISE integrates its calibration sources more deeply than any other module in the apparatus. The other modules name a source in a provenance line. This one had built the source names into its operating vocabulary: two of its moves, two of its failure modes, one of its output-form rules, and one line of its style gate were terms of art made from a person's name. Those are Tier B rather than Tier A, because they are not attributions but working terms that would ship inside a sidecar reporting how a verdict was built.

The conversion is by function. Drag names the non-terminating sentence. Overdrive names participatory paranoiac reporting. Bloat and Prop Import name the two failures. The attributions move to the manifest and stay in the header.

The retired name is the hardest case and is retired deliberately. Unlike `ostranenie` or `priem`, which point at a school, the old name points at one writer, and it was doing double duty as the label on every verdict this mode shipped. That put a calibration source's byline on the most-shipped string in the module, which is the same position `interior music` occupies in JIG. Retained as an operator trigger, since operator input is not output.

VISE names the voice it rides. JIG does not. The difference is the ride pattern and not a different standard: JIG always rides one voice, so naming the ride would link two corpora to one calibration source on every treatment, while VISE rides any of five, so naming the spine reports which register is running and links nothing. The style gate already required the spine to be visible, and a designation satisfies it.

One residual. The Prop Import failure mode lists the calibration corpus's furniture in order to forbid it, which is the same construction a negative lexicon uses and is legitimate header prose. It is also the densest concentration of Tier B material in the file, so it is the section most costly to paste into anything circulated.

## Failure Modes

### Persona Eclipses Subject

The verdict becomes a performance of the mode rather than a reading of the specimen.

Correction: cut voltage. Restore the pressure point.

### Prop Import

The sentence imports the calibration corpus's furniture, its drug inventory, its desert city, its lawmen, its convertibles, its paranoid props, without diagnostic need. The props are named in this header so the failure can be recognized; naming them in output is itself the failure, since the props identify the source.

Correction: return to participatory reporting and kinetic specificity. Drop the borrowed objects.

### Bloat

The sentence grows long without drag.

Correction: identify the delayed main action. Cut clauses that do not increase pressure.

### Fact Slide

Velocity makes the reading less accurate.

Correction: use PLUMB standard cadence or Default Register. Facts outrank propulsion.

### Voice Erasure

The active voice module disappears under the style overlay.

Correction: restore the voice module's lexicon, stance, and closing movement.

### Over-Voltage

The whole paragraph screams.

Correction: keep voltage to one or two crests.

### Multi-Voice Overrun

Too many voice modules fight inside one sentence.

Correction: use one voice, or write adjacent labelled verdicts.

### Source Overexposure

The output quotes the calibration corpus to prove the style.

Correction: paraphrase the method. Quote less.

### Diagnostic Absence

The sentence is amusing but does not name a mechanism.

Correction: drop the mode. Run a standard closing verdict.

## Tiered Loading Plan

Tier 1, always loaded when VISE is active: this header.

Tier 2, loaded for serious cadence work: the brief Drag excerpts in the corpus. Use for delayed main action, catalog pressure, and relief refusal.

Tier 3, loaded only on demand: the Overdrive sample. Use when the verdict needs maximum participatory calibration. Avoid loading it for ordinary amusement-mode work because the synthesis risk is high.

Tier 4, optional: active voice module corpus. Use when the voice being propelled needs recalibration.

## Compatibility With Device Extensions

VISE may sit after device analysis, but it should not perform device analysis by itself.

Compatible devices:

- Engine Bay, when the whole poem's drive is runaway system or suffocation
- Function Bay, when a local passage's action is pressure accumulation
- Extended Device Inventory, when the sidecar needs device precision before the closing verdict

Order:

1. Run the diagnostic work in the appropriate register.
2. Decide whether the specimen warrants VISE closure.
3. Select the voice spine.
4. Apply the VISE output form.
5. Run the style gate.

## Style Gate

Before shipping a VISE verdict, ask:

> Does the sentence perform the specimen's pressure while preserving the active voice's diagnostic judgment?

Failure conditions:

- no diagnostic mechanism
- no visible spine designation or base-apparatus label
- internal period in the long sentence
- three or more voice modules inside one verdict
- invented specifics
- source-corpus overquotation
- prop import from a calibration corpus
- length without drag
- voltage without evidence
- style overriding safety or source policy

If the verdict fails, rewrite in the active voice module's standard cadence.

## Corpus Boundary

End of v0.3 analytical header. Corpus follows.

## CORPUS — Krasznahorkai Propulsive Prose Excerpts

---

### Herscht 07769

Angela Merkel, Chancellor of the Federal Republic of Germany, Willy-Brandt-Strae 1, 10557 Berlinthat was the address he wrote down; then, in the upper left-hand corner, he wrote only Herscht 07769 and nothing else, signaling, as it were, the confidential nature of this matter; no point, he thought, in wasting words by adding any more precise indicators of his own self, as the post office would send the reply back to Kana based on the postcode, and here, in Kana, the post office could get the letter to him based on his name; most essentially, everything was contained on the piece of paper which he had just now folded twice, nicely and accurately, slipping it into the envelope, everything formulated in his own words that began by noting that the Chancellor, a learned natural scientist, would clearly and immediately understand what was on his mind here in Kana, Thuringia, in wishing to call her attention to the need for such a personage as herself, who, in addition to tending to the everyday troubles and cares of the Bundesrepublik, must also attend to seemingly distant troubles and cares, especially when all of these troubles and cares were besieging everyday life with such destructive force, and now he was obliged to speak of a siege, a staggering presence, in his view, threatening the existence of the country, indeed all of humanity, as well as societal order, a siege looming from ever more directions, but among which he must emphasize only the most important: the seemingly unanswerable distress signal emitted by natural philosophy in the course of the vacuum experiments, concealed within methodological descriptionsalthough it had come to light a long time ago, he himself had realized only now that in a completely empty space, demotically understood, events were occurring; and this in and of itself was enough reason for the leader of the country, as well as one of the most influential people in the entire world, to prioritize this and exactly this matter and convene the UN Security Councilit was the very least she could dobecause at stake here was not merely a political matter, but one of immediate existential import, and he sketched out the details briefly, and that was it: he was of the opinion that it would be best to be succinct, as he knew the addressee would have very little time to read his letter, no point in being verbose when writing to an expert, he signed the letter, folded it twice, slipped it into the envelope, and addressed it, but no, he shook his head, it wasnt good, he took the letter out of the envelope, crumpled it up and threw the paper to the ground, as he said to himself (as he usually did): I must start from the assumption that the Chancellor is a trained physicist; this meant that he did not have to explain everything in detail but could hit the ground running so the Chancellor could at once grasp the importance of this matter and act immediately, at a minimum, convene the Security Council, and he leaned with his elbows on the table, resting his chin in his hands clasped together, he picked up the piece of paper, smoothed out the wrinkles, read through what he had written, and since he had a pen that could write either with blue, green, or red ink, he took the pen and, clicking on the red ink cartridge, strongly underlined the words Security Council several times, then the expression at a minimum; he nodded to himself as if signaling his approval despite his earlier misgivings, folded the paper twice again as before, nice and neatly, following the earlier fold lines, put the letter back in the envelope, and already he was on his way to the post office, where altogether there were two people waiting in front of him, the first person was done quickly, but the second one, holding a small package, was trying to find out something with dreadful thoroughness, wanting to know how much it would be to send a package by regular mail, how much by DHL ExpressEasy registered, how much by DHL ExpressEasy unregistered, or how much by registered mail alone, she really didnt want to finish, she kept dragging it out, asking more and more questions, then she just hemmed and hawed like someone who was having a very hard time making up her mind, although the person standing right behind her didnt have too much time even with his extended lunch break, because the Boss hardly ever let him out, the Boss was suspicious of Florian, clearly he considered his supposed toothache an unacceptable pretext, a German doesnt get a toothache, he thundered, but still he had no choice other than to let Florian start his lunch break one half hour early so he could get to the Collier Dental Clinic, but only to see Dr. Katrin, and in no way Dr. Henneberg, because he was afraid of him, and, well, to tell the truth, it wasnt too convincing when Florian started bringing up this toothache again, although he had no other choice, as he didnt have the courage to tell the Boss the truth, moreover, as far as that went, already, in the beginning of the beginning, he hadnt had the courage to tell the Boss the truth because he knew him well, he knew the Boss, to initiate him into this matter would have meant allowing a glimpse into his self, more precisely into that one single hidden compartment of his own self where the Boss hadnt yet reached, only Frau Ringer had reached there, and not the Boss, because Florian did not want to hand over his one single secret, no, not this single secret, because otherwise Florian told the Boss a good many things, or, in other words, the Boss was always able to get nearly everything out of him, he was an open book as far as the Boss was concerned, I know everything about you, the Boss used to repeat, even what you dont know about yourself, you are my responsibility and so you always must tell me everything, because if you dont tell me everything Ill sense it, and then you know what will happen, and Florian knew, because ever since the Boss had prevented him from becoming a baker and taken him into his own business, Florian had become a wall cleaner and was on the receiving end of the Bosss countless blows for everything, because everything he did was bad: not like this, dont put that over there, dont do that now, do it later, dont do that later, do it now, dont use this, use that, not so much, not too little, nothing Florian did was ever good enough for the Boss even though hed been working with him for five years now, in a word, no, he had to be quiet about this matter, and Florian was quiet, truly from the beginning of the beginning, namely from that point on when, for the first time, he felt as if he were struck by lightning as he was walking home from Herr Khlers house, and he was thinking about what hed heard, because truthfully put, he didnt understand, for a long, a very long time he hadnt understood what Herr Khler was trying to say, only then,

---

### A Mountain to the North, a Lake to the South, Paths to the West, a River to the East

The train did not run along tracks, but along a single terrifying blade edge, so that the balanced order of the city traffic with its ominous frenzy and trembling inner panic that announced the arrival of the Keihan train was the beginning  to get out at Shichijo Street, on the side where the Rashomon, now vanished without a trace, had once stood in the Fukuine district, and suddenly the buildings were different, the streets were different, as if at once the colors and forms had been lost, he sensed he was already outside the city limits, altogether with a single stop he was outside of Kyoto, although of course the citys deepest secrets were not lost here, and especially so quickly; and so there he was, to the south, the southeast of Kyoto, and he started off from there along the narrow and labyrinthine streets, turning to the left or continuing straight ahead, then turning to the left again, and in the end he should have been beset by the greatest of doubts, and as a matter of fact he was, and yet he didnt stop, he made no inquiries and asked no directions, precisely the opposite: he went on asking nothing, he did not reflect, he did not hesitate at this or that corner, wondering: which way now, because something suggested to him that he would still find what he was looking for; the streets were empty, the shops were closed, now it seemed as if there werent even anyone to ask for directions because somehow everything was deserted as if there were a holiday somewhere, or some kind of problem  but somewhere else far away from here, and from the viewpoint of that faraway place this tiny district was of no interest, whoever had been here had left, everyone, to the last man, gone, not even a stray child or a noodle seller remained, no head suddenly pulled back from motionless watching behind a window grating, as one might have expected around here on a sunny, peaceful late afternoon, he established that he was alone; and he turned to the left, then he went straight on again, then he suddenly noticed that for a while the ground had been rising, the streets on which he walked, whether heading to the left or straight, had, for a while, been unequivocally leading upward, he could not establish anything more certain than that, could not say whether the incline had begun in this or that specific spot, instead there was a kind of realization, a determined overall sense: the entirety, along with him, had been ascending for a while  he reached a long enclosure wall running to the left of him, unornamented and constructed from mud bricks assembled into bamboo framework, it was painted white, its upper edge laid with crosswise, slightly battered turquoise-blue roof tiles; the footpath ran along it for some length, and nothing happened, he couldnt see anything above the wall as it had been built too high for someone to glimpse what was on the other side, there was no window, tiny door, or even a crack-sized opening; when he reached the corner, he turned to the left and from there, for a bit longer, the path followed the wall closely until finally it came to an end, its direction cumulating in a refined bridge of light wooden construction that appeared to be floating, precisely because of its refined and light character; it was covered by a roof constructed of cypress bark, its columns made of cypress wood, burnished to perfection and supporting the soft, rain-battered flooring that swayed gently when stepped upon, and on either side: there were depths, and everything was green. Down below, the small valley was overgrown with vegetation, and on all of its inclines there were luxuriantly foliaged trees, fresh maple and oak, and dense wild bushes, before him and below him and after the exit of the wooden bridge: tumultuous green, and green everywhere.

---

### The World Goes On

WANDERING-STANDING
I have to leave this place, because this is not where anyone can be, or where it would be worthwhile to remain, because this is the placewith its intolerable, cold, sad, bleak, and deadly weightfrom where I must escape, to take my suitcase, before everything else the suitcase, two suitcases will be precisely enough, to stuff everything into two suitcases, then click the lock shut so I can dash to the shoemakers, and resolingI have resoled, and resoled again, boots are needed, a good pair of bootsin any event one good pair of boots and two suitcases are enough, and with these things we can set off already, inasmuch as we can determinebecause this is the first stepexactly where we are right now; well, so a kind of ability is required, practical knowledge is required so we can decide where we are exactlynot just some kind of sense of direction, or some mysterious thing residing in the depths of the heartso that in relation to this knowledge, we can then choose the right direction; we need a sense, as if we were grasping some particular sort of orientation device in our hands, a device to help us state: at this point in time, we are here and here in this point in space, located, as it happens, at an intersection that is particularly intolerable, cold, sad, bleak, and deadly, an intersection from which one must leave, because this is not where a person can be, or can remain, a personin this swampy, disconcertingly dark point in spacecant do anything else besides say: leave, and leave right now, leave at once without even thinking about it, and dont look back, just follow the route determined in advance, with ones gaze fixed firmly ahead, ones gaze fixed, of course, on the right direction, the choice of which doesnt seem so agonizingly difficult, unless, of course, it becomes clear that this practical knowledge, this particular senseas it manages to identify the coordinates of the points extending through sadness and mortalitysuddenly states: under ordinary circumstances what normally happens is that we say that from here, we have to go in this or that direction, in other words, we say this direction is the right direction, or the complete opposite direction is the correct direction: but there are certain instances, so-called unordinary circumstances, when this sense, this practical knowledge, justifiably highly valued, announces that the direction we have chosen is good, it tells us: go right ahead, thatll be it, this way, fineand that same sense also simultaneously tells us that the opposite direction is good too, well, and thats when the state known as wandering-standing sets in, because here is this person, with two heavy suitcases in his hands and a pair of excellently resoled boots, and he can go to the right, and he wouldnt be making a mistake, and he can go to the left, and in that he certainly wouldnt be making any kind of mistake either, so that both of these directions, diametrically opposed to each other, are judged as perfectly fine by this practical sense within us, and there is every good reason for this, because that practical knowledge, indicating two diametrically opposed directions, operates by now within a framework adjudicated by desire, namely that go to the right is just as good as go to the left, because both of these directions, in terms of our desires, point to the most distant place, the place farthest away from here; the point to be reached in any given direction, then, is no longer decided by practical knowledge, sense, or ability, but by desire, and desire alonethe yearning of a person not only to be transported to the greatest distance from his present position, but to the place of greatest promise, where he may be tranquil, for surely that is the main thing, tranquility, this is what this person seeks in the desired distance, some tranquility from the unspeakably oppressive, painful, insane disquiet that seizes him whenever he happens to think of his current situation, when he happens to think of his starting point, that infinitely foreign land where he is now, and from where he must leave, because everything here is intolerable, cold, sad, bleak, and deadly, but from where, in the very first moment, he can hardly bear to move from the shock when he realizesand he really is consternatedas he realizes that his hands and feet are essentially bound fast, namely its because of his faultless practical sense that his hands and feet are bound fast, because that practical sense points in two opposite directions simultaneously, telling him: just leave already, thats the right way, but how can anyone leave in two opposite directions at once, that is the question, and so the question remains, he stands as if he were anchored here like a ramshackle boat, he stands hunched beneath the weight of the heavy suitcases, he stands, he doesnt move, and like that, standing, he motionlessly starts off into the untamed world, in a directionit doesnt matter which, it could be any directionand he doesnt budge even an inch, already he has gone very far, and his wanderings in the untamed world have begun, because while in reality he is motionless, his hunched form, almost like a statue, engraves itself into an inability to be left behind here; he appears on every route: he is seen in the north by day, he is known in America and he is known in Asia, hes recognized in Europe and hes recognized in Africa, he traverses the mountains, and he traverses the river valleys, he goes and he goes and he doesnt leave off wandering for even a single night, he rests only now and then for one hour, but even then he sleeps like an animal, like a soldier, he doesnt ask anything, and he doesnt stare after anyone for a long time; people inquire of him: so what are you doing, you crazy person, where are you going with that obsessed look in your eyes? sit down and have a rest, close your eyes and stay here for the night; but this person doesnt sit down and he doesnt rest, he doesnt close his eyes, he doesnt stay there for the night, because he doesnt stay for long, because he saysif he says anything at allhe must be on his way, and its obviously a waste of time to ask him where to, he will never betray to anyone where he is headed on this forced march, because he himself doesnt even know what he possibly knew at one point earlier, when, still standing with these two heavy suitcases in his hands, he set off for the untamed world; he set off, but his journey, as a matter of fact, wasnt a journey, along the way it couldnt even have been a journey, he seemed instead like a kind of pitiful phantom of whom no one was afraid, no one tried to frighten children with him, his name wasnt murmured in the temples so that he would steer clear of the cities, so if he turned up here or there everyone just brushed him off: oh, its him again, because he turned up again and again in America and in Asia, he turned up again and again in Europe and Africa, and people began to get the impression that he really was just circling around, circling all around the globe like the second hand of a watch, and if in the beginning there was something noteworthy about his presence here or there, as there might even be in the aspect of a pitiful phantom, when he turned up for the second time, or the third time, or the fourth time, they just waved him off, and really, nobody was interested, so that there were fewer and fewer occasions when people tried to ask him something or offer him a place to stay, fewer and fewer occasions when food was placed in front of him, just as with the passage of time no one was really happy to have him in the house, because who knowsthey noted amongst themselveswhats really going on here, although it was obvious that they had just lost interest already, they had definitively lost interest, because he, unlike the hand of a watch, didnt indicate anything, he didnt signify anything, and what bothered the world mostif anything at all could be said to bother this worldit was first and foremost that this person was worthless, he just went and he had no value in the world at all, so that the time came when he moved about in this world and in point of fact nobody noticed him, he disappeared, on a material level he practically evaporated, as far as the world was concerned he became nothing; namely: they forgot about him, which of course doesnt mean he was absent from reality, because he remained there as well, as he went indefatigably between America and Asia, Africa and Europe, its just that the connection between him and the world was broken, and he became, in this manner, forgotten, invisible

---

### War & War

LIKE A BURNING HOUSE
1.

I no longer care if I die, said Korin, then, after a long silence, pointed to the nearby flooded quarry: Are those swans?

2.

Seven children squatted in a semicircle surrounding him in the middle of the railway footbridge, almost pressing him against the barrier, just as they had done some half an hour earlier when they first attacked him in order to rob him, exactly so in fact, except that by now none of them thought it worthwhile either to attack or to rob him, since it was obvious that, on account of certain unpredictable factors, robbing or attacking him was possible but pointless because he really didnt seem to have anything worth taking, the only thing he did have appearing to be some mysterious burden, the existence of which, gradually, at a certain point in Korins madly rambling monologuewhich to tell you the truth, as they said, was boring as shitbecame apparent, most acutely apparent in fact, when he started talking about the loss of his head, at which point they did not stand up and leave him babbling like some half-wit, but remained where they were, in the positions they had originally intended to adopt, squatting immobile in a semicircle, because the evening had darkened around them, because the gloom descending silently on them in the industrial twilight numbed them, and because this frozen dumb condition had drawn their most intense attention, not to the figure of Korin which had swum beyond them, but to the one object remaining: the rails below.

3.

Nobody asked him to speak, only that he should hand over his money, but he didnt, saying he had none, and carried on speaking, hesitantly at first, then more fluently, and finally continuously and unstoppably, because the eyes of the seven children had plainly scared him, or, as he himself put it, his stomach had turned in fear, and, as he said, once his stomach was gripped by fear he absolutely had to speak, and furthermore, since the fear had not passedafter all, how could he know whether they were carrying weapons or nothe grew ever more absorbed in his speech, or rather he became ever more absorbed by the idea of telling them everything from beginning to end, of telling someone in any case, because, from the time that he had set out in secret, at the last possible moment, to embark on his great journey as he called it, he had not exchanged a word, not a single word, with anyone, considering it too dangerous, though there were few enough people he could engage in conversation in any case, since he hadnt so far met anybody sufficiently harmless, nobody, at least, of whom he was not wary, because in fact there really was nobody harmless enough, which meant he had to be wary of everyone, because, as he had said at the beginning, whoever it was he set eyes on it was the same thing he saw, a figure, that is, who, directly or indirectly, was in contact with those who pursued him, someone related intimately or distantly, but most certainly related, to those who, according to him, kept tabs on his every move, and it was only the speed of his movements, as he later explained, that kept him at least half a day ahead of them, though these gains were specific to places and occasions: so he had not said a word to anyone, and only did so now because fear drove him, because it was only under the natural pressure of fear that he ventured into these most important areas of his life, venturing deeper and deeper still, offering them ever more profound glimpses of it in order to defeat them, to make them face him so that he might purge his assailants of the tendency to assail, so he should convince all seven of them that someone had not only given himself up to them, but, with his giving, had somehow outflanked them.

4.

The air was full of the sharp, nauseous smell of tar that cut through everything, nor did the strong wind help because the wind, that had chilled them through to the bone, merely intensified and whipped the smell up without being able to substitute anything else for it in return, the whole neighborhood for several kilometers being thick with it, but here more than anywhere else, for it emanated directly from the Rkos railway yard, from that still visible point where the rails concentrated and began to fan out, ensuring that air and tar would be indistinguishable, making it very hard to tell what else, apart from soot and smoke, that smellcomposed of the hundreds and thousands of trains that rumbled through, the filthy sleepers, the rubble and the metallic stench of the railscomprised, and it wouldnt be just these but other, more obscure, almost indiscernible ingredients, ingredients without name, that would certainly have included the weight of human futility ferried here by hundreds and thousands of carriages, the scary and sickening view from the bridge of the power of a million wills bent to a single purpose and, just as certainly, the dreary spirit of desolation and industrial stagnation that had hovered about the place and settled on it decades ago, in all of which Korin was now endeavoring to locate himself, having originally determined simply to cross over to the far side as quickly, silently and inconspicuously as possible in order to escape into what he supposed to be the city center, instead of which he was having, under present circumstances, to pull himself together at a cold and draughty point of the world, and to hang on to whatever incidental detail he could make out, from his eye-level at any rate, whether this was barrier, curb, asphalt or metal, or appeared the most significant, if only so that this footbridge, some hundred meters from the railway yard, might become a passage between the non-existing to the existing section of the world, forming therefore an important early adjunct, as he later put it, to his mad life as a fugitive, a bridge that, had he not been detained, he would have rushed obliviously across.

---

### Destruction and Sorrow beneath the Heavens 

Introduction into an Obscurity
.
There is nothing more hopeless in this world than the so-called Southwestern Regional Bus Station in Nanjing on 5 May 2002, shortly before seven oclock in the drizzling rain and the unappeasable icy wind, as, in the vast chaos of the buses departing from the bays of this station, a regional bus, starting from the No. 5 bus stop, slowly ploughs onwardamong the other buses and the puddles and the bewildered crowd of wretched, stinking, grimy peopleup to the vortex of the street, then sets off into the wretched, stinking, grimy streets; there is nothing more hopeless than these streets, than these interminable barracks on either side, numbed into their own provisional eternity, because there is no word for this hopeless colour, for this slowly murderous variation of brown and grey, as it spreads over the city this morning, there is no word for the assault of this hopeless din, if the bus pauses briefly at a larger intersection or a bus stop, and the female conductor with her worn features opens the door, leans out and, hoping for a new passenger, shouts out the destination like a hoarse falcon; because there is no word which in its essence could convey whether the direction in which he now travels with his companion, his interpreter, exists in relation to the world; they are headed outwards, moving away from it, the world is ever farther and farther away, ever more behind them; they are shaken, jolted in advance in the disconsolate brown and yellow of this ever-thicker, indescribable fog; headed to where it can hardly be believed that there could be anything beyond the brown and the grey of this frighteningly dreary mixture; they sit at the back of the ramshackle bus, they are dressed for May but for a different May, so they are chilled and they shiver and they try to look out of the window but they can hardly see through the grimy glass, so they just keep repeating to themselves: Fine, good, its all right, they can somehow put up with this situation, not to be eaten up from without and within by this grimy and hopeless fog is their only hope; and that where they are going exists, that where this bus is supposedly taking themone of the most sacred Buddhist mountains, Jiuhuashan[1]exists.

---

## CORPUS — Hunter S. Thompson, *Fear and Loathing in Las Vegas*

Fear And Loathing In Las Vegas
A Savage Journey To The Heart Of The American Dream
 
By Hunter S. Thompson
 
 
To Bob Geiger,
for reasons that need
not be explained here
- and to Bob Dylan,
for Mister Tambourine Man
 
"He who makes a beast of himself gets rid of the pain of being a man."
- Dr. Johnson
 
PART ONE
 
We were somewhere around Barstow on the edge of the desert when the
drugs began to take hold. I remember saying something like "I feel a
bit lightheaded; maybe you should drive. . . ." And suddenly there was a
terrible roar all around us and the sky was full of what looked like huge
bats, all swooping and screeching and diving around the car, which was
going about a hundred miles an hour with the top down to Las Vegas. And
a voice was screaming: "Holy Jesus! What are these goddamn animals?"
Then it was quiet again. My attorney had taken his shirt off and was
pouring beer on his chest, to facilitate the tanning process. "What the
hell are you yelling about?" he muttered, staring up at the sun with his
eyes closed and covered with wraparound Spanish sunglasses. "Never mind,"
I said. "It's your turn to drive." I hit the brakes and aimed the Great
Red Shark toward the shoulder of the highway. No point mentioning those
bats, I thought. The poor bastard will see them soon enough.
It was almost noon, and we still had more than a hundred miles to go. They
would be tough miles. Very soon, I knew, we would both be completely
twisted. But there was no going back, and no time to rest. We would
have to ride it out. Press registration for the fabulous Mint 400 was
already underway, and we had to get there by four to claim our sound -
proof suite. A fashionable sporting magazine in New York had taken care
of the reservations, along with this huge red Chevy convertible we'd
just rented off a lot on the Sunset Strip . . . and I was, after all,
a professional journalist; so I had an obligation to cover the story,
for good or ill.
The sporting editors had also given me $300 in cash, most of which was
already spent on extremely dangerous drugs. The trunk of the car looked
like a mobile police narcotics lab. We had two bags of grass, seventy -
five pellets of mescaline, five sheets of high - powered blotter acid,
a salt shaker half full of cocaine, and a whole galaxy of multi - colored
uppers, downers, screamers, laughers and also a quart of tequila, a quart
of rum, a case of Budweiser, a pint of raw ether and two dozen amyls.All
this had been rounded up the night before, in a frenzy of high - speed
driving all over Los Angeles County - from Topanga to Watts, we picked
up everything we could get our hands on. Not that we needed all that
for the trip, but once you get locked into a serious drug collection,
the tendency is to push it as far as you can.
The only thing that really worried me was the ether. There is nothing
in the world more helpless and irresponsible and depraved than a man
in the depths of an ether binge. And I knew we'd get into that rotten
stuff pretty soon. Probably at the next gas station. We had sampled
almost everything else, and now - yes, it was time for a long snort
of ether. And then do the next hundred miles in a horrible, slobbering
sort of spastic stupor. The only way to keep alert on ether is to do up
a lot of amyls - not all at once, but steadily, just enough to maintain
the focus at ninety miles an hour through Barstow.
"Man, this is the way to travel," said my attorney. He leaned over to
turn the volume up on the radio, humming along withthe rhythm section
and kind of moaning the words: "One toke over the line, Sweet Jesus
. . . One toke over the line . . . " 
One toke? You poor fool! Wait till you see those goddamn bats. I could
barely hear the radio . . . slumped over on the far side of the seat,
grappling with a tape recorder turned all the way up on "Sympathy for the
Devil." That was the only tape we had, so we played it constantly, over
and over, as a'kind of demented counterpoint to the radio. And also to
maintain our rhythm on the road. A constant speed is good for gas mileage
- and for some reason that seemed important at the time. Indeed. On a
trip like this one must be careful about gas consumption. Avoid those
quick bursts of acceleration that drag blood to the back of the brain.
My attorney saw the hitchhiker long before I did. "Let's give this boy
a lift," he said, and before I could mount any argument he was stopped
and this poor Okie kid was running up to the car with a big grin on his
face, saying, "Hot damn! I never rode in a convertible before!"
"Is that right?" I said. "Well, I guess you're about ready, eh?"
The kid nodded eagerly as we roared off.
"We're your friends," said my attorney. "We're not like the others."
"0 Christ, I thought, he's gone around the bend. "No more of that talk,"
I said sharply. "Or I'll put the leeches on you." He grinned, seeming
to understand. Luckily, the noise in the car was so awful - between the
wind and the radio and the tape machine - that the kid in the back seat
couldn't hear a word we were saying. Or could he?
How long can we maintain? I wondered. How long before one of us starts
raving and jabbering at this boy? What will he think then? This same
lonely desert was the last known home of the Manson family. Will he make
that grim connection when my attorney starts screaming about bats and
huge manta rays coming down on the car? If so - well, we'll just have to
cut his head off and bury him somewhere. Because it goes without saying
that we can't turn him loose. He'll report us at once to some kind of
outback nazi law enforcement agency, and they'll run us down like dogs.
Jesus! Did I say that? Or just think it? Was I talking? Did they hear
me? I glanced over at my attorney, but he seemed oblivious - watching
the road, driving our Great Red Shark along at a hundred and ten or
so. There was no sound from the back seat.Maybe I'd better have a chat
with this boy, I thought. Perhape if I explain things, he'll rest easy.
Of course. I leaned around in the seat and gave him a fine big smile
. . . admiring the shape of his skull."By the way," I said. "There's
one thing you should probably understand."
He stared at me, not blinking. Was he gritting his teeth?
"Can you hear me?" I yelled.
He nodded.
"That's good," I said. "Because I want you to know that we're on our
way to Las Vegas to find the American Dream." I smiled. "That's why we
rented this car. It was the only way to do it. Can you grasp that?"
He nodded again, but his eyes were nervous.
"I want you to have all the background," I said. "Because this
is a very ominous assignment - with overtones of extreme personal
danger. . . . Hell, I forgot all about this beer; you want one?"
He shook his head.
"How about some ether?" I said.
"What?"
"Never mind. Let's get right to the heart of this thing. You see, about
twenty - four hours ago we were sitting in the Polo Lounge of the Beverly
Hills Hotel - in the patio section, of course - and we were just sitting
there under a palm tree when this uniformed dwarf came up to me with a
pink telephone and said, 'This must be the call you've been waiting for
all this time, sir.'"
I laughed and ripped open a beer can that foamed all over the back seat
while I kept talking. "And you know? He was right! I'd been expecting
that call, but I didn't know who it would come from. Do you follow me?"
The boy's face was a mask of pure fear and bewilderment. I blundered on:
"I want you to understand that this man at the wheel is my attorney! He's
not just some dingbat I found on the Strip. Shit, look at him! He doesn't
look like you or me, right? That's because he's a foreigner. I think he's
probably Samoan. But it doesn't matter, does it? Are you prejudiced?"
"Oh, hell no!" he blurted.
"I didn't think so," I said. "Because in spite of his race, this man is
extremely valuable to me." I glanced over at my attorney, but his mind
was somewhere else.
I whacked the back of the driver's seat with my fist. "This is important,
goddamnit! This is a true story!" The car swerved sickeningly, then
straightened out. "Keep your hands off my fucking neck!" my attorney
screamed. The kid in the back looked like he wasready to jump right
out of the car and take his chances.Our vibrations were getting nasty -
but why? I was puzzled, frustrated. Was there no communication in this
car? Had we deteriorated to the level of dumb beasts?
Because my story was true. I was certain of that. And it was extremely
important, I felt, for the meaning of our journey to be made absolutely
clear. We had actually been sitting there in the Polo Lounge - for
many hours - drinking Singapore Slings with mescal on the side and beer
chasers. And when the call came, I was ready.
The Dwark approached our table cautiously, as I recall, and when he
handed me the pink telephone I said nothing, merely listened. And then
I hung up, turning to face my attorney. 
"That was headquarters," I said. "They want me to go to Las 
Vegas at once, and make contact with a Portuguese photographer named
Lacerda. He'll have the details. All I have to do is check into my suite
and he'll seek me out."
My attorney said nothing for a moment, then he suddenly came alive in
his chair. "God hell!" he exclaimed. "I think I see the pattern. This
one sounds like real trouble!" He tucked his khaki undershirt into his
white rayon bellbottoms and called for more drink. "You're going to need
plenty of legal advice before this thing is over," he said. "And my first
advice is that you should rent a very fast car with no top and get the
hell out of L.A. for at least forty - eight hours." He shook his head
sadly. "This blows my weekend, because naturally I'll have to go with
you - and we'll have to ann ourselves."
"Why not?" I said. "If a thing like this is worth doing at all, it's
worth doing right. We'll need some decent equipment and plenty of cash
on the line - if only for drugs and a super - sensitive tape recorder,
for the sake of a permanent record."
"What kind of a story is this?" he asked.
"The Mint 400," I said. "It's the richest off - the - road race for
motorcycles and dune - buggies in the history of organized sport - a
fantastic spectacle in honor of some fatback grossero named Del Webb,
who owns the luxurious Mint Hotel in the heart of downtown Las Vegas
. . . at least that's what the press release says; my man in New York
just read it to me."
"Well," he said, "as your attorney I advise you to buy a motorcycle. How
else can you cover a thing like this righteously?"
"No way," I said. "Where can we get hold of a Vincent Black Shadow?"
"What's that?"
"A fantastic bike," I said. "The new model is something like two thousand
cubic inches, developing two hundred brake - horsepower at four thousand
revolutions per minute on a magnesium frame with two styrofoam seats
and a total curb weight of exactly two hundred pounds."
"That sounds about right for this gig," he said.
"It is" I assured him. "The fucker's not much for turning, but it's pure
hell on the straightaway. It'll outrun the F - ill until takeoff."
"Takeoff?" he said. "Can we handle that much torque?"
"Absolutely," I said. "I'll call New York for some cash."
 
2. The Seizure of $300 from a Pig Woman In Beverly Hills
 
The New York office was not familiar with the Vincent Black Shadow:
they referred me to the Los Angeles bureau - which is actually in Beverly
Hills just a few long blocks from the Polo Lounge - but when I got there,
the money - woman refused to give me more than $300 in cash. She had
no idea who I was, she said, and by that time I was pouring sweat. My
blood is too thick for California: I have never been able to properly
explain myself in this climate. Not with the soaking sweats . . . wild
red eyeballs and trembling hands.
So I took the $300 and left. My attorney was waiting in a bar around the
corner. "This won't make the nut," he said, "unless we have unlimited
credit."
I assured him we would. "You Samoans are all the same," I told him. "You
have no faith in the essential decency of the white man's culture. Jesus,
just one hour ago we were sitting over there in that stinking baiginio,
stone broke and paralyzed for the weekend, when a call comes through
from some total stranger in New York, telling me to go to Las Vegas and
expenses be damned - and then he sends me over to some office in Beverly
Hills where another total stranger gives me $300 raw cash for no reason at
all . . . I tell you, my man, this is the American Dream in action! We'd
be fools not to ride this strange torpedo all the way out to the end."
"Indeed," he said. "We must do it."
"Right," I said. "But first we need the car. And after that, the
cocaine. And then the tape recorder, for special music, and some Acapulco
shirts." The only way to prepare for a trip like this, I felt, was to
dress up like human peacocks and get crazy, then screech off across the
desert and cover the stary. 
Never lose sight of the primary responsibility. But what was the
story? Nobody had bothered to say. So we would have to drum it up on
our own. Free Enterprise. The American Dream. Horatio Alger gone mad on
drugs in Las Vegas. Do it now: pure Gonzo journalism.
There was also the socio - psychic factor. Every now and then when your
life gets complicated and the weasels start closing in, the only real
cure is to load up on heinous chemicals and then drive like a bastard
from Hollywood to Las Vegas. To relax, as it were, in the womb of the
desert sun. Just roll the roof back and screw it on, grease the face
with white tanning butter and move out with the music at top volume,
and at least a pint of ether.
Getting hold of the drugs had been no problem, but the car and the tape
recorder were not easy things to round up at 6:30 on a Friday afternoon
in Hollywood. I already had one car, but it was far too small and slow
for desert work. We went to a Polynesian bar, where my attorney made
seventeen calls before locating a convertible with adequate horsepower
and proper coloring.
"Hang onto it," I heard him say into the phone. "We'll be over to make
the trade in thirty minutes." Then after a pause, he began shouting:
"What? Of course the gentleman has a major credit card! Do you realize
who the fuck you're talking to?"
"Don't take any guff from these swine," I said as he slammed the phone
down. "Now we need a sound store with the finest equipment. Nothing
dinky. We want one of those new Belgian Heliowatts with a voice -
activated shotgun mike, for picking up conversations in oncoming cars."
We made several more calls and finally located our equip - ment in
a store about five miles away. It was closed, but the salesman said
he would wait, if we hurried. But we were de - layed en route when a
Stingray in front of us killed a pedestrian on Sunset Boulevard. The
store was closed by the time we got there. There were people inside,
but they refused to come to the double - glass door until we gave it a
few belts and made ourselves clear.
Finally two salesmen brandishing tire irons came to the door and we
managed to negotiate the sale through a tiny slit. Then they opened the
door just wide enough to shove the equipment out, before slamming and
locking it again. "Now take that stuff and get the hell away from here,"
one of them shouted through the slit.
My attorney shook his fist at them. "We'll be back," he yelled. "One of
these days I'll toss a fucking bomb into this place! I have your name on
this sales slip! I'll find out where you live and burn your house down!"
"That'll give him something to think about," he muttered as we drove
off. "That guy is a paranoid psychotic, anyway. They're easy to spot."
We had trouble, again, at the car rental agency. After signing all the
papers, I got in the car and almost lost control of it while backing
across the lot to the gas pump. The rental - man was obviously shaken.
"Say there . . . uh . . . you fellas are going to be careful with this
car, aren't you?"
"Of course."
"Well, good god!" he said. "You just backed over that two - foot concrete
abutment and you didn't even slow down! Forty - five in reverse! And
you barely missed the pump!"
"No harm done," I said. "I always test a transmission that way. The rear
end. For stress factors."
Meanwhile, my attorney was busy transferring rum and ice from the Pinto ~
the back seat of the convertible. The rental - man watched him nervously.
"Say," he said. "Are you fellas drinking?"
"Not me," I said.
"Just fill the goddamn tank," my attorney snapped. "We're in a hell of
a hurry. We're on our way to Las Vegas for a desert race.
"What?"
"Never mind," I said. "We're responsible people." I watched him put the
gas cap on, then I jammed the thing into low gear and we lurched into
traffic.
"There's another worrier," said my attorney. "He's prob - ably all
cranked up on speed."
"Yeah, you should have given him some reds."
"Reds wouldn't help a pig like that," he said. "To hell with him. We
have a lot of business to take care of, before we can get on the road."
"I'd like to get hold of some priests' robes," I said. "They might come
in handy in Las Vegas."
But there were no costume stores open, and we weren't up to burglarizing
a church. "Why bother?" said my attorney. 
"And you have to remember that a lot of cops are good vicious
Catholics. Can you imagine what those bastards would do to us if we got
busted all drugged - up and drunk in stolen investments? Jesus, they'd
castrate us!"
"You're right," I said. "And for christ's sake don't smoke that pipe at
stoplights. Keep in mind that we're exposed."
He nodded. "We need a big hookah. Keep it down here on the seat, out of
sight. If anybody sees us, they'll think we're using oxygen."
We spent the rest of that night rounding up materials and packing the
car. Then we ate the mescaline and went swimming in the ocean. Somewhere
around dawn we had breakfast in a Malibu coffee shop, then drove very
carefully across town and plunged onto the smog - shrouded Pasadena
Freeway, heading East.
 
3. Strange Medicine On The Desert . . . A Crisis Of Confidence
 
I am still vaguely haunted by our hitchhiker's remark about how he'd
"never rode in a convertible before." Here's this poor geek living in
a world of convertibles zipping past him on the highways all the time,
and he's never even ridden in one. It made me feel like King Farouk. I
was tempted to have my attorney pull into the next airport and arrange
some kind of simple, common - law contract whereby we could just give
the car to this unfortunate bastard. Just say: "Here, sign this and
the car's yours." Give him the keys and then use the credit card to zap
off on a jet to some place like Miami and rent another huge fireapple -
red convertible for a drug - addled, top - speed run across the water
all the way out to the last stop in Key West . . . and then trade the
car off for a boat. Keep moving.
But this manic notion passed quickly. There was no point in getting this
harmless kid locked up - and, besides, I had plans for this car. I was
looking forward to flashing around Las Vegas in the bugger. Maybe do a
bit of serious drag - racing on the Strip: Pull up to that big stoplight
in front of the Flamingo and start screaming at the traffic:
"Alright, you chickenshit wimps! You pansies! When this goddamn light
flips green, I'm gonna stomp down on this thing and blow every one of
you gutless punks off the road!"
Right. Challenge the bastards on their own turf. Come Screeching up to
the crosswalk, bucking and skidding with a bottle of rum in one hand and
jamming the horn to drown out the music . . . glazed eyes insanely dilated
behind tiny black, gold - rimmed greaser shades, screaming gibberish..,
a genuinely dangerous drunk, reeking of ether and terminal psychosis. 
Revving the engine up to a terrible high - pitched chattering whine,
waiting for the light to change . . . 
How often does a chance like that come around? To jangle the bastards
right down to the core of their spleens. Old elephants limp off to the
hills to die; old Americans go out to the highway and drive themselves
to death with huge cars.
But our trip was different. It was a classic affirmation of everything
right and true and decent in the national character. It was a gross,
physical salute to the fantastic possibilities of life in this country -
but only for those with true grit. And we were chock full of that.
My attorney understood this concept, despite his racial handicap, but
our hitchhiker was not an easy person to reach. He said he understood,
but I could see in his eyes that he didn't. He was lying to me.
The car suddenly veered off the road and we came to a sliding halt in
the gravel. I was hurled against the dashboard. My attorney was slumped
over the wheel. "What's wrong?" I yelled. "We can't stop here. This is
bat country!"
"My heart," he groaned. "Where's the medicine?"
"Oh," I said. "The medicine, yes, it's right here." I reached into
the kit - bag for the amyls. The kid seemed petrified. "Don't worry,"
I said. "This man has a bad heart - Angina Pectoris. 
But we have the cure for it. Yes, here they are." I picked four amyls
out of the tin box and handed two of them to my attorney. He immediately
cracked one under his nose, and I did likewise.
He took a long snort and fell back on the seat, staring straight up at
the sun. "Turn up the fucking music!" he screamed. "My heart feels like
an alligator!
"Volume! Clarity! Bass! We must have bass!" He flailed his naked arms
at the sky. "What's wrong with us? Are we god - damn old ladies?"
I turned both the radio and the tape machine up full bore. "You scurvy
shyster bastard," I said. "Watch your language! You're talking to a
doctor of journalism!"
He was laughing out of control. "What the fuck are we doing out here on
this desert?" he shouted. "Somebody call the police! We need help!"
"Pay no attention to this swine," I said to the hitchhiker. "He can't
handle the medicine. Actually, we're both doctors of journalism, and we're
on our way to Las Vegas to cover the main story of our generation." And
then I began laughing . . . .
My attorney hunched around to face the hitchhiker. "The truth is," he
said, "we're going to Vegas to croak a scag baron named Savage Henry. I've
known him for years, but he ripped us off - and you know what that means,
right?"
I wanted to shut him off, but we were both helpless with laughter. What
the fuck were we doing out here on this desert, when we both had bad
hearts?
"Savage Henry has cashed his check!" My attorney snarled at the kid in
the back seat. "We're going to rip his lungs out!"
"And eat them!" I blurted. "That bastard won't get away with this! What's
going on in this country when a scumsucker like that can get away with
sandbagging a doctor of journalism?"
Nobody answered. My attorney was cracking another amyl and the kid was
climbing out of the back seat, scrambling down the trunk lid. "Thanks
for the ride," he yelled. "Thanks a lot. I like you guys. Don't worry
about me." His feet hit the asphalt and he started running back towards
Baker. Out in the middle of the desert, not a tree in sight.
Wait a minute," I yelled. "Come back and get a beer." But apparently he
couldn't hear me. The music was very loud, and he was moving away from
us at good speed.
"Good riddance," said my attorney. "We had a real freak on our
hands. That boy made me nervous. Did you see his eyes?" He was still
laughing. "Jesus," he said. "This is good medicine!"
I opened the door and reeled around to the driver's side. "Move over,"
I said. "I'll drive. We have to get out of Califor - nia before that
kid finds a cop."
"Shit, that'll be hours," said my attorney. "He's a hundred miles from
anywhere."
"So are we," I said.
"Let's turn around and drive back to the Polo Lounge," he said. "They'll
never look for us there."
I ignored him. "Open the tequila," I yelled as the wind - scream took
over again; I stomped on the accelerator as we hurtled back onto the
highway. Moments later he leaned over with a map. "There's a place up
ahead called Mescal Springs," he said. "As your attorney, I advise you
to stop and take a swim.
I shook my head. "It's absolutely imperative that we get to the Mint
Hotel before the deadline for press registration," I said. "Otherwise,
we might have to pay for our suite."
He nodded. "But let's forget that bullshit about the American Dream," he
said. "The important thing is the Great Samoan Dream." He was rummaging
around in the kit - bag. 
"I think it's about time to chew up a blotter," he said. "That cheap
mescaline wore off a long time ago, and I don't know if 1 can stand the
smell of that goddamn ether any longer."
"I like it," I said. "We should soak a towel with the stuff and then put
it down on the floorboard by the accelerator so the fumes will rise up
in my face all the way to Las Vegas."
He was turning the tape cassette over. The radio was screaming:
"Power to the People - Right On!" John Lennon's political song, ten
years too late. "That poor fool should have stayed where he was," said
my attorney. "Punks like that just get in the way when they try to be
serious."
"Speaking of serious," I said. "I think it's about time to get into the
ether and the cocaine."
"Forget ether," he said. "Let's save it for soaking down the rug in the
suite. But here's this. Your half of the sunshine blotter. Just chew it
up like baseball gum."
I took the blotter and ate it. My attorney was now fumbling with the salt
shaker containing the cocaine. Opening it. Spilling it. Then screaming
and grabbing at the air, as our fine white dust blew up and out across
the desert highway. A very expensive little twister rising up from the
Great Red Shark. 
"Oh, Jesus!" he moaned. "Did you see what God just did to us?"
"God didn't do that!" I shouted. "You did it. You're a fucking narcotics
agent! I was on to your stinking act from the start, you pig!"
"You better be careful," he said. And suddenly he was waving a fat black
.357 magnum at me. One of those snubnosed Colt Python 5 with the beveled
cylinder. "Plenty of vultures out here," he said. "They'll pick your
bones clean before morning."
"You whore" I said. "When we get to Las Vegas I'll have you chopped into
hamburger. What do you think the Drug Bund will do when I show up with
a Samoan narcotics agent?"
"They'll kill us both," he said. "Savage Henry knows who I am. Shit,
I'm your attornney" He burst into wild laughter.
"You're full of acid, you fool. It'll be a goddamn miracle if we can
get to the hotel and check in before you turn into a wild animal. Are
you ready for that? Checking into a Vegas hotel under a phony name with
intent to commit capital fraud and a head full of acid?" He was laughing
again, then he jammed his nose down toward the salt shaker, aiming the
thin green roll of a $20 bill straight into what was left of the powder.
"How long do we have?" I said.
"Maybe thirty more minutes," he replied. "As your attorney I advise you
to drive at top speed."
Las Vegas was just up ahead. I could see the strip/hotel skyline looming
up through the blue desert ground - haze: The Sahara, the landmark, the
Americana and the ominous Thunderbird - a cluster of grey rectangles in
the distance, rising out of the cactus.
Thirty minutes. It was going to be very close. The objective was the big
tower of the Mint Hotel, downtown - and if we didn't get there before we
lost all control, there was also the Nevada State prison upstate in Carson
City. I had been there once, but only for a talk with the prisoners -
and I didn't want to go back, for any reason at all. So there was really
no choice: 
We would have to run the gauntlet, and acid be damned. Go through all
the official gibberish, get the car into the hotel garage, work out on
the desk clerk, deal with the bellboy, sign in for the press passes -
all of it bogus, totally illegal, a fraud on its face, but of course it
would have to be done.
 
"KILL THE BODY AND THE HEAD WILL DIE"
 
This line appears in my notebook, for some reason. Perhaps some connection
with Joe Frazier. Is he still alive? Still able to talk? I watched that
fight in Seattle - horribly twisted about four seats down the aisle from
the Governor. A very painful experience in every way, a proper end to the
sixties Tim Leary a prisoner of Eldridge Cleaver in Algeria, Bob Dylan
clipping coupons in Greenwich Village, both Kennedysmurdered by mutants,
Owsley folding napkins on Terminal Island, and finally Cassius/Ali belted
incredibly off his pedestal by a human hamburger, a man on the verge of
death. Joe Frazier, like Nixon, had finally prevailedfor reasons that
people like me refused to understand - at least not out loud.
But that was some other era, burned out and long gone from the brutish
realities of this foul year of Our Lord, 1971. A lot of things had changed
in those years. And now I was in Las Vegas as the motor sports editor of
this fine slick magazine that had sent me out here in the Great Red Shark
for some reason that nobody claimed to understand. "Just check it out,"
they said, "and we'll take it from there.
Indeed. Check it out. But when we finally arrived at the Mint Hotel my
attorney was unable to cope artfully with the registration procedure. We
were forced to stand in line with all the others - which proved to be
extremely difficult under the circumstances. I kept telling myself:
"Be quiet, be calm, say nothing . . . speak only when spoken to: name,
rank and press affiliation, nothing else, ignore this terrible drug,
pretend it's not happening. . .There is no way to explain the terror I
felt when I finally lunged up to the clerk and began babbling. All my
well - re - hearsed lines fell apart under that woman's stoney glare. "Hi
there," I said. "My name is . . . ah, Raoul Duke . . . yes, on the list,
that's for sure. Free lunch, final wisdom, total coverage. . . . why
not? I have my attorney with me and I realize of course that his name is
not on the list, but we must have that suite, yes, this man is actually
my driver. We brought this Red Shark all the way from the Strip and now
it's time for the desert, right? Yes. Just check the list and you'll
see. Don't worry. What's the score here? What's next?"
The woman never blinked. "Your room's not ready yet," she said. "But
there's somebody looking for you."
"No!" I shouted. "Why? We haven't done anything yet!" My legs felt
rubbery. I gripped the desk and sagged toward her as she held out the
envelope, but I refused to accept it. The Woman's face was changing:
swelling, pulsing . . . horrible green jowls and fangs jutting out, the
face of a Moray Eel! Deadly poison! I lunged backwards into my attorney,
who gripped my arm as he reached out to take the note. "I'll handle this,"
he said to the Moray woman. 
"This man has a bad heart, but I have plenty of medicine. My name is
Doctor Gonzo. Prepare our suite at once. We'll be in the bar."
The woman shrugged as he led me away. In a town full of bedrock crazies,
nobody even notices an acid freak. 
We struggled through the crowded lobby and found two stools at the bar. My
attorney ordered two cuba libres with beer and mescal on the side, then
he opened the envelope. "Who's Lacerda?" he asked. "He's waiting for us
in a room on the twelfth floor."
I couldn't remember. Lacerda? The name rang a bell, but I couldn't
concentrate. Terrible things were happening all around us. Right next to
me a huge reptile was gnawing on a woman's neck, the carpet was a blood -
soaked sponge - impossible to walk on it, no footing at all. "Order some
golf shoes," I whispered. "Otherwise, we'll never get out of this place
alive. You notice these lizards don't have any trouble moving around in
this muck - that's because they have claws on their feet."
"Lizards?" he said. "If you think we're in trouble now, wait till you see
what's happening in the elevators." He took off his Brazilian sunglasses
and I could see he'd been crying. "I just went upstairs to see this man
Lacerda," he said. "I told him we knew what he was up to. He says he's
a photographer, but when I mentioned Savage Henry - well, that did it;
he freaked. I could see it in his eyes. He knows we're onto him."
"Does he understand we have magnums?" I said.
"No. But I told him we had a Vincent Black Shadow. That scared the piss
out of him."
"Good," I said. "But what about our room? And the golf shoes? We're
right in the middle of a fucking reptile zoo! And somebody's giving
booze to these goddamn things! It won't be long before they tear us to
shreds. Jesus, look at the floor! Have you ever seen so much blood? How
many have theykilled already?" I pointed across the room to a group
that seemed to be staring at us. "Holy shit, look at that bunch over
there! They've spotted us!"
"That's the press table," he said. "That's where you have to sign in
for our credentials. Shit, let's get it over with. You handle that,
and I'll get the room."
 
4. Rude Music And The Sound Of Many Shotguns . . . Rude Vibes On A
Saturday Evening In Vegas
 
We finally got into the suite around dusk, and my attorney was immediately
on the phone to room service - ordering four club sandwiches, four
shrimp cocktails, a quart of rum and nine fresh grapefruits. "Vitamin C,"
he explained. "We'll need all we can get."
I agreed. By this time the drink was beginning to cut the acid and my
hallucinations were down to a tolerable level. The room service waiter had
a vaguely reptilian cast to his features, but I was no longer seeing huge
pterodactyls lumbering around the corridors in pools of fresh blood. 
The only problem now was a gigantic neon sign outside the window,
blocking our view of the mountains - millions of colored balls running
around a very complicated track, strange symbols & filigree, giving off
a loud hum.
"Look outside," I said.
"Why?"
"There's a big .. . machine in the sky, . . . some kind of electric
snake . . . coming straight at us."
"Shoot it," said my attorney.
"Not yet," I said. "I want to study its habits." He 
went over to the corner and began pulling on a chain todrapes. "Look,"
he said, "you've got to stop this talk snakes and leeches and lizards
and that stuff. It's making me sick."
"Don't worry," I said.
"Worry? Jesus, I almost went crazy down there in the bar. They'll never
let us back in that place - not after your 
scene at the press table."
"What scene?"
"You bastard," he said. "I left you alone for three minutes! You scared
the shit out of those people! Waving that goddamn marlin spike around
and yelling about reptiles. You're lucky I came back in time. They were
ready to call the cops. I said you were only drunk and that I was taking
you up to your room for a cold shower. Hell,the only reason they gave
us the press passes was to get you out of there."
He was pacing around nervously. "Jesus, that scene straightened me right
out! I must have some drugs. What have you done with the mescaline?"
"The kit - bag," I said.
He opened the bag and ate two pellets while I got the tape machine
going. "Maybe you should only eat one of these," he said. "That acid's
still working on you."
I agreed. "We have to go out to the track before dark," I said. "But we
have time to watch the TV news. Let's carve up this grapefruit and make
a fine rum punch, maybe toss in a blotter . . . where's the car?"
"We gave it to somebody in the parking lot," he said. "I have the ticket
in my briefcase."
"What's the number? I'll call down and have them wash the bastard,
get rid of that dust and grime."
"Good idea," he said. But he couldn't find the ticket.
"Well, we're fucked," I said. "We'll never convince them to give us that
car without proof."
He thought for a moment, then picked up the phone and asked for the
garage. "This is Doctor Gonzo in eight fifty," he said. "I seem to have
lost my parking stub for that red convertible I left with you, but I
want the car washed and ready to go in thirty minutes. Can you send
up a duplicate stub? . . . What . . . Oh? . . . Well, that's fine." He
hung up and reached for the hash pipe. "No problem," hesaid. "That man
remembers my face."
"That's good," I said. "They'll probably have a big net for us when we
show up."shook his head. "As your attorney, I advise you not to about
me."
The TV news was about the Laos Invasion - a series of horrifying
disasters: explosions and twisted wreckage, men fleeing in terror,
Pentagon generals babbling insane lies. 
"Turn that shit off!" screamed my attorney "Let's get out of here!"
A wise move. Moments after we picked up the car my attorney went into
a drug coma and ran a red light on Main Street before I could bring us
under control. I propped him up in the passenger seat and took the wheel
myself . . . feeling fine, extremely sharp. All around me in traffic I
could see people talking and I wanted to hear what they were saying. All
of them. But the shotgun mike was in the trunk and I decided to leave
it there. Las Vegas is not the kind of town where you want to drive down
Main Street aiming a black bazooka - looking instrument at people.Turn up
the radio. Turn up the tape machine. Look into the sunset up ahead. Roll
the windows down for a better taste of the cool desert wind. Ah yes. This
is what it's all about. Total control now. Tooling along the main drag
on a Saturday night in Las Vegas, two good old boys in a fireapple -
red convertible . . . stoned, ripped, twisted . . . Good People.
Great God! What is this terrible music?
"The Battle Hymn of Lieutenant Galley":
 
" . . . as we go marching on
When I reach my final campground, in that land 
beyond the sun,
and the Great Commander asks me . . . "
(What did he ask you, Rusty?)
"Did you fight or did you run?"
(and what did you tell him, Rusty?)
" . . . We responded to their rifle fire with everything we had . . . "
 
No! I can't be hearing this! It must be the drug. I glanced over at my
attorney, but he was staring up at the sky, and I could see that his
brain had gone off to that campground 
beyond the sun. Thank christ he can't hear this music, I thought. It
would drive him into a racist frenzy.
Mercifully, the song ended. But my mood was already shattered . . . and
now the fiendish cactus juice took over, plunging me into a sub - human
funk as we suddenly came up on the turnoff to the Mint Gun Club. "One
mile," the sign said. But even a mile away I could hear the crackling
scream of two - stroke bike engines winding out . . . and then, coming
closer, I heard another sound.
Shotguns! No mistaking that fiat hollow boom.
I stopped the car. What the hell is going on down there? 
I rolled up all the windows and eased down the gravel road, hunched low
on the wheel . . . until I saw about a dozen figures pointing shotguns
into the air, firing at regular intervals.
Standing on a slab of concrete out here in the mesquite - desert,
this scraggly little oasis in a wasteland north of Vegas . . They were
clustered, with their shotguns, about fifty yards away from a one -
story concrete/block - house, half - shaded by ten or twelve trees and
surrounded by cop - cars, bike - trailers and motorcycles.
Of course. The Mint Gun Club! These lunatics weren't letting anything
interfere with their target practice. Here were about a hundred bikers,
mechanics and assorted motorsport types milling around in the pit area,
signing in for tomorrow's race, idly sipping beers and appraising each
other's machinery - and right in the middle of all this, oblivious to
everything but the clay pigeons flipping out of the traps every five
seconds or so, the shotgun people never missed a beat.
Well, why not? I thought. The shooting provided a certain rhythm -
sort of a steady bass - line - to the high - pitched chaos of the bike
scene. I parked the car and wandered into the crowd, leaving my attorney
in his coma.
I bought a beer and watched the bikes checking in. Many
Husquavarnas, high - tuned Swedish fireballs . . . also Yamahas,
Kawasakis, a few 500 Triumphs, Maicos, & there a CZ, a Pursang . . . all
very fast, super - light dfrt bikes. No Hogs in this league, not even a
Sportster . . . that would be like entering our Great Red Shark in the
dune buggy competition.
Maybe I should do that, I thought. Sign my attorney up as the driver,
then send him out to the starting line with a head full of ether and
acid. How would they handle it?Nobody would dare go out on the track
with a person that crazy. He would roll on the first turn, and take out
four or five dune buggies - a Kamikaze trip.
"What's the entry fee?" I asked the desk - man.
"Two fifty," he said.
"What if I told you I had a Vincent Black Shadow?"He stared up at me,
saying nothing, not friendly. I noticed he was wearing a .38 revolver
on his belt. "Forget it," I said. "My driver's sick, anyway."
His eyes narrowed. "Your driver ain't the only one sick around here,
buddy."
"He has a bone in his throat," I said.
"What?"
The man was getting ugly, but suddenly his eyes switched away. He was
staring at something else
My attorney no longer wearing his Danish sunglasses, no longer wearing
his Acapulco shirt . . . a very crazy looking ,half - naked and breathing
heavily.
"What's the trouble here?" he croaked. "This man is my client - Are
you prepared to go to court?" grabbed his shoulder and gently spun him
around. 
"Never " I said. "It's the Black Shadow - they won't accept it." 
"Wait a minute!" he shouted. "What do you mean, they won't accept it? Have
you made a deal with these pigs?"
"Certainly not," I said, pushing him along toward the gate. "But you
notice they're all armed. We're the only people here without guns. Can't
you hear that shooting over there?"
He paused, listened for an instant, then suddenly began,running toward the
car. "You cocksuckers!" he screamed over his shoulder. "We'll be back!"
By the time we got the shark back on the highway he was able to
talk. "Jesus christ! How did we get mixed up with that gang of psychotic
bigots? Let's get the fuck out of this town. Those scumbags were trying
to kill us!
 
5.Covering the Story . . . A Glimpse of the Press in Action . . . Ugliness
& Failure
 
The racers were ready at dawn. Fine sunrise over the desert. Very
tense. But the race didn't start until nine, so we had to kill about
three long hours in the casino next to the pits, and that's where the
trouble started.
The bar opened at seven. There was also a "koffee & donut canteen"
in the bunker, but those of us who had been up all night in places like
the Circus - Circus were in no mood for coffee & donuts. We wanted strong
drink. Our tempers were ugly and there were at least two hundred of us, so
they opened the bar early. By eight - thirty there were big crowds around
the crap - tables. The place was full of noise and drunken shouting.
A boney, middle - aged hoodlum wearing a Harley - Davidson T - shirt
boomed up to the bar and yelled: "God damn! What day is this - Saturday?"
"More like Sunday," somebody replied.
"Hah! That's a bitch, ain't it?" the H - D boomer shouted to nobody in
particular. "Last night I was out home in Long and somebody said they
were runnin' the Mint 400 so I says to my old lady, 'Man, I'm goin'." He
laughed.
"So she gives me a lot of crap about it, you know . . . so I started
slappin' her around and the next thing I knew two guys I never even seen
before got me out on the sidewalk workin' me over. Jesus! They beat me
stupid."
He laughed again, talking into the crowd and not seeming listened. 
"Hell yes!" he continued. "Then one of em says, 'Where you going?' And I
says, 'Las Vegas, to the Mint 400.' So they gave me ten bucks and drove
me down to the bus station . . . ." He paused. "At least I think it was
them . . . "
"Well, anyway, here I am. And I tell you that was one hell of a long
night, man! Seven hours on that goddamn bus! But when I woke up it was
dawn and here I was in downtown Vegas and for a minute I didn't know
what the hell I was doin' here. All I could think was, '0 Jesus, here
we go again: Who's divorced me this time?'"
He accepted a cigarette from somebody in the crowd, still grinning as
he lit up. "But then I remembered, by God! I was here for the Mint 400
. . . and, man, that's all I needed to know. I tell you it's wonderful to
be here, man. I don't give a damn who wins or loses. It's just wonderful
to be here with you people.
Nobody argued with him. We all understood. In some circles, the "Mint
400" is a far, far better thing than the Super Bowl, the Kentucky Derby
and the Lower Oakland Roller Derby Finals all rolled into one. This race
attracts a very special breed, and our man in the Harley T - shirt was
clearly one of them.
 
The correspondent from Life nodded sympathetically and screamed at the
bartender: "Senzaman wazzyneeds!"
"Fast up with it," I croaked. "Why not five?" I smacked the bar with my
open, bleeding palm. "Hell yes! Bring us ten!"
"I'll back it!" The Life man screamed. He was losing his grip on the bar,
sinking slowly to his knees, but still speaking with definite authority:
"This is a magic moment in sport! It may never come again!" Then his
voice seemed to break. "I once did the Triple Crown," he muttered. "But
it was nothing like this."
The frog - eyed woman clawed feverishly at his belt. "Stand up!" she
pleaded. "Please stand up! You'd be a very handsome man if you'd just
stand up!"
He laughed distractedly. "Listen, madam," he snapped. "I'm damn near
intolerably handsome down here where I am. You'd go crazy if I stood up!"
The woman kept pulling at him. She'd been mooning at his elbows for two
hours, and now she was making her move. The man from Life wanted no part
of it; he slumped deeper into his crouch.
I turned away. It was too horrible. We were, after all, the absolute
cream of the national sporting press. And we were gathered here in Las
Vegas for a very special assignment: to cover the Fourth Annual "Mint 400"
. . . and when it comes to things like this, you don't fool around.
But now - even before the spectacle got under way - there were signs that
we might be losing control of the situation. Here we were on this fine
Nevada morning, this cool bright dawn on the desert, hunkered down at
some greasy bar in a concrete blockhouse & gambling casino called the
"Mint Gun Club" about ten miles out of Vegas . . . and with the race
about to start, we were dangerously disorganized.
Outside, the lunatics were playing with their motorcycles, taping the
headlights, topping off oil in the forks, last minute bolt - tightening
(carburetor screws, manifold nuts, etc.) and the first ten bikes blasted
off on the stroke of nine. It was extremely exciting and we all went
outside to watch. The flag went down and these ten poor buggers popped
their clutches and zoomed into the first turn, all together, then somebody
grabbed the lead (a 405 Husquavarna, as I recall), and a cheer went up
as the rider screwed it on and disappeared in a cloud of dust.
"Well, that's that," somebody said. "They'll be back around in an hour
or so. Let's go back to the bar."
But not yet. No. There were something like a hundred and ninety more
bikes waiting to start. They went off ten at a time, every two minutes. At
first it was possible to watch them out to a distance of some two hundred
yards from the starting line. But this visibility didn't last long. The
third brace of ten disappeared into the dust about a hundred yards from
where we stood . . . and by the time they'd sent off the first hundred
(with still another hundred to go), our visibility was down to something
like fifty feet. We could see as far as the hay - bales at the end of
the pits . . . 
Beyond that point the incredible dustcloud that would hang over this part
of the desert for the next two days was already formed up solid. None
of us realized, at the time, that this was the last we would see of the
"Fabulous Mint 400" - By noon it was hard to see the pit area from the
bar/casino, one hundred feet away in the blazing sun. The idea of trying
to "cover this race" in any conventional press - sense was absurd: It
was like trying to keep track of a swimming meet in an Olympic - sized
pool filled with talcum powder instead of water. The Ford Motor Company
had come through, as promised, with a "press Bronco" and a driver, but
after a few savage runs across the desert - looking for motorcycles and
occasionally finding one - I abandoned this vehicle to the photographers
and went back to the bar.
It was time, I felt, for an Agonizing Reappraisal of the whole scene. The
race was definitely under way. I had witnessed the start; I was sure of
that much. But what now? Rent a helicopter? Get back in that stinking
Bronco? Wander out on that goddamn desert and watch these fools race
past the checkpoints? One every thirteen minutes. . . .
By ten they were spread out all over the course. It was no longer a
"race"; now it was an Endurance Contest. The only visible action was
at the start/finish line, where every few minutes some geek would
come speeding out of the dustcloud and stagger off his bike, while his
pit crew would gas it up and then launch it back onto the track with a
fresh driver for another fifty - mile lap, another brutal hour of kidney
killing madness out there in that terrible dust - blind limbo.
Somewhere around eleven, I made another tour in the press vehicle, but all
we found were two dune - buggies full of what looked like retired petty
- officers from San Diego. Theycut us off in a dry - wash and demanded,
"Where is the damn thing?"
"Beats me," I said. "We're just good patriotic Americans like
yourselves." Both of their buggies were covered with ominous symbols:
Screaming Eagles carrying American Flags in their claws, a slant - eyed
snake being chopped to bits by a buzz - saw made of stars & stripes,
and one of the vehicles had what looked like a machine - gun mount on
the passenger side.
They were having a bang - up time - just crashing around the desert at top
speed and hassling anybody they met. "What outfit you fellas with?" one
of them shouted. The engines were all roaring; we could barely hear each
other."The sporting press," I yelled. "We're friendlies - hired geeks."
Dim smiles.
"If you want a good chase," I shouted, "you should get after that skunk
from CBS News up ahead in the big black jeep. He's the man responsible
for The Selling Of The Pentagon."
"Hot damn!" two of them screamed at once. "A black jeep, you say?"
They roared off, and so did we. Bouncing across the rocks & scrub
oak/cactus like iron tumbleweeds. The beer in my hand flew up and hit
the top, then fell in my lap and soaked my crotch with warm foam.
"You're fired," I said to the driver. "Take me back to the pits."
It was time, I felt, to get grounded - to ponder this rotten assignment
and figure out how to cope with it. Lacerda insisted on Total Coverage. He
wanted to goback out in the dust storm and keep trying for some rare
combination of film and lense that might penetrate the aweful stuff.
"Joe," our driver, was willing. His name was not really "Joe," but that's
what we'd been instructed to call him. I had talked to the FOMOCO boss
the night before, and when we mentioned the driver he was assigning to
us he said, "His real name is Steve, but you should just call him Joe."
"Why not?" I said, We'll call him anything he wants. How about "Zoom"?"
"No dice," the FOrd man said, "It has to be "Joe".
Lacerda agreed, and sometime around noon he went out on the desert again,
in the company of our driver Joe. I went back to the blockhouse bar/casino
that was actually the Mint Gun Club - where I began to drink heavily,
think heavily, and make many heavy notes . . . 
 
6. A Night on the Town . . . Confrontation at the Desert Inn . . . Drug
Frenzy at the Circus Circus . . . 
 
Saturday midnight . . . Memories of this night are extremely hazy. All I
have, for guide - pegs, is a pocketful of keno cards and cocktail napkins,
all covered with scribbled notes. Here is one: "Get the Ford man, demand
a Bronco for race - observation purposes . .. photos? . . . Lacerda/call
. . . why not a helicopter? . . . Get on the phone, lean on the fuckers
. . . heavy yelling."
Another says: "Sign on Paradise Boulevard - 'Stopless and Topless'
. . . bush - league sex compared to L.A.; pasties here - total
naked public humping in L.A. . . . Las Vegas is a society of armed
masturbators/gambling is the kicker here/sex is extra/weird trip for
high rollers . . . house - whores for winners, hand jobs for the bad
luck crowd."
A long time ago when I lived in Big Sur down the road from Lionel Olay
I had a friend who liked to go to Reno for the crap - shooting. He
owned a sporting - goods store in Carmel. And one month he drove his
Mercedes highway - cruiser to Reno on three consecutive weekends - winning
heavilyinch time. After three trips he was something like $15,000 ahead,
so he decided to skip the fourth weekend and take friends to dinner at
Nepenthe. "Always quit winners," explained. "And besides, it's a long
drive."
On Monday morning he got a phone call from Reno - from the general manager
of the casino he'd been working out on. "We missed you this weekend,"
said the GM. "The pit - men were bored."
"Shucks," said my friend.
So the next weekend he flew up to Reno in a private plane, with a friend
and two girls - all "special guests" of the GM. Nothing too good for
high rollers . . . 
And on Monday morning the same plane - the casino's plane - flew him
back to the Monterey airport. The pilot lent him a dime to call a friend
for a ride to Carmel. He was $30,000 in debt, and two months later he
was looking down the barrel of one of the world's heaviest collection
agendes.
So he sold his store, but that didn't make the nut. They could wait for
the rest, he said - but then he got stomped, which convinced him that
maybe he'd be better off borrowing enough money to pay the whole wad.
Mainline gambling is a very heavy business - and Las Vegas makes Reno
seem like your friendly neighborhood grocery store. For a loser, Vegas
is the meanest town on earth. Until about a year ago, there was a giant
billboard on the outskirts of Las Vegas, saying:
 
DON'T GAMBLE WITH MARIJUANA! 
IN NEVADA: POSSESSION - 20 YEARS SALE - LIFE!
 
So I was not entirely at ease drifting around the casinos on this Saturday
night with a car full of marijuana and head full of acid. We had several
narrow escapes: at one point I tried to drive the Great Red Shark into
the laundry room of the Landmark Hotel - but the door was too narrow,
and the people inside seemed dangerously excited.
 
We drove over to the Desert Inn, to catch the Debbie Reynolds/Harry
James show. "I don't know about you," I told my attorney, "but in my
line of business it's important to be Hep."
"Mine too," he said. "But as your attorney I advise you to drive over
to the Tropicana and pick up on Guy Lombardo. He's in the Blue Room with
his Royal Canadians."
"Why?" I asked.
"Why what?"
"Why should I pay out my hard - earned dollars to watch a fucking
corpse?"
"Look," he said. "Why are we out here? To entertain ourselves, or to do
the job?"
"The job, of course," I replied. We were driving around in circles,
weaving through the parking lot of a place I thought was the Dunes,
but it turned out to be the Thunderbird or maybe it was the Hacienda
My attorney was scanning The Vegas Visitor, looking for hints of
action. "How about "'Nickel Nick's Slot Arcade?'" he said. "'Hot Slots,'
that sounds heavy . . . Twenty - nine cent hotdogs . .
Suddenly people were screaming at us. We were in trouble. Two thugs
wearing red - gold military overcoats were looming over the hood:
"What the hell are you doing?" one screamed. "You can't park here!'
"Why not?" I said. It seemed like a reasonable place to park, plenty of
space. I'd been looking for a parking spot for what seemed like a very
long time. Too long. I was about ready to abandon the car and call a
taxi . . . but then, yes, we found this space.
Which turned out to be the sidewalk in front of the main entrance to
the Desert Inn. I had run over so many curbs by this time, that I hadn't
even noticed this last one. But now we ourselves in a position that was
hard to explain . . . the entrance, thugs yelling at us, bad confusion
. . . . attorney was out of the car in a flash, waving a five - dollar
bill. 
"We want this car parked! I'm an old friend of Debbie's. I used to romp
with her."
For a moment I thought he had blown it . . . then one of the doormen
reached out for the bill, saying: "OK, OK. I'll take care of it, sir." And
he tore off a parking stub.
"Holy shit!" I said, as we hurried through the lobby. 
"They almost had us there. That was quick thinking."
"What do you expect?" he said. "I'm your attorney . . . and you owe me
five bucks. I want it now."
I shrugged and gave him a bill. This garish, deep - orlon carpeted lobby
of the Desert Inn seemed an inappropriate place to be haggling about
nickel/dime bribes for the parking lot attendant. This was Bob Hope's
turf. Frank Sinatra's. Spiro Agnew's. The lobby fairly reeked of high -
grade formica and plastic palm trees - it was clearly a high - class
refuge for Big Spenders.
We approached the grand ballroom full of confidence, but they refused
to let us in. We were too late, said a man in a wine - colored tuxedo;
the house was already full - no seats left, at any price.
"Fuck seats," said my attorney. "We're old friends of Debbie's. We drove
all the way from L.A. for this show, and we're goddamn well going in."
The tux - man began jabbering about "fire regulations," but my attorney
refused to listen. Finally, after a lot of bad noise, he let us in for
nothing - provided we would stand quietly in back and not smoke.
We promised, but the moment we got inside we lost control. The tension
had been too great. Debbie Reynolds was yukking across the stage in a
silver Afro wig . . . to the tune of "Sergeant Pepper," from the golden
trumpet of Harry James.
"Jesus creeping shit!" said my attorney. "We've wandered into a time
capsule!"
Heavy hands grabbed our shoulders. I jammed the hash pipe back into my
pocket just in time. We were dragged across the lobby and held against
the front door by goons until our car was fetched up. "OK, get lost,"
said the wine - tux - man. "We're giving you a break. If Debbie has
friendsIke you guys, she's in worse trouble than I thought."
"We'll see about this!" my attorney shouted as we drove away. "You
paranoid scum!"
I drove around to the Circus - Circus Casino and parked near the back
door. "This is the place," I said. "They'll never fuck with us here."
"Where's the ether?" said my attorney. "This mescaline isn't working."
I gave him the key to the trunk while I lit up the hash pipe. He came
back with the ether - bottle, un - capped it, then poured some into a
kleenex and mashed it under his nose, breathing heavily. I soaked another
kleenex and fouled my own nose. The smell was overwhelming, even with
the top down. Soon we were staggering up the stairs towards the entrance,
laughing stupidly and dragging each other along, like drunks.
This is the main advantage of ether: it makes you behave like the
village drunkard in some early Irish novel . . . total loss of all basic
motor skills: blurred vision, no balance, numb tongue - severance of
all connection between the body and the brain. Which is interesting,
because the brain continues to function more or less normally . . . you
can actually watch yourself behaving in this terrible way, but you can't
controlit.
You approach the turnstiles leading into the Circus - Circus and you
know that when you get there, you have to give the man two dollars or
he won't let you inside . . . but when you get there, everything goes
wrong: you misjudge the distance to the turnstile and slam against it,
bounce off and grab hold of an old woman to keep from falling, some
angry Rotarian shoves you and you think: What's happening here? What's
going on? Then you hear yourself mumbling: "Dogs fucked the Pope, no
fault of mine. Watch out! . . . Why money? My name is Brinks; I was born
. . . born? Get sheep over side . . . women and children to armored car
. . . orders from Captain Zeep."
Ah, devil ether - a total body drug. The mind recoils in horror, unable
to communicate with the spinal column. The hands flap crazily, unable
to get money out of the pocket . . . garbled laughter and hissing from
the mouth . . . always smiling.
Ether is the perfect drug for Las Vegas. In this town they love a
drunk. Fresh meat. So they put us through the turnstiles and turned us
loose inside.
 
The Circus - Circus is what the whole hep world would be doing on Saturday
night if the Nazis had won the war. This is the Sixth Reich. The ground
floor is full of gambling tables, like all the other casinos . . . but
the place is about four stories high, in the style of a circus tent,
and all manner of strange County - Fair/Polish Carnival madness is going
on up in this space. Right above the gambling tables the Forty Flying
Carazito Brothers are doing a high - wire trapeze act, along with four
muzzled Wolverines and the Six Nymphet Sisters from San Diego . . . so
you're down on the main floor playing blackjack, and the stakes are
getting high when suddenly you chance to look up, and there, right smack
above your head is a half - naked fourteen - year - old girl being chased
through the air by a snarling wolverine, which is suddenly locked in a
death battle with two silver - painted Polacks who come swinging down
from opposite balconies and meet in mid - air on the wolverine's neck
. . . both Polacks seize the animal as they fall straight down towards
the crap tables - but they bounce off the net; they separate and spring
back up towards the roof in three different directions, and just as
they're about to fall again they are grabbed out of the air by three
Korean Kittens and trapezed off to one of the balconies.
This madness goes on and on, but nobody seems to notice. The gambling
action runs twenty - four hours a day on the main floor, and the circus
never ends. Meanwhile, on all the upstairs balconies, the customers are
being hustled by every conceivable kind of bizarre shuck. All kinds of
funhouse - typeShoot the pasties off the nipples of a ten - foot bulle
and win a cotton - candy goat. Stand in front of this fantastic machine,
my friend, and for just 99$ your likeness will appear, two hundred feet
tall, on a screen above downtown Las Vegas. Ninety - nine cents more
for a voice message. "Say whatever you want, fella. They'll hear you,
don't worry about that. Remember you'll be two hundred feet tall."
Jesus Christ. I could see myself lying in bed in the Mint Hotel, half -
asleep and staring idly out the window, when suddenly a vicious nazi
drunkard appears two hundred feet tall in the midnight sky, screaming
gibberish at the world: "Woodstock Uber Alles!"
We will close the drapes tonight. A thing like that could send a drug
person careening around the room like a pingpong ball. Hallucinations
are bad enough. But after a while you learn to cope with things like
seeing your dead grandmother crawling up your leg with a knife in her
teeth. Most acid fanciers can handle this sort of thing.But nobody can
handle that other trip - the possibility that any freak with $1.98 can
walk into the Circus - Circus and suddenly appear in the sky over downtown
Las Vegas twelve times the size of God, howling anything that comes into
his head. No, this is not a good town for psychedelic drugs. Reality
itself is too twisted.
 
Good mescaline comes on slow. The first hour is all waiting, then about
halfway through the second hour you start cursing the creep who burned
you, because nothing is happeningand then ZANG! Fiendish intensity,
strange glow and vibrations . . . a very heavy gig in a place like the
Circus - Circiii.
"I hate to say this," said my attorney as we sat down at the Merry -
Go - Round Bar on the second balcony, "but this place is getting to
me. I think I'm getting the Fear."
"Nonsense," I said. "We came out here to find the American Dream, and now
that we're right in the vortex you want to quit." I grabbed his bicep and
squeezed. "You must realize,"I said, "that we've found the main nerve."
"I know," he said. "That's what gives me the Fear."
The ether was wearing off, the acid was long gone, but the mescaline
was running strong. We were sitting at a small round gold formica table,
moving in orbit around the bartender.
"Look over there," I said. "Two women fucking a polar bear."
"Please," he said. "Don't tcll me those things. Not now." He signaled
the waitress for two more Wild Turkeys. 
"This is my last drink," he said. "How much money can you lend me?"
"Not much," I said. "Why?"
"I have to go," he said.
"Go?"
"Yes. Leave the country. Tonight."
"Calm down," I said. "You'll be straight in a few hours."
"No," he said. "This is serious.
"George Metesky was serious," I said. "And you see what they did to him."
"Don't fuck around!" he shouted. "One more hour in this town and I'll
kill somebody!"
I could see he was on the edge. That fearful intensity that comes at
the peak of a mescaline seizure. "OK," I said. "I'll lend you some
money. Let's go outside and see how much we have left."
"Can we make it?" he said.
"Well . . . that depends on how many people we fuck with between here
and the door. You want to leave quietly?"
"I want to leave fast," he said.
"OK. Let's pay this bill and get up very slowly. We're both out of our
heads. This is going to be a long walk." I shouted at the waitress for
a bill. She came over, looking bored, and my attorney stood up.
"Do they pay you to screw that bear?" he asked her.
"What?"
"He's just kidding," I said, stepping between them. 
"Come on, Doc - let's go downstairs and gamble." I got him as far as
the edge of the bar, the rim of the merry - go - round, but he refused
to get off until it stopped turning.
"It won't stop," I said. "It's not never going to stop." I stepped off
and turned around to wait for him, but he wouldn't move . . . and before
I could reach out and pull him off, he was carried away. "Don't move,"
I shouted. 
"You'll come around!" His eyes were staring blindly ahead, squinting
with fear and confusion. But he didn't move a muscle until he'd made
the whole circle.
I waited until he was almost in front of me, then I reached out to grab
him - but he jumped back and went around the circle again. This made me
very nervous. I felt on the verge of a freakout. The bartender seemed
to be watching us.Carson City, I thought. Twenty years.
 
I stepped on the merry - go - round and hurried around the bar,
approaching my attorney on his blind side - and when we came to the
right spot I pushed him off. He staggered into the aisle and uttered a
hellish scream as he lost his balance and went down, thrashing into the
crowd . . . rolling like a log, then up again in a flash, fists clenched,
looking for somebody to hit.
I approached him with my hands in the air, trying to smile. 
"You fell," I said. "Let's go."
By this time people were watching us. But the fool wouldn't move, and
I knew what would happen if I grabbed him. "OK," I said. "You stay here
and go to jail. I'm leaving." I started walking fast towards the stairs,
ignoring him.
This moved him.
"Did you see that?" he said as he caught up with me. 
"Some sonofabitch kicked me in the back!"
"Probably the bartender," I said. "He wanted to stomp you for what you
said to the waitress."
"Good god! Let's get out of here. Where's the elevator?"
"Don't go near that elevator," I said. "That's just what they want us
to do . . . trap us in a steel box and take us down to the basement." I
looked over my shoulder, but nobody was following.
"Don't run," I said. "They'd like an excuse to shoot us." He nodded,
seeming to understand. We walked fast along the big indoor midway -
shooting galleries, tattoo 
parlors, money - changers and cotton - candy booths - then out through
a bank of glass doors and across the grass downhill to a parking lot
where the Red Shark waited.
'You drive," he said. "I think there's something wrong with me."
 
7. Paranoid Terror . . . and the Aweful Specter of Sodomy . . . A Flashing
of Knives and Green Water
 
When we got to the Mint I parked on the street in front of the casino,
around a corner from the parking lot. No point risking a scene in the
lobby, I thought. Neither one of us could pass for drunk. We were both
hyper - tense. Extremely menacing vibrations all around us. We hurried
through the casino and up the rear escalator.
We made it to the room without meeting anybody - but the key wouldn't
open the door. My attorney was struggling desperately with it. "Those
bastards have changed the lock on us," he groaned. "They probably searched
the room. Jesus, we're finished."
Suddenly the door swung open. We hesitated, then hurried inside. No sign
of trouble. "Bolt everything," said my attorney. "Use all chains." He
was staring at two Mint Hotel Room keys in his hand. "Where did this
one come from?" he said, holding up a key with number 1221 on it.
"That's Lacerda's room," I said.
He smiled. "Yeah, that's right. I thought we might need it."
"What for?"
"Let's go up there and blast him out of bed with the fire he said.
"No," I said. "We should leave the poor bastard alone, I get the feeling
he's avoiding us for some reason."
"Don't kid yourself," he said. "That Portuguese son of bitch is
dangerous. He's watching us like a hawk." He squinted at me. "Have you
made a deal with him?"
"I talked with him on the phone," I said, "while you were out getting
the car washed. He said he was turning in early, so he can get out there
to the starting line at dawn."
My attorney was not listening. He utt.ered an anguished cry and smacked
the wall with both hands. "That dirty bastard!" he shouted. "I knew
it! He got hold of my woman!"
I laughed. "That little blonde groupie with the film crew? You think he
sodomized her?"
"That's right - laugh about it!" he yelled. "You goddamn honkies are
all the same." By this time he'd 
opened a new bottle of tequila and was quaffing it down. 
Then he grabbed a grapefruit and sliced it in half with a Gerber Mini -
Magnum - a stainless - steel hunting knife with a blade like a fresh -
honed straight razor.
"Where'd you get that knife?" I asked.
"Room service sent it up," he said. "I wanted something to cut the limes.
"What limes?"
"They didn't have any," he said. "They don't grow out here in the
desert." He sliced the grapefruit into quarters then into eighths
. . . then sixteenths . . . then he began aimlessly at the residue. "That
dirty toad bastard," he moaned. "I knew I should have taken him out when
I had the chance. Now he has her."
I remembered the girl. We'd had a problem with her on the elevator a
few hours earlier: my attorney had made a fool of himself.
"You must be a rider," she'd said. "What class are you in?"
"Class?" he snapped. "What the fuck do you mean?"
"What do you ride?" she asked with a quick smile. 
"We're filming the race for a TV series - maybe we can use you."
"Use me?"
Mother of God, I thought. Here it comes. The elevator was crowded with
race people: it was taking a long time to get from floor to floor. By the
time we'd stopped at Three, he was trembling badly. Five more to go. .
"I ride the big ones!" he shouted suddenly. "The really big fuckers!"
I laughed, trying to de - fuse the scene. "The Vincent Black Shadow,"
I said. "We're with the factory team."
This brought a murmur of rude dissent from the crowd. 
"Bullshit," somebody behind me muttered.
"Wait a minute!" my attorney shouted . . . and then to the girl:
"Pardon me, lady, but I think there's some kind of ignorant chicken -
sucker in this car who needs his face cut open." He plunged his hand
into the pocket of his black plastic jacket and turned to face the
people crowded into the rear of the elevator. "You cheap honky faggots,"
he snarled. "Which one of you wants to get cut?"
I was watching the overhead floor - indicator. The door opened at Seven,
but nobody moved. Dead silence. The door closed. Up to Eight . . . then
open again. Still no sound ormovement in the crowded car. Just as the
door began to close I stepped off and grabbed his arm, jerking him out
just in time. The doors slid shut and the elevator light dinged Nine. 
"Quick! Into the room," I said. "Those bastards will have on
us!" We ran around the corner to the room. My attorney was laughing
wildly. "Spooked!" he shouted. "Did you see that? They were spooked. Like
rats in a death - cage!"
Then, as we bolted the door behind us, he stopped laughing. "God damn," he
said. "It's serious now. That girl understood. She fell in love with me."
 
Now, many hours later, he was convinced that Lacerda - the so - called
photographer - had somehow got his hands on the girl. "Let's go up there
and castrate that fucker," he said, waving his new knife around in quick
circles in front of his teeth. "Did you put him onto her?"
"Look," I said, "you'd better put that goddamn blade away and get your
head straight. I have to put the car in the lot." I was backing slowly
towards the door. One of the things you learn, after years of dealing
with drug people, is that everything is serious. You can turn your back
on a person, but never turn your back on a drug - especially when it's
waving a razor - sharp hunting knife in your eyes.
"Take a shower," I said. "I'll be back in twenty minutes." I left quickly,
locking the door behind me and 
taking the key to Lacerda's room - the one my attorney had stolen
earlier. That poor geek, I thought, as I hurried down the escalator. They
sent him out here on this perfectly reasonable assignment - just a few
photos of motorcycles and dune buggies racing around the desert - and
now he was plunged, without realizing it, into the maw of some world
beyond his ken. There was no way he could possibly understand what was
happening.
 
What were we doing out here? What was the meaning of this trip? Did I
actually have a big red convertible out there on the street? Was I just
roaming around these Mint Hotel escalators in a drug frenzy of some kind,
or had I really come out here to Las Vegas to work on a story?
I reached in my pocket for the room key; "1850," it said. At least that
much was real. So my immediate task was to deal with the car and get
back to that room . . . and then hopefully get straight enough to cope
with whatever might happen at dawn.
Now off the escalator and into the casino, big crowds still tight around
the crap tables. Who are these people? These faces! Where do they come
from? They look like caricatures of used - car dealers from Dallas. But
they're real. And, sweet Jesus, there are a hell of a lot of them -
still screaming around these desert - city crap tables at four - thirty
on a Sunday morning. Still humping the American Dream, that vision of
the Big Winner somehow emerging from the last - minute pre - dawn chaos
of a stale Vegas casino.
Big strike in Silver City. Beat the dealer and go home rich. Why not? I
stopped at the Money Wheel and dropped a dollar on Thomas Jefferson -
a $2 bill, the straight Freak ticket, thinking as always that some idle
instinct bet might carry the whole thing off.
But no. Just another two bucks down the tube. You bastards!
No. Calm down. Learn to enjoy losing. The important thing is to cover
this story on its own terms; leave the other stuff to Life and Look -
at least for now. On the way down the escalator I saw the Life man
twisted feverishly into the telegraph booth, chanting his wisdom into
the ear of some horny robot in a cubicle on that other coast. Indeed:
"LAS VEGAS AT DAWN - The racers are still asleep, the dust is still
on the desert, $50,000 in prize money slumbers darkly in the office
safe at Del Webb's fabulous Mint Hotel in the bright heart of Casino
Center. Extreme tension. And our Life team is here (as always, with
a sturdy police escort. . .)." Pause. "Yes, operator, that word was
police. What else? This is, after all, a Life Special . . . 
The Red Shark was out on Fremont where I'd left it. I drove around to
the garage and checked it in - Dr. Gonzo's car, no problem, and if any of
your men fall idle we can use awax job before morning. Yes, of course -
just bill the room.
 
  
 
My attorney was in the bathtub when I returned. Submerged in green water -
the oily product of some Japanese bath salts he'd picked up in the hotel
gift shop, along with a new AM/FM radio plugged into the electric razor
socket. Top volume. Some gibberish by a thing called "Three Dog Night,"
about a frog named Jeremiah who wanted "Joy to the World."First Lennon,
now this, I thought. Next we'll have Glenn Campbell screaming "Where
Have All the Flowers Gone?"
Where indeed? No flowers in this town. Only carnivorous plants. I turned
the volume down and noticed a hunk of chewed - up white paper beside
the radio. My attorney seemed not to notice the sound - change. He was
lost in a fog of green steam; only half his head was visible above the
water line.
"You ate this?" I asked, holding up the white pad.
He ignored me. But I knew. He would be very difficult to reach for the
next six hours. The whole blotter was chewed up.
"You evil son of a bitch," I said. "You better hope there's some thorazine
in that bag, because if there's not you're in bad trouble tomorrow."
"Music!" he snarled. "Turn it up. Put that tape on."
"What tape?"
"The new one. It's right there."
I picked up the radio and noticed that it was also a tape recorder -
one of those things with a cassette - unit built in. And the tape,
Surrealistic Pillow, needed only to be flipped over. He had already gone
through side one - at a volume that must have been audible in every room
within a radius of one hundred yards, walls and all.
"'White Rabbit,"' he said. "I want a rising sound."
"You're doomed," I said. "I'm leaving here in two hours - and then
they're going to come up here and beat the mortal shit out of you with
big saps. Right there in the tub."
"I dig my own graves," he said. "Green water and the White Rabbit
. . . put it on; don't make me use this." His arm lashed out of the water,
the hunting knife gripped in his fist.
"Jesus," I muttered. And at that point I figured he was I help - lying
there in the tub with a head full of acidand the sharpest knife I've
ever seen, totally incapable of reason, demanding the White Rabbit. This
is it, I thought. "I've gone as far as I can with this waterhead. This
time it's a suicide trip. This time he wants it. He's ready..
"OK," I said, turning the tape over and pushing the "play" button. "But
do me one last favor, will you? Can you give me two hours? That's all I
ask - just two hours to sleep before tomorrow. I suspect it's going to
be a very difficult day."
"Of course," he said. "I'm your attorney. I'll give you all the time you
need, at my normal rates: $45 an hour - but you'll be wanting a cushion,
so why don't you just lay one of those $100 bills down there beside the
radio, and fuck off?"
"How about a check?" I said. "On the Sawtooth National Bank. You won't
need any ID to cash it there. They know me."
"Whatever's right," he said, beginning to jerk with the music. The
bathroom was like the inside of a huge defective woofer. Heinous
vibrations, overwhelming sound. The floor was full of water. I moved
the radio as far from the tub as it would go, then I left and closed
the door behind me.
Within seconds he was shouting at me. "Help! You bastard! Ineed help!"
I rushed back inside, thinking he'd sliced off an ear by accident.
But no . . . he was reaching across the bathroom toward the white formica
shelf where the radio sat. "I want that tuckin radio," he snarled.
I grabbed it away from his hand. "You fool!" I said. "Get in that tub! Get
away from that goddamn radio!" I shoved it back from his hand. The volume
was so far up that it was hard to know what was playing unless you knew
Surrealistic Pillow almost note for note . . . which I did, at the time,
so I knew that "White Rabbit" had finished; the peak and had come and
gone.
But my attorney, it seemed, had not made it. He wanted more. "Back the
tape up!" he yelled. "I need it again!" His eyes were full of craziness
now, unable to focus. He seemed on the verge of some awful psychic orgasm
"Let it roll!" he screamed. "Just as high as the fucker can go! And when
it comes to that fantastic note where the rabbit bites its own head off,
I want you to throw that fuckin radio into the tub with me."
I stared at him, keeping a firm grip on the radio. "Not me," I said
finally. "I'd be happy to ram a goddamn 440 - volt cattle prod into
that tub with you right now, but not this radio. It would blast you
right through the wall - stone - dead in ten seconds." I laughed. "Shit,
they'd make me explain it - drag me down to some rotten coroner's inquest
and grill me about. . yes . . . the exact details. I don't need that."
"Bullshit!" he screamed. "Just tell them I wanted to get Higher!"
I thought for a moment. "Okay," I said finally. "You're right. This
is probably the only solution." I picked up the tape/radio - which was
still plugged in - and held it over the tub. "Just let me make sure I
have it all lined up," I said. 
"You want me to throw this thing into the tub when 'White Rabbit' peaks -
is that it?"
He fell back in the water and smiled gratefully. "Fuck yes," he said. "I
was beginnjng to think I was going to have to go out and get one of the
goddamn maids to do it."
"Don't worry," I said. "Are you ready?" I hit the "play" button and
"White Rabbit" started building again. 
Almost immediately he began to howl and moan . . . another fast run up
that mountain, and thinking, this time, that he would finally get over
the top. His eyes were gripped shut and only his head and both kneecaps
poked up through the oily green water.
I let the song build while I sorted through the pile of fat ripe
grapefruit next to the basin. The biggest one of the lot weighed almost
two pounds. I got a good Vida Blue faitball grip on the fucker - and
just as "Whit. Rabbit" peaked Ilashed it into the tub like a cannonball.
My attorney screamed crazily, thrashing around in the tub like a shark
after meat, churning water all over the floor as he struggled to get
hold of something.
I jerked the AC cord out of the tape/radio and moved out of the bathroom
very quickly . . . the machine kept on playing, but now it was back on
its own harmless battery power. I could hear the beat cooling down as I
moved across the room to my kitbag and fetched up the Mace can . . . just
as my attorney ripped the bathroom door open and started out. His eyes
were still unfocused, but he was waving the blade out in front of him
like a man who meant to cut something.
"Mace!" I shouted. "You want this?" I waved the Mace bomb in front of
his watery eyes.
He stopped, "You bastard!" he hissed. "You'd do that, wouldn't you?"
I laughed, still waving the bomb at him. "Why worry? You'll like it. Shit,
there's nothing in the world like a Mace high - forty - five minutes
on your knees with the dry heaves, gasping for breath. It'll calm you
right down."
He stared in my general direction, trying to focus. "You cheap honky
sonofabitch," he muttered. "You'd do it, wouldn't you?"
"Why not?" I said. "Hell, just a minute ago you were asking me to kilt
you! And now you want to kill me! What I should do, goddamn it, is call
the police!"
He sagged. "The cops?"
I nodded. "Yeah, there's no choice. I wouldn't dare go to sleep with
you wandering around in this condition - with a head full of acid and
wanting to slice me up with that god - damn knife."
He rolled his eyes for a moment, then tried to smile. 
"Who said anything about slicing you up?" he mumbled. I just wanted to
carve a little Z on your forehead - nothing serious." 
He shrugged and reached for a cigarette of the TV set,
I menaced him again with the Mace can. "Get back in that tub," I
said. "Eat some reds and try to calm down. Smoke some grass, shoot some
smack - shit, dowhatever you have to do, but let me get some rest."
He shrugged and smiled distractedly, as if everything I'd said made
perfect sense.
"Hell yes," he said very earnestly. "You really need some sleep. You
have towork tomorrow." He shook his head sadly and turned back toward
the bathroom. "God damn! What a bummer." He waved me off. "Try to rest,"
he said."Don't let me keep you up."
I nodded, and watched him shuffle back into the bathroom - still holding
the blade, but now he seemed unaware of it. The acid had shifted gears
on him; the next phase would probably be one of those hellishly intense
introspection night mares. Four hours or so of catatonic despair; but
nothing physical, nothing dangerous. I watched the door close behind
him, then I quietly slid a heavy, sharp - angled chair up in front of
the bathroom knob and put the Mace can beside the alarm clock.
 
The room was very quiet. I walked over to the TV set and turned it on
to a dead channel - white noise at maximum decibels, a fine sound for
sleeping, a powerful continuous hiss to drown out everything strange.
 
8. "Genius 'Round the Wand Stands Hand in Hand, and One Shock of
Recognition Runs the Whole Circle 'Round"
 
- Art LinkIetter
 
I live in a quiet place, where any sound at night means some thing is
about to happen: You come awake fast - thinking, what does that mean?
Usually nothing. But sometimes . . . it's hard to adjust to a city gig
where the night is full of sounds, all of them comfortably routine. Cars,
horns, footsteps . . . no way to relax; so drown it all out with the fine
white drone of a cross - eyed TV set. Jam the bugger between channels
and doze off nicely.
 
Ignore that nightmare in the bathroom. Just another ugly refugee from
the Love Generation, some doom - struck gimp who couldn't handle the
pressure. My attorney has never been able to accept the notion - often
espoused by reformed drug abusers and especially popular among those on
probation - that you can get a lot higher without drugs than with them.
And neither have I, for that matter. But I once lived down the hill
from Dr. - on -Road, Names deleted at insistence of publisher's lawyer)
a former acid guru who later claimed to have made that long jump from
chemical frenzy to preternatural consciousness. One fine afternoon in the
first rising curl of what would soon become the Great San Francisco Acid
Wave I stopped by the Good Doctor's house with the idea of asking him
(since he was even then a known drug authority) what sort of advice he
might have for a neighbor with a healthy curiosity about LSD.
I parked on the road and lumbered up his gravel driveway, pausing
enroute to wave pleasantly at his wife, who was working out in the graden
. . . pruning carrots, or whatever . . . humming while she works, some
tune I fail to recognize.
Humming. Yes . . . but it would be nearly ten years before I would
recognize that sound for what it was: like Ginsberg far gone in the Om, -
was trying to humm me off. That was no old lady out there in that garden;
it was the good doctor himself - and his humming was a frantic attempt
to block me out of his higher consciousness.
I made several attempts to make myself clear: Just a neighbor come to
call and ask the doctor's advice about gobbling some LSD in my shack
just down the hill from his house. I did, after all, have weapons. And
I liked to shoot them - especially at night, when the great blue flame
would leap out, along with all that noise . . . and, yes, the bullets,
too. We couldn't ignore that. Big balls of lead/alloy flying around the
valley at speeds up to 3700 feet per second.
But I always fired into the nearest hill or, failing that, into
blackness. I meant no harm; I just liked the explosions. And I was
careful never to kill more than I could eat.
"Kill?" I realized I could never properly explain that word to this
creature toiling here in its garden. Had it ever eaten meat? Could it
conjugate the verb "hunt?" Did it understand hunger? Or grasp the awful
fact that my income averaged around $32 a week that year?
No . . . no hope of communication in this place. I recognized that-but
not soon enough to keep the drug doctor from humming me all the way down
his driveway and into my car and down the mountain road. Forget LSD,
I thought. Look what it's done to that poor bastard.
So I stuck with hash and rum for another six months or so, until I
moved into San Francisco and found myself one night, in a place called
"The Fillmore Auditorium." And that was that. One grey lump of sugar,
and BOOM. In my mind I was right back there in the doctor's garden. Not
on the surface, but underneath - poking up through that finely cultivated
earth like some kind of mutant mushroom. A victim of the Drug Explosion. A
natural street freak, just eating whatever came by. I recall one night,
in the Matrix, when a road - person came in with a big pack on his back,
shouting: 
"Anybody want some L . . . S . . . D . . . ? I got all the makin's right
here. All I need is a place to cook."
The manager was on him at once, mumbling, "Cool it, cool it, come on
back to the office." I never saw him after that night, but before he
was taken away, the road - person distributed his samples. Huge white
spansules. I went into the men's room to eat mine. But only half at
first, I thought. Good thinking, but a hard thing to accomplish under the
circumstances. I ate the first half, but spilled the rest on the sleeve
of my red Pendleton shirt . . . And then, wondering what to do with it,
I saw one of the musicians come in. "What's the trouble," he said.
"Well," I said. "All this white stuff on my sleeve is LSD." He said
nothing: Merely grabbed my arm and began sucking on it. A very gross
tableau. I wondered what would happen if some Kingston Trio/young
stockbroker type might wander in and catch us in the act. Fuck him,
I thought. With a bit of luck, it'll ruin his life - forever thinking
that just be - hind some narrow door in all his favorite bars, men in
red Pendleton shirts are getting incredible kicks from things he'll never
know. Would he dare to suck a sleeve? Probably not. Play it safe. Pretend
you never saw it.
 
Strange memories on this nervous night in Las Vegas. Five years
later? Six? It seems like a lifetime, or at least a Main Era - the kind
of peak that never comes again. San Francisco in the middle sixties
was a very special time and place to be a part of. Maybe it meant
something. Maybe not, in the long run . . . but no explanation, no mix
of words or music or memories can touch that sense of knowing that you
were here and alive in that corner of time and the world. Whatever it
meant . . . .
History is hard to know, because of all the hired bullshit, but even
without being sure of "history" it seems entirely reasonable to think
that every now and then the energy of a whole generation comes to a head
in a long fine flash, for reasons that nobody really understands at the
time - and which never explain, in retrospect, what actually happened.My
central memory of that time seems to hang on one or five or maybe forty
nights - or very early mornings - when I left the Fillmore half - crazy
and, instead of going home, aimed the big 650 Lightning across the Bay
Bridge at a hundred miles an hour wearing L. L. Bean shorts and a Butte
sheepherder's jacket . . . booming through the Treasure Island tunnel at
the lights of Oakland and Berkeley and Richmond, not quite sure which
turn - off to take when I got to the other end (always stalling at the
toll - gate, too twisted to find neutral while I fumbled for change)
. . . but being absolutely certain that no matter which way I went I
would come to a place where people were just as high and wild as I was:
No doubt at all about that. .There was madness in any direction, at any
hour. If not across the Bay, then up the Golden Gate or down 101 to Los
Altos or La Honda. . . . You could strike sparks anywhere. 
There was a fantastic universal sense that whatever we were doing was
right, that we were winning.And that, I think, was the handle - that
sense of inevitable victory over the forces of Old and Evil. Not in any
mean or military sense; we didn't need that. Our energy would simply
prevail. There was no point in fighting - on our side or theirs. We had
all the momentum; we were riding the crest of a high and beautiful wave.
So now, less than five years later, you can go up on a steep hill in
Las Vegas and look West, and with the right kind of eyes you can almost
see the high - water mark - that place where the wave finally broke and
rolled back.
 
9. Sympathy for the Devil . . . Newsmen Tortured? . . . Flight into
Madness
 
The decision to flee came suddenly. Or maybe not. Maybe I'd 'planned it
all along - subconsciously waiting for the right moment. The bill was a
factor, I think. Because I had no money to pay it. And no more of these
devilish credit - card/reimbursement deals. Not after dealing with Sidney
Zion. They seized my American Express card after that one, and now the
bastards are suing me - along with the Diner's Club and the IRS . . . .
And besides, the magazine is legally responsible. My attorney saw to
that. We signed nothing. Except those room service tabs. We never knew the
total, but - just before we left - my attorney figured we were running
somewhere between $29 and $36 per hour, for forty - eight consecutive
hours.
"Incredible," I said. "How could it happen?"
But by the time I asked this question, there was nobody around to
answer. My attorney was gone. He must have sensed trouble. On Monday
evening he ordered up a set of fine cowhide luggage from room service,
told me he had reservations on the next plane for L.A. We would have to
hurry, he said, and on the way to the airport he borrowed $25 for the
plane ticket.
I saw him off, then I went back to the airport souvenir counter and
spent all the rest of my cash on garbage - complete shit, souvenirs of
Las Vegas, plastic fake - Zippo - lighters with a built - in roulette
wheel for $6.95, JFK half - dollar clips for $5 each, tin apes that
shook dice for $7.50 . . . 
I loaded up on this crap, then carried it out to the Great Red Shark
and dumped it all in the back seat . . . and then I stepped into the
driver's seat in a very dignified way (the white top was rolled back,
as always) and I sat there and turned the radio on and began thinking.
How would Horatio Alger handle this situation?One toke over the line,
sweet Jesus. . . one toke over the 
line. Panic. It crept up my spine like the first rising vibes of an acid
frenzy. All these horrible realities began to dawn on me: Here I was all
alone in Las Vegas with this goddamn incredibly expensive car, completely
twisted on drugs, no attorney, no cash, no story for the magazine - and
on top of everything else I had a gigantic goddamn hotel bill to deal
with. We had ordered everything into that room that human hands could
carry - including about six hundred bars of translucent Neutrogena soap.
The whole car was full of it - all over the floors, the seats, the glove
compartment. My attorney had worked out some kind of arrangement with
the mestizo maids on our floor to have this soap delivered to us - six
hundred bars of this weird, transparent shit - and now it was all mine.
Along with this plastic briefcase that I suddenly noticed right beside
me on the front seat. I lifted the fucker and knew immediately what was
inside. No Samoan attorney in his right mind is going to stomp through
the metal - detector gates of a commercial airline with a fat black .357
Magnum on his person.
So he had left it with me, for delivery - if I made it back to
L.A. Otherwise . . . well, I could almost hear myself talking to the
California Highway Patrol:
What? This weapon? This loaded, unregistered, concealed and maybe hot
.357 Magnum? What am I doing with it? Well, you see, officer, I pulled
off the road near Mescal Springs - on the advice of my attorney, who
subsequently disappearedr - and all of a sudden while I was just sort
of walking around that deserted waterhole by myself for no reason at
all when this little fella with a beard came up to me, out of nowhere,
and he had horrible linoleum knife in one hand and this huge black pistol
in the other hand. . . and he offered to carve a big X on my forehead, in
memory of Lieutenant Calley . . . but when I told him I was a doctor of
journalism his whole attitude changed. Yes, you probably won't believe
this, officer, but he suddenly hurled that knife into the brackish
mescal waters near our feet, and then he gave me this revolver. Right,
he just shoved it into my hands, butt - first, and then he ran off into
the darkness.
So that's why I have this weapon, officer. Can you believe that?
No.
But I wasn't about to throw the bastard away, either. A good .357 is a
hard thing to get, these days.
So I figured, well, just get this bugger back to Malibu, and it's mine. My
risk - my gun: it made perfect sense. And if that Samoan pig wanted to
argue, if he wanted to come yelling around the house, give him a taste
of the bugger about midway up the femur. Indeed. 158 grains of half -
jacketed lead/alloy, traveling 1500 feet per second, equals about forty
pounds of Samoan hamburger, mixed up with bone splinters. Why not?
 
Madness, madness . . . and meanwhile all alone with the Great Red Shark in
the parking lot of the Las Vegas airport. To hell with this panic. Get a
grip. Maintain. For the next twenty - four hours this matter of personal
control will be critical. Here I am sitting out here alone on this fucking
desert, this nest of armed loonies, with a very dangerous carload hazards,
horrors and liabilities that I must get back to L.A.if they nail me out
here, I'm doomed. Completely fucked. No question about that. No future
for a doctor of journalism editing the state pen weekly. Better to get
the hell of this atavistic state at high speed. Right. But, first - to
the Mint Hotel and cash a $50 check, then up to the room and call down
for two club sandwiches, two quarts of milk, a pot of coffee and a fifth
of Bacardi Anejo. Rum will be absolutely necessary to get through this
night - to polish these notes, this shameful diary . . . keep the tape
machine screaming all night long at top volume: "Allow me to introduce
myself . . . I'm a man of wealth and taste." 
Sympathy?
Not for me. No mercy for a criminal freak in Las Vegas. 
This place is like the Army: the shark ethic prevails - eat the
wounded. In a closed society where everybody's guilty, the only crime is
getting caught. In a world of thieves, the only final sin is stupidity.
It is a weird feeling to sit in a Las Vegas hotel at four in the morning -
hunkered down with a notebook and a tape recorder in a $75 - a - day suite
and a fantastic room service bill, run up in forty - eight hours of total
madness - knowing that just as soon as dawn comes up you are going to flee
without paying a fucking penny . . . go stomping out through the lobby
and call your red convertible down from the garage and stand there waiting
for it with a suitcase full of marijuana and illegal weapons . . . trying
to look casual, scanning the first morning edition of the Las Vegas Sun.
This was the final step. I had taken all the grapefruit and other luggage
out to the car a few hours earlier.
Now it was only a matter of slipping the noose: Yes, extremely casual
behavior, wild eyes hidden behind these Saigon - mirror sun glasses
. . . waiting for the Shark to roll up. 
Where is it? I gave that evil pimp of a carboy $5, a prime investment
right now.
Stay calm, keep reading the paper. The lead story was a screaming blue
headline across the top of the page:
 
TRIO RE - ARRESTED
IN BEAUTY'S DEATH
 
An overdose of heroin was listed as the official cause of death for pretty
Diane Hamby, 19, whose body was foundstuffed in a refrigerator last
week, according to Clark County Coroner's office. Investigators of the
sheriff's homicide team who went to arrest the suspects said that one,
a 24 - year - old woman, attempted to fling herself through the glass
doors of her trailer before being stopped by deputies. Officers said she
was apparently hysterical and shouted, 'You'll never take me alive." But
officers handcuffed the woman and she apparently was not injured.
 
GI DRUG DEATHS CLAIMED
 
WASHINGTON (AP) - A House Subcommittee report says 
illegal drugs killed 160 American GI's last year - 40 of 
them in Vietnam . . . Drugs were suspected, it said, in another 
56 military deaths in Asia and the Pacific Command . . . It 
said the heroin problem in Vietnam is increasing in 
seriousness, primarily because of processing laboratories in 
Laos, Thailand and Hong Kong. "Drug suppression in 
Vietnam is almost completely ineffective," the report said, 
"partially because of an ineffective local police force and 
partially because some presently unknown corrupt officials 
in public office are involved in the drug traffic."
 
To the left of that grim notice was a four - column center - page photo
of Washington, D.C., cops fighting with "young anti - war demonstrators
who staged a sit - in and blocked the entrance to Selective Service
Headquarters."And next to the photo was a large black headline: 
 
TORTURE TALES TOLD IN WAR HEARINGS.
 
WASHINGTON - Volunteer witnesses told an informal 
congressional panel yesterday that while serving as 
miliy interrogators they routinely used electrical tele - 
tione hookups and helicopter drops to torture and kill 
ietnamese prisoners. One Army intelligence specialist 
iid the pistol slaying of his Chinese interpreter was de - 
by a superior who said, "She was just a slope,
Lyway," meaning she was an Asiatic. . . . 
 
Right underneath that story was a headline saying: FIVE 
WOUNDED NEAJi NYC TENEMENT . . . by an unidentified 
gunman who fired from the roof of a building, for no apparent reason. This
item appeared just above a headline that said:
PHARMACY OWNER ARRESTED IN PROBE . . . "a 
result," the article explained, "of a preliminary investigation (of a
Las Vegas pharmacy) showing a 
shortage of over 100,000 pills considered dangerous drugs. . .
Reading the front page made me feel a lot better. Against that heinous
background, my crimes were pale and meaningless. I was a relatively
respectable citizen - a multiple felon, perhaps, but certainly not
dangerous. And when the Great Scorer came to write against my name,
that would surely make a difference.
Or would it? I turned to the sports page and saw a small item
about Muhammad Ali; his case was before the Supreme Court, the final
appeal. He'd been sentenced to five years in prison for refusing to kill
"slopes."
"I ain't got nothin' against them Viet Congs," he said.
Five years.
 
10. Western Union Intervenes: A Warning from Mr. Heem . . . New Assignment
from the Sports Desk and a Savage Invitation from the Police
 
Suddenly I felt guilty again. The Shark! Where was it? I tossed the paper
aside and began to pace. Losing control. I felt my whole act slipping
. . . and then I saw the car, swooping down a ramp in the next - door
garage.
Deliverance! I grasped my leather satchel and moved forward to meet my
wheels.
"MISTER DUKE!"
The voice came from over my shoulder.
"Mister Duke! We've been looking for you!"
I almost collapsed on the curb. Every cell in my brain and body
sagged. No! I thought. I must be hallucinating. There's nobody back there,
nobody calling . . . it's a paranoid delusion, amphetamine psychosis
. . . just keep walking towards the car, always smiling . . . .
"MISTER DUKE! Wait!"
Well . . . why not? Many fine books have been written in on. And it's
not like I'll be a total stranger up there in Carson City. The warden
will recognize me; and the Con Boss - I once interviewed them for The
New York Times. Along with a lot of other cons, guards, cops and assorted
hustlers who got ugly, by mail, when the article never appeared.
Why not? They asked. They wanted their stories told. And it was hard to
explain; in those circles, that everything they told me went into the
wastebasket or at least the dead - end file because the lead paragraphs
I wrote for that article didn't satisfy some editor three thousand miles
away - some nervous drone behind a grey formica desk in the bowels of a
journalistic bureaucracy that no con in Nevada will ever understand -
and that the article finally died on the vine, as it were, because I
refused to rewrite the lead. For reasons of my own. 
None of which would make much sense in The Yard. But what the hell? Why
worry about details? I turned to face my accuser, a small young clerk
with a big smile on his face and a yellow envelope in his hand. "I've
been calling your room," he said. "Then I saw you standing outside."
I nodded, too tired to resist. By now the Shark was beside me, but I saw
no point in even tossing my bag into it. The game was up. They had me.
The clerk was still smiling. "This telegram just came for you," he
said. "But actually it isn't for you. It's for somebody named Thompson,
but it says 'care of Raoul Duke'; does that make sense?"
I felt dizzy. It was too much to absorb all at once. From freedom,
to prison, and then back to freedom again - all in thirty seconds. I
staggered backwards and leaned on the car, feeling the white folds of
the canvas top beneath my trembling hand. The clerk, still smiling,
was poking the telegram at me.
I nodded, barely able to speak. "Yes," I said finally, "it makes sense." I
accepted the envelope and tore it open:
 
URGENT SPEED LETTER
 
HUNTER S. THOMPSON
c/o RAOUL DUKE
SOUNDPROOF SUITE 1850
 
MINT HOTEL LAS VEGAS
 
CALL ME AT ONCE REPEAT AT ONCE WE HAVE A NEW ASSIGNMENT BEGINNING TOMORROW
ALSO VEGAS DONT WE STOP THE NATIONAL CONFERENCE OF DISTRICT ATTORNEYS
INVITES YOU TO THEIR FOUR DAY SEMINAR ON NARCOTICS AND DANGEROUS DRUGS AT
DUNES HOTEL STOP ROLLING STONE CALLED THEY WANT 50 THOUSAND WORDS MASSIVE
PAYMENT TOTAL EXPENSES INCLUDING ALL SAMPLES STOP WE HAVE RESERVATIONS
AT HOTEL FLAMINGO AND WHITE CADDY CONVERTIBLE STOP EVERYTHING IS ARRANGED
CALL IMMEDIATELY FOR DETAILS URGENT REPEAT URGENT STOP
DOCTOR GONZO
 
 
"Holy shit!" I muttered. "This can't be true!"
"You mean it's not for you?" the clerk asked, suddenly nervous. "I checked
the register for this man Thompson. We don't show him, but I thought he
was part of your team."
"He is," I said quickly. "Don't worry, I'll get it to him." I tossed my
bag into the front seat of the Shark, wanting to leave before my stay
of execution ran out. But the clerk was still curious.
"What about Doctor Gonzo?" he said.
I stared at him, giving him a full taste of the mirrors. 
"He's fine," I said. "But he has a vicious temper. The Doctor handles
our finances, makes all our arrangements." 
I slid into the driver's seat and prepared to leave.
The clerk leaned into the car. "What confused us," he said, "was Doctor
Gonzo's signature on this telegram from Los Angeles - when we knew he
was here in the hotel." He shrugged. "And then to have the telegram
addressed to some guest we couldn't account for .. . well, this delay
was unavoidable. You understand, I hope . . . ."
I nodded, impatient to flee. "You did the right thing," I "Never try to
understand a press message. About half time we use codes - especially
with Doctor Gonzo." I smiled again, but this time it seemed a trifle
odd. "Tell me," he said, "when will the doctor be awake?" 
I tensed at the wheel, "Awake? What do you mean?"
He seemed uncomfortable. "Well . . . the manager, Mister Heem, would
like to meet him." Now his grin was definitely malevolent. "Nothing
unusual. Mr. Heem likes to meet all our large accounts . . . put them
on a personal basis . . . just a chat and a handshake, you understand."
"Of course," I said. "But if I were you I'd leave the doctor alone until
after he's eaten breakfast. He's a very crude man."
The clerk nodded warily. "But he will be available. Perhaps later this
morning?"
I saw what he was getting at. "Look," I said. "That telegram was all
scrambled. It was actually from Thompson, not to him. Western Union
must have got the names reversed." I held up the telegram, knowing he'd
already read it. "What this is," I said, "is a speed message to Doctor
Gonzo, upstairs, saying Thompson is on his way out from L.A. with a new
assignment - a new work order." 
I waved him off the car. "See you later," I snapped. "I have to get out
to the track."
He backed away as I eased the car into low gear. 
"There's no hurry," he called after me. "The race is over."
"Not for me," I said, tossing him a quick friendly wave.
"Let's have lunch!" he shouted as I turned into the street.
"Righto!" I yelled. And then I was off into traffic. After a few blocks
in the wrong direction on Main Street, I doubled back and aimed south,
towards L.A. But with all deliberate speed. Keep cool and slow, I
thought. Just drift to the city limits . . . .
What I needed was a place to get safely off the road, out of sight,
and ponder this incredible telegram from my attorney. It was true; I was
certain of that. There was a definite valid urgency in the message. The
tone was unmistakable. .
But I was in no mood or condition to spend another week in Las Vegas. Not
now. I had pushed my luck about as far as it was going to carry me in
this town . . . all the way out to the edge. And now the weasels were
closing in; I could smell the ugly brutes.
Yes, it was definitely time to leave. My margin had shrunk to nothing.
Now idling along Las Vegas Boulevard at thirty miles an hour, I wanted
a place to rest and formalize the decision. It was settled, of course,
but I needed a beer or three to seal the bargain and stupefy that one
rebellious nerve end that kept vibrating negative . . . 
It would have to be dealt with. Because there was an argument, of sorts,
for staying on. It was treacherous, stupid and demented in every way -
but there was no avoiding the stench of twisted humor that hovered around
the idea of a gonzo journalist in the grip of a potentially terminal
drug episode being invited to cover the National District Attorneys'
Conference on Narcotics and Dangerous Drugs.
There was also a certain bent appeal in the notion of running a savage
burn on one Las Vegas Hotel and then - instead of becoming a doomed
fugitive on the highway to L.A. - just wheeling across town, trading in
the red Chevy convertible for a white Cadillac and checking into another
Vegas hotel, with press credentials to mingle with a thousand ranking
cops from all over America, while they harangued each other about the
Drug Problem.
It was dangerous lunacy, but it was also the kind of thing a real
connoisseur of edge - work could make an argument for. Where, for
instance, was the last place the Las Vegas police would look for a drug -
addled fraud - fugitive who just ripped off a downtown hotel?
Right. In the middle of a National District Attorneys' Drug Conference
at an elegant hotel on the strip. . .. Arriving at Caesar's Palace for
the Tom Jones dinner show in a flashing white Coupe de Ville . . . At
a cocktail party for narcotics agents and their wives at the Dunes?
Indeed, what better place to hide? For some people. But not for me. And
certainly not for my attorney - a very conspicuous person. Separately,
we might pull it off. But together, no - we would blow it. Too much
aggressive chemistry in that mix; the temptation to run a deliberate
freakout would be too heavy.
And that of course would finish us. They would show us no mercy. To
infiltrate the infiltrators would be to accept the fate of all spies:
"As always, if you or any member of your organization is apprehended by
the enemy, the Secretary will deny any Knowledge, . . . . .
No, it was too much. The line between madness and masochism was already
hazy; the time had come to pull back . . . to retire, hunker down, back
off and "cop out," as it were. Why not? In every gig like this, there
comes a time to either cut your losses or consolidate your winnings -
whichever fits.
I drove slowly, looking for a proper place to sit down with an early
morning beer and get my head together . . . to plot this unnatural
retreat.
 
11. Aaawww, Mama, Can This Really Be the End? Down and Out in Vegas,
with Amphetamine Psychosis Again?
 
Tuesday, 9:00 A.M . . . . Now, sitting in "Wild Bill's Cafe" on the
oputskirts of Las Vegas, I saw it all very learly. There only one road to
L.A. - U.S. Intertate 15, a straight-run with no backroads or alternate
routes, just a flat-out high-speed burn through Baker and Barstow and
Berdoo and then on the Hollywood Freeway straight into frantic oblivion:
safetly, obscurity, just another freak in the Freak Kingdom.
But in the meantime, for the next five or six hours, I'd be the most
conspicsous thing on this goddamn evil road - the only fireapple-red
shark convertible between Butte and Tijauana . . . blazing along this
desert highway with a half naked hillbilly mental case at the wheel. Is
it better to wear my purple and green Acapulco shirt, or nothing at all?
No way to hide in this monster.
This will not be a happy run. Not even the Sun God wants to watch. He is
gone behind a cloud for the first time in three days. No sun at all. The
sky is grey and ugly.
Just as I pulled into Wild Bill's back-street, half-hidden parking lot
I heard a roar overhead and looked up to see a big silver smoke-trailing
DC-8 taking off - about two thousand feet above the highway. Was Lacerda
aboard? The man fom Life? Did they have all the photos they needed? All
the facts? Had they fulfilled their responsibilities?
I didn't even know who'd won the race. Maybe nobody. For all I knew,
the whole spectacle had been aborted by a terrible riot - an orgy of
senseless violence, kicked off by drunken hoodlums who refused to abide
by the rules.
I wanted to plug this gap in my knowledge at the earliest opportunity:
Pick up the L.A. Times and scour the sports section for a Mint 400
story. Get the details. Cover myself. Even on the Run, in the grip of
a serious Fear . . . 
I knew it was Lacerda in that plane, heading back to New York. He told
me last night that he meant to catch the first flight.
So there he goes . . . and here I am, with no attorney, slumped on a red
plastic stool in Wild Bill's Tavern, nervously sipping a Budweiser in
a bar just coming awake to an early morning rush of pimps and pinball
hustlers .. . with a huge Red Shark just outside the door so full of
felonies that I'm afraid to even look at it.
But I can't abandon the fucker. The only hope is to somehow get it across
three hundred miles of open road between here and Sanctuary. But, sweet
Jesus, I am tired! I'm scared. I'm crazy. This culture has beaten me
down. What the fuck am I doing out here? This is not even the story I
was supposed to be working on. My agent warned me against it. All signs
were negative - especially that evil Dwark with the pink telephone in
the Polo Lounge. I should have stayed there . . . anything but this.
Aaawww . .. Mama
can this really be the end?
No!
Who played that song? Did I actually hear that fucking thing on the
jukebox just now? At 9:19 on this filthy grey morning in Wild Bill's
Tavern?
No. That was only in my brain, some long - lost echo of a painful dawn
in Toronto . . . a long time ago, half - mad in another world . . . ,
but no different.
HELP!
How many more nights and weird mornings can this terrible shit go
on? How long can the body and the brain tolerate this doom - struck
craziness? This grinding of teeth, this pouring of sweat, this pounding
of blood in the temples . . . small blue veins gone amok in front of
the ears, sixty and seventy hours with no sleep.
 
And now that is the jukebox! Yes, no doubt about it and why not? A very
popular song: "Like a bridge over troubled water . .. I will lay me down
. . . "
BOOM. Flashing paranoia. What kind of rat - bastard psychotic would play
that song - right now, at this moment? Has somebody followed me here? Does
the bartendress know who I am? Can she see me behind these mirrors?
All bartenders are treacherous, but this one is a surly middle - aged
fat woman wearing a muu - muu and Iron Boy overalls . . . probably Wild
Bill's woman.
Jesus, bad waves of paranoia, madness, fear and loathing - intolerable
vibrations in this place. Get out. Flee . . . and suddenly it occurs to
me, some final flash of lunatic shrewdness before the darkness closes in,
that my legal/hotel checkout time is not until noon . . . which gives
me at least two hours of legitimate high - speed driving to get out of
this goddamn state before I become a fugitive in the eyes of the law.
Wonderful luck. By the time the alarm goes off, I can be running full
bore somewhere between Needles and Death Valley - jamming the accelerator
through the floorboard and shaking my fist up at Efrem Zimbalist, Jr.,
swooping down on me in his FBI/Screaming Eagle helicopter.
 
YOU CAN RUN, BUT YOU CAN'T HIDE 
( . . . warning to smack dealers seen on a bulletin board in Boulder,
CO.)
 
Fuck you, Efrem, that wisdom cuts both ways.
As far as you and the Mint people know, I am still up there l850 -
legally and spiritually if not in the actual flesh - a "Do Not Disturb"
sign hung out to ward off disturb - The maids won't come near that
room as long as that sign is on the doorknob. My attorney saw to that
- along with 600 bars of Neutrogena soap that I still have to deliver
to Malibu. What will the FBI make of that? This Great Red Shark full
of Neutrogena soap bars? All completely legal. The maids gave us that
soap. They'll swear to it . . . Or will they?
Of course not. Those goddamn treacherous maids will swear they were
menaced by two heavily - armed crazies who threatened them with a Vincent
Black Shadow unless they gave up all their soap.
Jesus Creeping God! Is there a priest in this tavern? I want to
confess! I'm a fucking sinner! Venal, mortal, carnal, major, minor -
however you want to call it, Lord . . . I'm guilty.
But do me this one last favor: just give me five more high - speed hours
before you bring the hammer down; just let me get rid of this goddamn
car and off of this horrible desert.
Which is not really a hell of a lot to ask, Lord, because the
 
incredible truth is that I am not guilty. All I did was take your 
gibberish seriously . . . and you see where it got me? My primitive
Christian instincts have made me a criminal. 
Creeping through the casino at six in the morning with a suitcase full of
grapefruit and "Mint 400" T - shirts, I remember telling myself, over and
over again, "You are not guilty." This is merely a necessary expedient,
to avoid a nasty scene. After all, I made no binding agreements; this is
an institutional debt - nothing personal. This whole goddamn nightmare
is the fault of that stinking, irresponsible magazine. Some fool in New
York did this to me. It was his idea, Lord, not mine.
And now look at me: half - crazy with fear, driving 120 miles an
hour across Death Valley in some car I never even wanted. You evil
bastard! This is your work! You'd better take care of me, Lord
. . . because if you don't you're going to have me on your hands.
 
12. Hellish Speed . . . Grappling with the California Highway Patrol
. . . Mano a Mano on Highway 61
 
Tuesday, 12:30 P.M. . . . Baker, California . . . Into the Ballantine Ale
now, zombie drunk and nervous. I recognize this feeling: three or four
days of booze, drugs, sun, no sleep and burned out adrenalin reserves
- a giddy, quavering sort of high that means the crash is coming. But
when? How much longer? This tension is part of the high. The possibility
of physical and mental collapse is very real now
. . . but collapse is out of the question; as a solution or even a cheap
alternative, it is unacceptable. 
Indeed. This is the moment of truth, that fine and fateful line between
control and disaster - which is also the difference between staying
loose and weird on the streets, or spending the next five years of summer
mornings playing basketball in the yard at Carson City.
No sympathy for the devil; keep that in mind. Buy the ticket, take the
ride . . . and if it occasionally gets a little heavier than what you had
in mind, well . . . maybe chalk it off to forced consciousness expansion:
Tune in, freak out, get eaten. It's all in Kesey's Bible. . . . The Far
Side of Reality.
And so much for bad gibberish; not even Kesey can help me I have just
had two very bad emotional experiences - with the California Highway
Patrol and another with a phantom hitchhiker who may or may not have
been who I thought it was - and now, feeling right on the verge of a
bad psychotic episode, I am hunkered down with my tape machine in a
"beer bar" that is actually the back room of a huge Hardware Barn -
all kinds of plows and harnesses and piled - up fertilizer bags, and
wondering how it all happened.
About five miles back I had a brush with the CHP. Not stopped or pulled
over: nothing routine. I always drive properly. A bit fast, perhaps, but
always with consummate skill and a natural feel for the road that even
cops recognize. No cop was ever born who isn't a sucker for a finely -
executed hi - speed Controlled Drift all the way around one of those
cloverleaf freeway interchanges.
Few people understand the psychology of dealing with a highway traffic
cop. Your normal speeder will panic and immediately pull over to the
side when he sees the big red light behind him . . . and then we will
start apologizing, begging for mercy.
This is wrong. It arouses contempt in the cop - heart. The thing to do -
when you're running along about a hundred or so and you suddenly find a
red - flashing CHP - tracker on your trail - what you want to do then is
accelerate. Never pull over with the first siren - howl. Mash it down and
make the bastard chase you at speeds up to 120 all the way to the next
exit. He will follow. But he won't know what to make of your blinker -
signal that says you're about to turn right.
This is to let him know you're looking for a proper place to pull off and
talk . .. keep signaling and hope for an off - ramp, one of those uphill
side - loops with a sign saying "Max Speed 25" . . . and the trick,
at this point, is to suddenly leave the freeway and take him into the
chute at no less than a hundred miles an hour.
He will lock his brakes about the same time you lock yours, but it will
take him a moment to realize that he's about to make a 180 - degree turn
at this speed . .. but you will be ready for it, braced for the Gs and
the fast heel - toe work, and with any luck at all you will have come
to a complete stop off the road at the top of the turn and be standing
beside your automobile by the time he catches up.
He will not be reasonable at first . . . but no matter. Let him calm
down. He will want the first word. Let him have it. His brain will be
in a turmoil: he may begin jabbering, or even pull his gun. Let him
unwind; keep smiling. The idea is to show him that you were always in
total control of yourself and your vehicle - while he lost control of
everything.
It helps to have a police/press badge in your wallet when he calms down
enough to ask for your license. I had one of these - but I also had a
can of Budweiser in my hand. Until that moment, I was unaware that I was
holding it. I had felt totally on top of the situation . . . but when I
looked down and saw that little red/silver evidence - bomb in my hand,
I knew I was fucked. .
Speeding is one thing, but Drunk Driving is quite another. The cop seemed
to grasp this - that I'd blown my whole performance by forgetting the
beer can. His face relaxed, he actually smiled. And so did I. Because
we both understood, in that moment, that my Thunder Road, moonshine -
bomber act had been totally wasted: We had both scared the piss out of
ourselves for nothing at all - because the fact of this beer can in my
hand made any argument about "speeding" beside the point.
He accepted my open wallet with his left hand, then extended his right
toward the beer can. "Could I have that?" he asked.
"Why not?" I said.
He took it, then held it up between us and poured the beer out on the
road.
I smiled, no longer caring. "It was getting warm, anyway," said. Just
behind me, on the back seat of the Shark, I couldabout ten cans of hot
Budweiser and a dozen or so grapefruits. I'd forgotten all about them,
but now they were too obvious for either one of us to ignore. My guilt
was so gross and overwhelming that explanations were useless.
The cop understood this. "You realize," he said, "that it's a crime to
. .
"Yeah," I said. "I know. I'm guilty. I understand that. I knew it was
a crime, but I did it anyway." I shrugged. 
"Shit, why argue? I'm a fucking criminal."
"That's a strange attitude," he said.
I stared at him, seeing for the first time that I was dealing with a
bright - eyed young sport, around thirty, who was apparently enjoying
his work.
"You know," he said, "I get the feeling you could use a nap." He
nodded. "There's a rest area up ahead. Why don't you pull over and sleep
a few hours?"
I instantly understood what he was telling me, but for some insane reason
I shook my head. "A nap won't help,"I said. "I've been awake for too
long - three or four nights; I can't even remember. If I go to sleep now,
I'm dead for twenty hours."
Good God, I thought. What have I said? This bastard is trying to be human;
he could take me straight to jail, but he's telling me to take a fucking
nap. For Christ sake, agree with him: Yes, officer, of course I'll take
advantage of that rest area. And I can't tell you how grateful I am for
this break you want to give me.
But no . . . here I was insisting that if he turned me loose I would
boom straight ahead for L.A. which was true, but why say it? Why push
him? This is not the right time for a show - down. This is Death Valley
. . . get a grip on yourself.
Of course. Get a grip. "Look," I said. "I've been out in Las Vegas
covering the Mint 400." I pointed to the "VIP Parking" sticker on the
windshield. "Incredible," I said. 
"All those bikes and dune buggies crashing around the desert for two
days. Have you seen it?"
He smiled, shaking his head' with a sort of melancholy un - derstanding. I
could see him thinking. Was I dangerous? 
Was he ready for the vicious, time - consuming scene that was bound
to come if he took me under arrest? How many off - duty hours would he
have to spend hanging around the courthouse, waiting to testify against
me? And what kind of monster lawyer would I bring in to work out on him?
I knew, but how could he?
"OK," he said. "Here's how it is. What goes into my book, as of noon,
is that I apprehended you . . . for driving too fast conditions, and
advised you . . . with this written warning - he handed it to me - "to
proceed no further than the next rest area . . . your stated destination,
right? Where you an to take a long nap . . ." 
He hung his ticket - pad back on his belt. "Do I make myself clear?" he
asked as he turned away.
I shrugged. "How far is Baker? I was hoping to stop there for lunch."
"That's not in my jurisdiction," he said. "The city limits are two -
point - two miles beyond the rest area. Can you make it that far?" He
grinned heavily.
"I'll try," I said. "I've been wanting to go to Baker for a long
time. I've heard a lot about it."
"Excellent seafood," he said. "With a mind like yours, you'll probably
want the land - crab. Try the Majestic Diner."
 
I shook my head and got back in the car, feeling raped. The pig had
done me on all fronts, and now he was going off to chuckle about it -
on the west edge of town, waiting for me to make a run for L.A.
I got back on the freeway and drove past the rest area to the intersection
where I had to turn right into Baker. As I am proached the turn I saw
. . . Great Jesus, it's him, the hitchhiker, the same kid we'd picked
up and terrified on the way out to Vegas. Our eyes met as I slowed down
to make the corner. I was tempted to wave, but when I saw him drop his
thumb I thought, no, this is not the time . . . 
God only knows what that kid said about us when he finally got back to
town. Get out of sight at once. How could I be surerecognized me? But
the car was hard to miss. And why would he back away from the road?
Suddenly I had two personal enemies in this godforsaken town. The CHP
cop would bust me for sure if I tried to go on through to L.A., and this
goddamn rotten kid/hitchhiker would have me hunted down like a beast
if I stayed. (Holy Jesus, Sam! There he is! That guy the kid told us
about! He's 
back!)
Either way, it was horrible - and if these righteous outback predators
ever got their stories together . . . and they would; it was inevitable
in a town this small . . . that would cash my check all around. I'd be
lucky to leave town alive. A ball of tar and feathers dragged onto the
prison bus by angry natives.
This was it: The crisis. 1 raced through town and found a telephone booth
on the northern outskirts, between a Sinclair station and . . . yes
. . . the Majestic Diner. I placed an emergency collect call to my
attorney in Malibu. He answered at once.
"They've nailed me!" I shouted. "I'm trapped in some stinking desert
crossroads called Baker. I don't have much time. The fuckers are closing
in."
"Who?" he said. "You sound a little paranoid."
"You bastard!" I screamed. "First I got run down by the CHP, then that
kid spotted me! I need a lawyer immediately!"
"What are you doing in Baker?" he said. "Didn't you get my telegram?"
"What? Fuck telegrams. I'm in trouble."
"You're supposed to be in Vegas," he said. "We have a suite at the
Flamingo. I was just about to leave for the airport . . . 
I slumped in the booth. It was too horrible. Here I was calling my
attorney in a moment of terrible crisis and the fool was deranged on drugs
- a goddamn vegetable! "You worthless bastard," I groaned. "I'll cripple
your ass for this! All that shit in the car is yours! You understand
that? When I finish testifying out here, you'll be disbarred!"
"You brainless scumbag!" he shouted. "I sent you a telegram! You're
supposed to be covering the National District Attorneys' Conference! I
made all the reservations . . . rented a white Cadillac convertible
. . . the whole thing is arranged! What the hell are you doing out there
in the middle the fucking desert?"
Suddenly I remembered. Yes. The telegram. It was all very clear. My
mind became calm. I saw the whole thing in a flash. "Never mind,"
I said. "It's all a big joke. I'm actually sitting beside the pool at
the Flamingo. I'm talking from a portable phone. Some dwarf brought it
out from the casino. I have total credit! Can you grasp that?" I was
breathing heavily, feeling crazy, sweating into the phone.
"Don't come anywhere near this place!" I shouted. 
"Foreigners aren't welcome here."
I hung up and strolled out to the car. Well, I thought. This is how
the world works. All energy flows according to the whims of the Great
Magnet. What a fool I was to defy him. 
He knew. He knew all along. It was He who sacked me in Baker. I had run
far enough, so He nailed me . . . closing off all my escape routes,
hassling me first with the CHP and then with this filthy phantom
hitchhiker . . . plunging me into fear and confusion.
Never cross the Great Magnet. I understood this now .and with
understanding came a sense of almost terminal relief. Yes, I would go
back to Vegas. Slip the Kid and confound the CHP by moving East again,
instead of West. This would be the shrewdest move of my life. Back to
Vegas and sign 
up for the Drugs and Narcotics conference; me and a thousand pigs. Why
not? Move coilfidently into their midst. Register at the Flamingo and
have the White Caddy sent over at once. Do it right; remember Horatio
Alger. ..
I looked across the road and saw a huge red sign that said
BEER. Wonderful. I left the Shark by the phone booth and reeled across
the highway into the Hardware Barn. A Jew loomed up from behind a pile
of sprockets and asked me what I wanted.
"Ballantine Ale," I said . .. a very mystic long shot, unknown between
Newark and San Francisco.
He served it up, ice - cold.
I relaxed. Suddenly everything was going right; I wasfinally getting
the breaks.
The bartender approached me with a smile. "Where yaheadin', young man?"
"Las Vegas," I said.
He smiled. "A great town, that Vegas. You'll have good luck there;
you're the type."
"I know," I said. "I'm a Triple Scorpio."
He seemed pleased. "That's a fine combination," he said. "You can't
lose."
I laughed. "Don't worry," I said. "I'm actually the districtattorney
from Ignoto county. Just another good American like yourself."
His smile disappeared. Did he understand? I couldn't be sure. But that
hardly mattered now. I was going back to Vegas. I had no choice.
 
Part Two
 
About 20 miles east of Baker I stopped to check the drug bag. The
sun was hot and I felt like killing something. Anything. Even a big
lizard. Drill the fucker. I got my attorney's .357 Magnum out of the
trunk and spun the cylinder. It was loaded all the way around: Long,
nasty little slugs - 158 grains with a fine flat trajectory and painted
aztec gold on the tips. I blew the horn a few times, hoping to call up
an iguana. Get the buggers moving. They were out there, I knew, in that
goddamn sea of cactus - hunkered down, barely breathing, and every one
of the stinking little bastards was loaded with deadly poison.
Three fast explosions knocked me off balance. Three deafening, double -
action blasts from the .357 in my right hand. Jesus! Firing at nothing,
for no reason at all. Bad craziness. I tossed the gun into the front seat
of the Shark and stared nervously at the highway. No cars either way;
the road was empty for two or three miles in both directions.Fine luck. 
It would not do to be found in the desert under these circumstances:
firing wildly into the cactus from a car full of drugs. And especially
not now, on the lam from the Highway Patrol.
Awkward questions would arise: "Well now, Mister .. . ah . . . Duke;
you understand, of course, that it is illegal to dise a firearm of any
kind while standing on a federal way?"
What? Even in self - defense? This goddamn gun has a hair trigger,
officer. The truth is I only meant to fire once - just to scare the
little bastards."
A heavy stare, then speaking very slowly: "Are you saying, Mister Duke
. . . that you were attacked out here?"
"Well . . . no . . . not literally attacked, officer, but seriously
menaced. I stopped to piss, and the minute I stepped out of the car
these filthy little bags of poison were all around me. They moved like
greased lightning!"
Would this story hold up?
No. They would place me under arrest, then routinely search the car -
and when that happened all kinds of savage hell would break loose. They
would never believe all these drugs were necessary to my work; that in
truth I was a professional journalist on my way to Las Vegas to cover the
National District Attorneys' Conference on Narcotics and Dangerous Drugs.
"Just samples, officer. I got this stuff off a road man for the Neo -
American Church back in Barstow. He started acting funny, so I worked
him over."
Would they buy this?
No. They would lock me in some hellhole of a jail and beat me on the
kidneys with big branches - causing me to piss blood for years to come.
 
Luckily, nobody bothered me while I ran a quick inventory on the kit
- bag. The stash was a hopeless mess, all churned together and half -
crushed. Some of the mescaline pellets had disintegrated into a reddish -
brown powder, but I counted about thirty - five or forty still intact. My
attorney had eaten all the reds, but there was quite a bit of speed
left . . . no more grass, the coke bottle was empty, one acid blotter,
a nice brown lump of opium hash and six loose amyls . . . Not enough
for anything serious, but a careful rationing of the mescaline would
probably get us through the four - day Drug Conference.
On the outskirts of Vegas I stopped at a neighborhood pharmacy and
bought two quarts of Gold tequila, two fifths of Chivas Regal and a
pint of ether. I was tempted to ask for some amyls. My angina pectoris
was starting to act up. But druggist had the eyes of a mean Baptist
hysteric. I told n I needed the ether to get the tape off my legs, but
by that time he'd already rung the stuff up and bagged it. He didn't
give a fuck about ether.
I wondered what he would say if I asked him for $22 worth Romilar and a
tank of nitrous oxide. Probably he would sold it to me. Why not? Free
enterprise. . . . Give the public what it needs - especially this bad
- sweaty, nervous talkin' fella with tape all over his legs and this
terrible cough, along with angina pectoris and these godawful Aneuristic
flashes every time he gets in the sun. I mean this fella was in bad
shape, officer. How the hell was I to know he'd walk straight out to
his car and start abusing those drugs?
How indeed? I lingered a moment at the magazine rack, then got a grip
on myself and hurried outside to the car. The idea of going completely
crazy on laughing gas in the middle of a DAs' drug conference had a
definite warped appeal. But not on the first day, I thought. Save that
for later. No point getting busted and committed before the conference
even starts.
I stole a Review - Journal from a rack in the parking lot, 
but I threw it away after reading a story on page one:
 
SURGERY UNCERTAIN
AFTER EYES REMOVED
 
BALTIMORE (UPI) - Doctors said Friday they were uncertain whether
surgery would succeed in restoring the eyesight of a young man who
pulled out his eyes while suffering the effects of a drug over(lose in
a jail cell. Charles Innes, Jr., 25, underwent surgery late Thursday
at Maryland General Hospital but doctors said it be weeks before they
could determine the outcome. statement issued by the hospital reported
that Innes uo light perception in either eye prior to surgery and the
possibility he will ever have light perception is extremely poor." Innes,
son of a prominent Massachusetts Republican, was found in a jail cell
Thursday by a turnkey who said Innes had pulled out his eyeballs.
Innes was arrested Wednesday night while walking nude through a
neighborhood near where he lived. He was examined at Mercy Hospital and
then placed in a jail cell. Police and one of Innes' friends said he
had taken an overdose of animal tranquilizer.
Police reported the drug was PCP, a Parke - Davis product not sold for
human medical purposes since 1963. However, a spokesman for Parke -
Davis said he thought the drug might be available on the black market.
Taken alone, the spokesman said PCP effects would not last more than 12
to 14 hours. However, the effects of PCP combined with an hallucinogen
such as LSD were not known.
Innes told a neighbor last Saturday, the day after he first took the drug,
that his eyes were bothering him and that he could not read.
Wednesday night police said Innes seemed to be in a deeply depressed
state and so impervious to pain that he did not scream when he pulled
out his eyes.
 
2. Another Day, Another Convertible . . . & Another Hotel Full of Cops
 
The first order of business was to get rid of the Red Shark. It was too
obvious. Too many people might recognize it, especially the Vegas police;
although as far as they knew, the thing was already back home in L.A. It
was last seen running at top speed across Death Valley on Interstate
15. Stopped and warned in Baker by the CHP . . . then suddenly disapeared
. . . 
The last place they would look for it, I felt, was in a rental - car lot
at the airport. I had to go out there anyway, to meet my attorney. He
would be arriving from L.A. in the late afternoon.
I drove very quietly on the freeway, gripping my normal instinct for
bursts of acceleration and sudden lane changes - trying to remain
inconspicuous - and when I got there I parked the Shark between two
old Air Force buses in a "utility lot" about half a mile from the
terminal. Very tall buses. Make it hard as possible for the fuckers. A
little walking never hurt anybody.
By the time I got to the terminal I was pouring sweat. But nothing
abnormal. I tend to sweat heavily in warm climates.clothes are soaking wet
from dawn to dusk. This worried at first, but when I went to a doctor and
described my normal daily intake of booze, drugs and poison he told me
to come back when the sweating stopped. That would be the danger point,
he said - a sign that my body's desperately overworked flushing mechanism
had broken down completely. "I have great faith in the natural processes,"
he said. "But in your case . . . well . . . I find no precedent. We'll
just have to wait and see, then work with what's left."
I spent about two hours in the bar, drinking Bloody Marys for the V - 8
nutritional content and watching the flights from L.A. I'd eaten nothing
but grapefruit for about twenty hours and my head was adrift from its
moorings.
You better watch yourself, I thought. There are limits to what the human
body can endure. You don't want to break down and start bleeding from
the ears right here in the terminal. Not in this town. In Las Vegas they
kill the weak and deranged.
I realized this, and kept quiet even when I felt symptoms of a terminal
blood - sweat coming on. But this passed. I saw the cocktail waitress
getting nervous, so I forced myself to get up and walk stiffly out of
the bar. No sign of my attorney.
Down to the VIP car - rental booth, where I traded the Red Shark in for
a White Cadillac Convertible. "This goddamn Chevy has caused me a lot
of trouble," I told them. "I get the feeling that people are putting me
down - especially in gas stations, when I have to get out and open the
hood manually."
"Well . . . of course," said the man behind the desk. 
"What you need, I think, is one of our Mercedes 600 Towne - Cruiser
Specials, with air - conditioning. You can even carry your own fuel,
if you want; we make that available.
"Do I look like a goddamn Nazi?" I said. "I'll have a natural American
car, or nothing at all!"
They called up the white Coupe de Ville at once. Every - thing was
automatic. I could sit in the red - leather driver's seat and make
every inch of the car jump, by touching the proper buttons. It was
a wonderful machine: Ten grand worth of gimmicks and high - priced
Special Effects. The rear - windows leaped up with a touch, like frogs
in a dynamite pond. The white canvas top ran up and down like a roller -
coaster. The dashboard was full of esoteric lights & dials & meters that
I would never understand - but there was no doubt 
in my mind that I was into a superior machine.
The Caddy wouldn' tget off the line quite as fast as the RedShark, but
once it got rol around eighty - it was pure smooth hell . . . all that
elegant, upholstered weight lashing across the desert was like rolling
through midnight on the old California Zephyr. - - 
I handled the whole transaction with a credit card that I later learned
was "banceled" - completely bogus. But the Big Computer hsdn't mixed me
yet, so I was still a fat gold credit risk.
Later, looking back on this transaction, I knew the conversation that
had almost certainly etisued:
"Hello. This is VIP car - rentals in Las Vegas. We're calling to check
on Number 875 - 045 - 6169. Just a routine credit check, nothing urgent
. . . (Long pause at the other end. Then:) "Holy shit!" 
"What?"
"Pardon me. . . Yes, we have that number. It's been placed on emergency
redline status. Call the police at once and don't let him out of your
sight!"
(Another long pause) "Well . . . ah . . . you see, that number is not
on our current Red List, and . . . ah . . . Number875 - 045 - 616 -
B just left our lot in a new Cadillac convertible."
"No!"
"Yes. He's long gone; totally insured."
"Where?"
"I think he said St. Louis. Yes, that's what the card says.
Raoul Duke, leftfielder & batting champion of the St. Loui sBrowns. Five
days at $25 per, plus twenty - five cents a mile.His card was valid,
so of course we had no choice . . . This is true. The car rental
agency had no legal reason to hassle me, since my card was technically
valid. During the next four days I drove that car all over Las Vegas -
even the VIP agency's main office on Paradise Boulevard several times -
and at no time was I bothered by any show of rudeness.
This is one of the hallmarks of Vegas hospitality. The only bedrock rule
is Don't Burn the Locals. Beyond that, nobody cares. They would rather
not know. If Charlie Manson checked into the Sahara tomorrow morning,
nobody would hassle him as long as he tipped big.
 
I drove straight to the hotel after renting the car. There was still
no sign of my attorney, so I decided to check in on my own - if only
to get off the street and avoid a public breakdown. I left the Whale in
a VIP parking slot and shambled self - consciously into the lobby with
one small leather bag - a hand - crafted, custom - built satchel that
had just been made for me by a leathersmith friend in Boulder.
Our room was at the Flamingo, in the nerve - center of theStrip: right
across the street from Caesar's Palace and the Dunes - site of the Drug
Conference. The bulk of the conferees were staying at the Dunes, but
those of us who signed up fashionably late were assigned to the Flamingo.
The place was full of cops. I saw this at a glance. Most of them were
just standing around trying to look casual, all dressed exactly alike
in their cut - rate Vegas casuals: plaid bermuda shorts, Arnie Palmer
golf shirts and hairless white legs tapering down to rubberized "beach
sandals." It was a terrifying scene to walk into - a super stakeout of
some kind. If I hadn't known about the conference my mind might have
snapped. You got the impression that somebody was going to be gunned down
in a blazing crossfire at any moment - maybe the entire Manson Family.
My arrival was badly timed. Most of the national DAs and other cop -
types had already checked in. These were the people who now stood around
the lobby and stared grimly at newcomers. What appeared to be the Final
Stakeout was only about two hundred vacationing cops with nothing better
to do. They didn't even notice each other.
I waded up to the desk and got in line. The man in front of me was a
Police Chief from some small town in Michigan. His Agnew - style wife
was standing about three feet off to his right while he argued with the
desk clerk: "Look, fella - I told you I have a postcard here that says I
have reservations in this hotel. Hell, I'm with the District Attorneys'
Conference! I've already paid for my room."
"Sorry, sir. You're on the 'late list.' Your reservations were transferred
to the . . . ah . . . Moonlight Motel, which is out on Paradise Boulevard
and actually a very fine place of lodging and only sixteen blocks from
here, with its own pool and . . . 
"You dirty little faggot! Call the manager! I'm tired of listening to
this dogshit!"
The manager appeared and offered to call a cab. This was obviously the
second or maybe even the third act in a cruel drama that had begun long
before I showed up. The police chief's wife was crying; the gaggle of
friends that he'd mustered for support were too embarrassed to back him
up - even now, in this showdown at the desk, with this angry little cop
firing his best and final shot. They knew he was beaten; he was going
against the RULES, and the people hired to enforce those rules said
"no vacancy.
After ten minutes of standing in line behind this noisy little asshole and
his friends, I felt the bile rising. Where did this cop - of all people
- get the nerve to argue with anybody in terms of Right & Reason? I
had been there with these fuzzy shitheads - and so, I sensed, had the
desk clerk. He had airof a man who'd been fucked around, in his time,
by a good cross - section of mean - tempered rule - crazy now he was
just giving their argument back to them: It didn't matter who's right
or wrong, man . . . or who's paid & who hasn't . . . what matters right
now is that for at time in my life I can work out on a pig: "Fuck you,
I'm in charge here, and I'm telling you we don't have for you."
I was enjoying this whipsong, but after a while I felt dizzy, nervous,
and my impatience got the better of my amusement. So I stepped around
the Pig and spoke directly to the desk clerk - "Say," I said, "I hate
to interrupt, but I have a reservation and I wonder if maybe I could
just sort of slide through and get out of your way." I smiled, letting
him know I'd been digging his snake - bully act on the cop party that
was now standing there, psychologically off - balance and staring at me
like I was some kind of water - rat crawling up to the desk.
I looked pretty bad: wearing old Levis and white Chuck Taylor All - Star
basketball sneakers . . . and my ten - peso Acapulco shirt had long since
come apart at the shoulder seams from all that road - wind. My beard was
about three days old, bordering on standard wino trim, and my eyes were
totally hidden by Sandy Bull's Saigon - mirror shades.
But my voice had the tone of a man who knows he has a reservation. I
was gambling on my attorney's foresightbut I couldn't pass a chance
to put the horn into a cop:and I was right. The reservation was in
my attorney's name. The desk - clerk hit his bell to summon the bag -
boy. "This is all I have with me, right now," I said, "The rest is out
there in that white Cadillac convertible." I pointed to the car that we
could all see parked just outside the front door. "Can you have somebody
drive it around to the room?"
The desk - clerk was friendly. "Don't worry about a thing, sir. Just enjoy
your stay here - and if there's anything you need, just call the desk."
I nodded and smiled, half - watching the stunned reaction of the cop
- crowd right next to me. They were stupid with shock. Here they were
arguing with every piece of leverage they could command, for a room they'd
already paid for - and suddenly their whole act gets side - swiped by some
crusty drifter who looks like something out of an upper - Michigan hobo
jungle. And he checks in with a handful of credit cards! Jesus! What's
happening in this world?
 
3. Savage Lucy . . . "Teeth Like Baseballs, Eyes Like Jellied Fire"
 
I gave my bag to the boy who scurried up, and told him to bring a quart of
Wild Turkey and two fifths of Bacardi Anejo with a night's worth of ice.
Our room was in one of the farthest wings of the Flamingo. The place
is far more than a hotel: It is a sort of huge underfinanced Playboy
Club in the middle of the desert. Something like nine separate wings,
with interconnecting causeways and pools - a vast complex, sliced up by
a maze of car - ramps and driveways. It took me about twenty minutes to
wander from the desk to the distant wing we'd been assigned to.
My idea was to get into the room, accept the booze and baggage delivery,
then smoke my last big chunk of Singapore Grey while watching Walter
Cronkite and waiting for my attorney to arrive. I needed this break,
this moment of peace and refuge, before we did the Drug Conference. It
was going to be quite a different thing from the Mint 400. That had been
observer gig, but this one would need participation - and a special
stance: At the Mint 400 we were dealing with anessentially simpatico
crowd, and if our behavior was gross outrageous . . . well, it was only
a matter of degree.this time our very presence would be an outrage. We
be attending the conference under false pretenses and from the start,
with a crowd that was convened for d purpose of putting people like us
in jail. We were the Menace - not in disguise, but stone - obvious drug
abusers, with a flagrantly cranked - up act that we intended to push all
the way to the limit . . . not to prove any final, sociological point,
and not even as a conscious mockery: It was mainly a matter of life -
style, a sense of obligation and even duty. If the Pigs were gathering
in Vegas for a top - level Drug Conference, we felt the drug culture
should be represented.
Beyond that, I'd been out, of my head for so long now, that a gig like
this seemed perfectly logical. Considering the circumstances, I felt
totally meshed with my karma.
 
Or at least I was feeling this way until I got to the big grey door
that opened into Mini - Suite 1150 in the Far Wing. I rammed my key
into the knob - lock and swung the door open, thinking, "Ah, home at
last!" . . . but the door hit something, which I recognized at once as
a human form: a girl of indeterminate age with the face and form of a
Pit Bull. She was wearing a shapeless blue smock and her eyes were angry
. . . 
Somehow I knew that I had the right room. I wanted to think otherwise,
but the vibes were hopelessly right . . . and she seemed to know, too,
because she made no move to stop me when I moved past her and into the
suite. I tossed my leather satchel on one of the beds and looked around
for what I knew I would see . . . my attorney .. . stark naked, standing
in the bathroom door with a drug - addled grin on his face.
"You degenerate pig," I muttered.
"It can't be helped," he said, nodding at the bulldog girl. 
"This is Lucy." He laughed distractedly. "You know - like Lucy in the
sky with diamonds . .
I nodded to Lucy, who was eyeing me with definite venom. I was clearly
some kind of enemy, some ugly intrusion on her scene . . . and it was
clear from the way she moved around the room, very quick and tense on
her feet, that she was sizing me up. She was ready for violence,there
was not much doubt about that. Even my attorney picked up on it.
"Lucy!" he snapped. "Lucy! Be cool, goddamnit! Remember what happened at
the airport . . . no more of that, OK?" He smiled nervously at her. She
had the look of a beast that had just been tossed into a sawdust pit to
fight for its life . . . 
"Lucy . .. this is my client; this is Mister Duke, the famous
journalist. He's pairing for this suite, Lucy. He's on our side." 
She said nothing. I could see that she was not entirely in control of
herself. Huge shoulders on the woman, and a chin like Oscar Bonavena. I
sat down on the bed and casually reached into my satchel for the Mace can
. . . and when I felt my tumb on the Shoot button I was tempted to jerk
the thing out and soak her down on general principles, I desperately
needed peace, rest, sanctuary. The last thing I wanted was a fight to
the finish, in my own hotel room, with some kind of drug - crazed hormone
monster.
My attorney seemed to understand this; he knew why my hand was in the
satchel.
"No!" he shouted. "Not here! We'll have to move out!"
I shrugged. He was twisted. I could see that. And so was Lucy. Her eyes
were feverish and crazy. She was staring at me like I was something
that would have to be rendered helpless before life could get back to
whatever she considered normal.
My attorney idled over and put his arm around her shoulders. "Mister
Duke is my friend," he said gently. "He lovesartists. Let's show him
your paintings."
For the first time, I noticed that the room was full of artwork - maybe
forty or fifty portraits, some in oil, some charcoal, all more or less
the same size and all the same face. 
They were propped up on every flat surface. The face was vaguely familiar,
but I couldn't get a fix on it. It was a girl with a mouth, a big nose
and extremely glittering eyes - a demonically sensual face; the kind
of overstated, embarrassingly dramatic renderings that you find in the
bedrooms of young female art students who get hung up on horses.
'Lucy paints portraits of Barbra Streisand," my attorney explained. "She's
an artist up in Montana.. ." He turned to the girl. 
"What's that town where you live?"
She stared at him, then at me, then back at my attorney again. Then 
finally she said, "Kalispel. Way up north. I drew these from TV."
My attorney nodded eagerly. "Fantastic," he said. "She came all the way
down here just to give all these 
portraits to Barbra. We're going over to the Americana Hotel tonight,
and meet her backstage."
Lucy smiled bashfully. There was no more hostility in her. I dropped the
Mace can and stood up. We obviously had a serious case on our hands. I
hadn't counted on this: 
Finding my attorney whacked on acid and locked into some kind of
preternatural courtship.
"Well," I said, "I guess they've brought the car around by now. Let's
get the stuff out of the trunk."
He nodded eagerly. "Absolutely, let's get the stuff." Hesmiled at
Lucy. "We'll be right back. Don't answer the phone if it rings."
She grinned and made the one - finger Jesus freak sign. "God bless,"
she said.
My attorney pulled on a pair of elephant - leg pants and a glaze -
black shirt, then we hurried out of the room. I could see he was having
trouble getting oriented, but I refused to humor him.
"Well . . ." I said. "What are your plans?"
"Plans?"
We were waiting for the elevator.
"Lucy," I said.
He shook his head, struggling to focus on the question. 
"Shit," he said finally. "I met her on the plane and I had all that
acid." He shrugged. "You know, those little blue barrels. Jesus, she's
a religious freak. She's running away from home for something like the
fifth time in six months. It's terrible. I gave her that cap before I
realized . . . shit, she's never even had adrinkf'
"Well," I said, "it'll probably work out. We can keep her loaded and
peddle her ass at the drug convention."
He stared at me.
"She's perfect for this gig," I said. "These cops will go fifty bucks
a head to beat her into submission and then gang - fuck her. We can set
her up in one of these back - street motels, hang pictures of Jesus all
over the room, then turn these pigsloose on her . . . Hell, she's strong;
she'll hold her own."
His face was twitching badly. We were in the elevator now, descending
into the lobby. "Jesus Christ," he muttered. "I knew you were sick,
but I never expected to hear you actually say that kind of stuff."
He seemed stunned.
I laughed. "It's straight economics. This girl is a godsend!" I fixed him
with a natural Bogart smile, all teeth .. . Shit, we're almost broke! And
suddenly you pick up some muscle - bound loony who can make us a grand
a day."
"No!" he shouted. "Stop talking like that!" The elevator door opened
and we walked toward the parking lot.
"I figure she can do about four at a time," I said. 
"Christ, if we keep her full of acid that's more like two grand a day;
maybe three."
"You filthy bastard!" he sputtered. "I should cave your fucking head
in!" He was squinting at me, shielding his eyes from the sun. I spotted
the Whale about fifty feet from the door. "There it is," I said. "Not
a bad looking car, for a pimp ..
He groaned. His face reflected the struggle that I knew he was having,
in his brain, with sporadic acid rushes: Bad waves of painful intensity,
followed by total confusion. 
When I opened the trunk of the Whale to get the bags, he got angry. "What
the hell are you doing?" he snapped. 
"This isn't Lucy's car."
"I know," I said. "It's mine. This is my luggage."
"The fuck it is!" he shouted. "Just because I'm a goddamn 'I lawyer
doesn't mean you can walk around stealing stuff right in front of me!" He
backed away. "What the hell is wrong with you? We'll never beat a rap
like this."
 
After much difficulty, we got back to the room and tried to have a
serious talk with Lucy. I felt like a Nazi, but it had to be done. She
was not right for us - not in this fragile situation. It was bad enough
if she were only what she appeared to be - a strange young girl in the
throes of a bad psychotic episode - but what worried me far more than
that was the likelihood that she would probably be just sane enough,
in a few hours, to work herself into a towering Jesus - based rage at
the hazy recollection of being picked up and seduced in the Los Angeles
International Airport by some kind of cruel Samoan who fed her liquor
and LSD, then dragged her to a Vegas hotel room and savagely penetrated
every orifice in her body with his throbbing, uncircumcised member.
I had a terrible vision of Lucy crashing into Barbra Strei - sand's
dressing room at the Americana and laying thisbrutal story on her. That
would finish us. They would track us down and probably castrate us both,
prior to booking
I explained this to my attorney, who was now in tears at the idea of
sending Lucy away. She was still powerfully twisted, and I felt the only
solution was to get her as far as possible from the Flamingo before she
got straight enough to remember where she'd been and what happened to
her.
Lucy, while we argued, was lying on the patio, doing a charcoal sketch of
Barbra Streisand. From memory this time. It was a full - faced rendering,
with teeth like baseballs and eyes like jellied fire.
The sheer intensity of the thing made me nervous. This girl was a walking
bomb. God only knows what she might be doing with all that mis - wired
energy right now if she didn't have her sketch pad. And what was she
going to do when she got straight enough to read The Vegas Vistitor,
as I just had, and learn that Streisand wasn't due at the Americana for
another three weeks?
My attorney finally agreed that Lucy would have to go. The possibility
of a Mann Act conviction, resulting in disbarment proceedings and total
loss of his livelihood, was a key factor in his decision. A nasty federal
rap. Especially for a monster Samoan facing a typical white middle -
class jury in Southern California.
"They might even call it kidnapping," I said. "Straight to the gas
chamber, like Chessman. And even if you 
manage to beatthat, they'll send you back to Nevada for Rape and
Congensual Sodomy."
"No!" he shouted. "I felt sorry for the girl, I wanted to help her!"
I smiled. "That's what Fatty Arbuckle said, and you know what they did
to him."
"Who?"
"Never mind," I said. "Just picture yourself telling a jury that you
tried to help this poor girl by giving her LSD and then taking her out
to Vegas for one of your special stark - naked back rubs."
He shook his head sadly. "You're right. They'd probably burn me at
the goddamn stake . . . set me on fire right there in the dock. Shit,
it doesn't pay to try to help somebody these days ..
We coaxed Lucy down to the car, telling her that we thought it was about
time to "go meet Barbra." We had no trouble convincing her that she
should take all her artwork, but she couldn't understand why my attorney
wanted to bring her suitcase along. "I don't want to embarrass her," she
protested. "She'll think I'm trying to move in with her, or something."
"No she won't," I said quickly . . . but that was all I could think of
to say. I felt like Martin Bormann. What would happen to this poor wretch
when we cut her loose? Jail? White slavery? What would Dr. Darwin do under
these circumstances? (Survival of the . . . fittest? Was that the proper
word? Had Darwin ever considered the idea of temporary unfitness? Like
"temporary insanity." Could the Doctor have made room in his theory for
a thing like LSD?)
All this was academic, of course. Lucy was a potentially fatal millstone
on both our necks. There was absolutely no choice but to cut her adrift
and hope her memory was fucked. But some acid victims - especially
nervous mongoloids - have a strange kind of idiot - sapient capacity
for remembering odd details and nothing else. It was possible that Lucy
might spend two more days in the grip of total amnesia, then snap out of
it with no memory of anything but ourroom number at the Flamingo . . . .
I thought about this . . . but the only alternative was to take her out
to the desert and feed her remains to the lizards. I wasn't ready for
this; it seemed a bit heavy for the thing we were trying to protect:
My attorney. It came down to that. 
So the problem was to work out a balance, to aim Lucy in a direction
that wouldn't snap her mind and provoke a disastrous backlash.
She had money. My attorney had ascertained that. "At least $200," he'd
said. "And we can always call the cops up there in Montana, where she
lives, and turn her in."
I was reluctant to do this. The only thing worse than turning her loose
in Vegas, I felt, was turning her over to "the authorities" . . . and
that was clearly out of the question, anyway. Not now. "What kind of
goddamn monster are you?" I said. "First you kidnap the girl, then you
rape her, and now you want to have her locked up!"
He shrugged. "It just occurred to me," he said, "that she has no
witnesses. Anything she says about us is completely worthless."
"Us?" I said.
He stared at me. I could see that his head was clearing. The acid was
almost gone. This meant that Lucy was probably coming down, too. It was
time to cut the cord.
Lucy was waiting for us in the car, listening to the radio with a twisted
smile on her face. We were standing about ten yards off. Anybody watching
us from a distance might have thought we were having some kind of vicious,
showdown argurnent about who had "rights to the girl." It was a standard
scene for a Vegas parking lot.
We finally decided to make her a reservation at the Americana. My attorney
ambled over to the car and got her last name under some pretense, then
I hurried inside and called the hotel - saying that I was her uncle and
that I wanted her to be "treated very gently," because she was an artist
and might seem a trifle high - strung. The room clerk assured me they'd
give her every courtesy.
Then we drove her out to the airport, saying we were going to trade the
White Whale in for a Mercedes 600, and my attorney took her into the
lobby with all her gear. She was still unhinged and babbling when he
led her away. I drove around a corner and waited for him.
Ten minutes later he shuffled up to the car and got in. "Take off slowly,"
he said. "Don't attract any attention."
When we got out on Las Vegas Boulevard he explained that he'd given one of
the airport cab - hasslers a $10 bill to see that his "drunk girlfriend"
got to the Americana, where she had a reservation. "I told him to make
sure she got there," he said.
"You think she will?"
He nodded. "The guy said he'd pay the fare with the extra five bucks I
gave him, and tell the cabbie to humor her. I told him I had some business
to take care of, but I'd be there myself in an hour - and if the girl
wasn't already checked in, I'd come back out here and rip his lungs out."
"That's good," I said. "You can't be subtle in this town." He grinned. "As
your attorney, I advise you to tell me where you put the goddamn
mescaline."
I pulled over. The kit - bag was in the trunk. He fetched out two
pellets and we each ate one. The sun was going down behind the scrub
hills northwest of the city. A good Kristofferson tune was croaking out
of the radio. We cruised back to town through the warm dusk, relaxed on
the red leather seats of our electric white Coupe de Ville.
"Maybe we should take it easy tonight," I said as we flashed past the
Tropicana.
"Right," he said. "Let's find a good seafood restaurant and some red
salmon. I feel a powerful lust for red salmon."
I agreed. "But first we should go back to the hotel and set - in. Maybe
have a quick swim and some rum."
He nodded, leaning back on the seat and staring up at the sky. Night
was coming down slowly.
 
4. No Refuge for Degenerates . . . Reflections on a Muderous Junkie
 
We drove through the parking lot of the Flamingo and around the back,
through the labyrinth, to our wing. No problem with parking, no problem
with theelevator, and the suite was dead quiet when we entered: half-dark
and peacefully elegant, with big sliding walls opening out on the lawn
and the pool.
The only thing moving in the room was the red-blinking message light on
the telephone. "Probably room service," I said. "I ordered some ice and
booze. I guess it came while we were gone.
My attorney shrugged. "We have plenty," he said. "But we might as well
get more. Hell yes, tell them to send it up."
I picked up the phone and dialed the desk. "What's the mes sage?" I
asked. "My light is blinking."
The clerk seemed to hesitate. I could hear papers shuffling. "Ah yes," he
saidfinally. "Mister Duke? Yes, you have two messages. One says, 'Welcome
to Las Vegas, from the Na tional District Attorneys' Association."'
"Wonderful," I said.
" . . . . and the other," he continued, "says, 'Call Lucy at the
Americana, room 1000."'
'What?"
He repeated the message. There was no mistake.
"Holy shit!" I muttered.
"Excuse me?" said the clerk.
I hung up.
 
  
 
My attorney was doing the Big Spit again, in the bathroom. I walked out
on the balcony and stared at the pool, this kidney-shaped bag of bright
water that shimmered outside our suite. I felt like Othello. Here I'd
only been in town a few hours, and we'd already laid the groundwork for
a classic tragedy. The hero was doomed; he had already sown the seed of
his own downfall.
But who was the Hero of this filthy drama? I turned away from the pool
and confronted my attorney, now emerging from the bathroom and wiping
his mouth with a towel. His eyes were glazed and limpid. "This goddamn
mescaline," he muttered. "Why the fuck can't they make it a little less
pure? Maybe mix it up with Rolaids, or something?"
"Othello used Dramamine," I said.
He nodded, hanging the towel around his neck as he reached out to flip on
the TV set. "Yeah, I heard about those remedies. Your man Fatty Arbuckle
used olive oil."
"Lucy called," I said.
"What?" He sagged visibly - like an animal taking a bullet. "I just got
the message from the desk. She's at the Americana, room 1600 . . . and
she wants us to call."
He stared at me . . . and just then the phone rang.
I shrugged and picked it up. There was no point trying to hide. She had
found us, and that was enough.
"Hello," I said.
It was the room clerk again.
"Mister Duke?"
"Yes."
"Hello, Mister Duke. I'm sorry we were cut off a moment ago.., but I
thought I should call again, because I was won dering . .
"What?" I sensed things closing down on us. This fucker was about to
spring something on me. What had that crazy bitch aid to him? I tried
to stay calm.
"We're watching the goddamn news!" I screamed. "What the fuck are you
interrupting me for?"
Silence.
"What do you want? Where's the goddamn ice I ordered? Where's the
booze? There's a war on, man! People are being killed!"
"Killed?" He almost whispered the word.
"In Vietnam!" I yelled. "On the goddamn television!"
"Oh . . . yes . . . yes," he said. "This terrible war. When will it end?"
"Tell me," I said quietly. "What do you want?"
"Of course," he said, snapping back to his desk-clerk tone. "I thought
I should tell you . . . because I know you're here with the Police
Convention . . . that the woman who left that message for you sounded
very disturbed."
He hesitated, but I said nothing.
"I thought you should know this," he said finally.
"What did you say to her?" I asked.
"Nothing. Nothing at all, Mister Duke. I merely took the message." He
paused.
"But it wasn't that easy, talking to that woman. She was . . . well
. . . extremelynervous. I think she was crying."
"Crying?" My brain had locked up. I couldn't think. The drug was taking
over. "Why was she crying?"
"Well . . . ah . . . she didn't say, Mister Duke. But since I knew the
nature of your work I thought . . . "
"I know," I said quickly. "Look, you want to be gentle with that woman
if sheever calls again. She's our case study. We're watching her very
carefully." I felt my head unwind ing now; the words came easily:
"She's perfectly harmless, of course . . . there'll be no trouble
. . . this woman has been into laudanum, it's a controlled experiment,
but I suspect we'll need your cooperation before this thing is over."
"Well . . . certainly," he said. "We're always happy to cooperate with
the police . . . just as long as there won't be any rouble . . . for us,
I mean."
"Don't worry," I said. "You're protected. Just treat this or woman like
you'd treat any other human being in trouble."
"What?" He seemed to be stuttering. "Ah . . . yes, yes, I see what you
meen . . . yes . . . so you'll be responsible then?"
"Of course," I said. "And now I have to get back to the news."
"Thank you," he muttered.
"Send the ice," I said, and hung up.
My attorney was smiling peacefully at the TV set. "Good work," he
said. "They'll treat us like goddamn lepers, after that." I nodded,
filling a tall glass with Chivas Regal.
"There hasn't been any news on the tube for three hours," he said
absently.
"That poor fool probably thinks we're plugged into some kind of special
cop channel. You should call back and ask him to send up a 3000 watt
sensing capacitator, along with the ice. Tell him ours just burned out ..
"You forgot about Lucy," I said. "She's looking for you."
He laughed. "No, she's looking for you."
"Me?"
"Yeah. She really flipped over you. The only way I could get rid of
her, out there in the airport, was by saying you were taking me out
to the desert for a showdown - that you wanted me out of the way so
you could have her all to yourself." He shrugged. "Shit, I had to tell
her something. I said she should go to the Americana and wait to see
which one of us came back." He laughed again. "I guess she figures you
won. That phone message wasn't for me, was it?"
I nodded. It made no sense at all, but I knew it was true. Drug
reasoning. The rhythms were brutally clear - and, to him, they made
excellent sense.
He was slumped in the chair, concentrating on Mission Im possible.
I thought for a while, then stood up and began stuffing things into my
suitcase.
"What are you doing?" he asked.
"Never mind," I said. The zipper stuck momentarily, butl yanked it
shut. Then I put on my shoes.
"Walt a minute," he said. "Jesus, you're not leaving?"
I nodded. "You're goddamn right, I'm leaving. But don't worry. I'll stop
at the desk on my way out. You'll be taken care of."
He stood up quickly, kicking his drink over. "OK, god damnit, this is
serious! Where's my .357?"
I shrugged, not looking at him as I crammed the Chivas Regal bottles
into my hand-satchel. "I sold it in Baker," I said. "I owe you 35 bucks."
"Jesus Christ!" he shouted. "That thing cost me a hundred and ninety
goddamn dollars!"
I smiled. "You told me where you got that gun," I said. "Remember?"
He hesitated, pretending to think. "Oh yeah," he said finally. "Yeah
. . . that punk out in Pasadena .. ." Then he flared again. "So it
cost me a goddamn grand. That asshole shot a narc. He was looking at
life! . . . shit, three weeks in court, and all I got was a fucking
six-shooter."
"You're stupid," I said. "I warned you about dealing with junkies on
credit - especially when they're guilty. You're lucky the bastard didn't
pay you off with a bullet in the stomach."
My attorney sagged. "He was my cousin. The jury found him innocent."
"Shit!" I snapped. "How many people has that junkie bastard shot since
we've known him? Six? Eight? That evil little tuck is so guilty that
I should probably kill him myself, on general principles. He shot that
narc just as sure as he killed that girl at the Holiday Inn . . . and
that guy in Ventura!"
He eyed me coldly. "You better be careful, man. You're into some heavy
slander."
I laughed, tossing my luggage together in a lump at the foot of the
bed while I sat down to finish my drink. I actually intended to leave. I
didn't really want to, but I figured that nothing I could possibly do with
this gig was worth the risk of tangled up with Lucy . . . No doubt she
was a beautiful person, if she ever got straight . . . very sensative,
with a secret reserve karma undernenth her Pit Bull act; a great talent
with fine instincts . . . Just a heavy little gal who unfortunately went
stone crazy somewhere prior to her eighteenth birthday.
I had nothing personal against her. But I knew she was perfectly capable
- under these circumstances - of sending us both to prison for at least
twenty years, on the strength of some heinous story we would probably
never even hear until she took the stand:
"Yessir, those two men over there in the dock are the ones who gave me
the LSD and took me to the hotel . .
"And what did they do then, Lucy?"
"Well, sir, I can't rightly remember . .
"Indeed? Well, perhaps this document from the District At torney's
files will refresh your memory, Lucy . . . This is the statement you
made to Officer Squane shortly after you were found wandering naked in
the desert near Lake Mead."
"I don't know for sure what they done to me, but I remem ber it was
horrible. One guy picked me up in the Los Angeles airport; he's the one
who gave me the pill . . . and the other one met us at the hotel; he was
sweating real bad and he talked so fast that I couldn't understand what
he wanted . . . No sir, I don't recall exactly what they did to me at that
point, because I was still under the influence of that drug . . . yessir,
the LSD they gave me . . . and I think I was naked for a long time,
maybe the whole time they had me there. I think it was evening, because
I remember they had the news on. Yessir, Walter Cronkite, I remember
his face all through it . . . "
No, I was not ready for this. No jury would doubt her testi mony,
especially when it came stuttering out through a fog of tears and obscene
acid flashbacks. And the fact that she couldn't recall precisely what we
had done to her would make it impossible to deny. The jury would know
what we'd done. They would have read about people like us in the $2.95
paper backs: Up To The Hilt and Only Skin Deep, . and seen your type in
the $5 fuck-flicks.
And of course we could'nt possibly taking the stand in our own defense -
not after they'd cleaned out the trunk of the Whale: "And I'd like to
point out, Your Honor, that, our Prosecution Exhibits A through Y are
available to the jury - yes, this incredible collection of illegal
drugs and narcotics which the defendants had in their possession at
the time of their arrests and forcible seizure by no less than nine
officers, six of whom are still hospitalized . . . and also Exhibit Z,
sworn testimony by three professional narcotics experts selected by the
president of the National District Attorneys' Conference - which was
seriously embarrassed by the defendants' attempts to infiltrate, disrupt
and pervert their annual convention . . . these experts have testified
that the drug cache in the possession of these defendants at the time
of the arrests was enough to kill an entire platoon of United States
Marines . . . and gentlemen, I use the word kill with all due respect for
the fear and loathing I'm sure it provokes in every one of you when you
reflect that these degenerate rapists used this galaxy of narcotics to
completely destroy the mind and morals of this once-innocent teenager,
this ruined and de graded young girl who now sits before you in shame
. . . yes, they fed this girl enough drugs to scramble her brains so
hor ribly that she can no longer even recall the filthy details of that
orgy she was forced to endure . . . and then they used her, ladies and
gentlemen of the jury, for their own unspeakable ends!"
 
5. A Terrible Experience with Extremely Dangerous Drugs. 
There was no way to cope with it. I stood up and gathered my luggage. It
was important, I felt, to get out of town immediately.
My attorney seemed to finally grasp this. "Wait!" he shouted. "You can't
leave me alone in this snake pit! This room is in my name."
I shrugged.
"OK, goddamnit," he said, moving toward the phone.
"Look, I'll call her. I'll get her off our backs." He nodded.
"You're right. She's my problem."
I shook my head. "No, it's gone too far."
"You'd make a pisspoor lawyer," he replied. "Relax. I'll handle this."
He dialed the Americana and asked for 1600. "Hi, Lucy," he said. "Yeah,
it's me. I got your message . . . what? Hell no, I taught the bastard
a lesson he'll never forget.., what? . . . o, not dead, but he won't be
bothering anybody for a while - yeah, I left him out there; I stomped him,
then pulled all teeth out..
Jesus, I thought. What a terrible thing to lay on somebody a head full
of acid.
"But here's the problem," he was saying. "I have to leave here right
away. That bastard cashed a bad check downstairs and gave you as a
reference, so they'll be looking for both of you . . . yeah, I know,
but you can't judge a book by it's cover, Lucy; some people are just
basically rotten . . . anyway, the pie as a reference, so they'll be
looking for both of us. The last thing in the world you want to do is
call this hotel again; they'll trace the call and put you straight behind
bars . . . no, I'm moving to the Tropicana right away; I'll call you from
there when I know my room number . . . yeah, probably two hours; I have
to act casual, or they'll capture me too . . . I think I'll probably use
a different name, but I'll let you know what it is . . . sure, just as
soon as I check in . . . what? of course; we'll go to the Circus-Circus
and catch the polar bear act; it'll freak you right out . .
He was nervously shifting the phone from ear to ear while he talked:
"No . . .listen, I have to get off; they probably have the phone tapped
. . . yeah, I know, it was horrible, but it's all over now. . . 0 MY
GOD! THEY'RE KICKING THEDOOR DOWN!" He hurled the phone down and began
shout ing: "No! Get away from me! I'm innocent! It was Duke! I swear to
God!" He kicked the phon against the wall, then leaned down to it and
began yelling again: "No, I don't know where she is! I think she went
back to Montana. You'll never catch Lucy! She's gone!" He kicked the
receiver again, then picked it up and held it about a foot away from
his mouth as he uttered a long, quavering groan. "No! No! Don't put that
thing on me!" he screamed. Then he slammed the phone down.
"Well," he said quietly. "That's that. She's probably stuffing herself
down the incinerator about now." He smiled. "Yeah, I think that's the
last we'll be hearing from Lucy."
I slumped on the bed. His performance had given me a bad jolt. For a
moment I thought his mind had snapped-that he actually believed he was
being attacked by invisible enemies.
But the room was quiet again. He was back in his chair, watching Mission
Impossible and fumbling Idly with the hash pipe. It was empty. "Where's
that opium?" he asked.
I tossed him the kit-bag. "Be careful," I mattered. "There's not 'such
left."
He chuckled,. "As your attorney," he said, "I advise you not worry." He
nodded toward the bathroom. "Take a hit out of that little brown bottle
in my shaving kit."
"What is it?"
"Adrenochrome," he said. "You won't need much. Just a little tiny taste."
I got the bottle and dipped the head of a paper match intoit.
"That's about right," he said. "That stuff makes pure mescaline seem
like gingerbeer. You'll go completely crazy if you take too much."
I licked the end of the match. "Where'd you get this?" I asked. "You
can't buy it."
"Never mind," he said. "It's absolutely pure."
I shook my head sadly. "Jesus! What kind of monster client have you
picked up this time? There's only one source for this stuff . .
He nodded.
"The adrenaline glands from a living human body," I said. "It's no good
if youget it out of a corpse."
 
"I know," he replied. "But the guy didn't have any cash. He's one of these
Satanism freaks. He offered me human blood - said it would make me higher
than I'd ever been in my life," he laughed. "I thought he was kidding,
so I told him I'd just as soon have an ounce or so of pure adrenochrome -
or maybe just a fresh adrenalin gland to chew on."
I could already feel the stuff working on me. The first wave felt like
a combination of mescaline and methedrmne. Maybe I should take a swim,
I thought.
"Yeah," my attorney was saying. "They nailed this guy for child molesting,
but he swears he didn't do it. 'Why should I fuck with chi Wren?' he says;
'They're too small!"' He shrugged. "Christ, what could I say? Even a
goddamn were wolf is entitled to legal counsel . . . I didn't dare turn
the creep down. He might have picked up a letter opener and gone after
my pineal gland."
"Why not?" I said. "He could probably get Melvin Belli for that." I
nodded, barely able to talk now. My body felt like I'd just been wired
into a 220 volt socket. "Shit, we should get us some of that stuff." I
muttered finally. "Just eat a big handful and see what happens."
"Some of what?"
"Extract of pineal."
He stared at me. "Sure," he said. "That's a good idea. One whiff of
that shit would turn you into something out of a god damn medical
encyclopedia! Man, your head would swell up like a watermelon, you'd
probably gain about a hundred pounds in two hours . . . claws, bleeding
warts, then you'd notice about six huge hairy tits swefling up on your
back .. ." He shook his head emphatically. "Man, I'll try just about
anything; but I'd never in hell touch a pineal gland. 
"Last Christmas somebody gave me a whole Jimson weed - the root must
have wqighed two pound; enough for a year - but I ate the whole goddamn
thiung in about twenty minutes."
The slightest hesitation made me want to grab him by the throat and
force him to talk faster. "Right!" I said eagerly. "Jimson weed! What
happened?"
"Luckily, I vomited most of it right back up," he said. "But even so,
I went blind for three days. Christ I couldn't even walk! My whole
body turned to wax. I was such a mess that they had to haul me back to
the ranch house in a wheelbarrow . . . they said I was trying to talk,
but I sounded like a raccoon."
"Fantastic," I said. But I could barely hear him. I was so wired that
my hands were clawing uncontrollably at the bed spread, jerking it right
out from under me while he talked. My heels were dug into the mattress,
with both knees locked . . . I could feel my eyeballs swelling, about
to pop out of the sockets.
"Finish the fucking story!" I snarled. "What happened? What about the
glands?"
He backed away, keeping an eye on me as he edged across the room. "Maybe
you need another drink," he said nervously. "Jesus, that stuff got right
on top of you, didn't it?"
I tried to smile. "Well . . . nothing worse .. . no, this is worse
.. ." It was hard to move my jaws; my tongue felt like burning
magnesium. "No . . . nothing to worry about," I hissed. "Maybe if you
could just . . . shove me into the pool, or something..
"Goddamnit," he said. "You took too much. You're about to ~plode. Jesus,
look at your face!'
I couldn't move. Total paralysis now. Every muscle in my was contracted. I
couldn't even move my eyeballs, much turn my head or talk.
"It won't last long," he said. "The first rush is the worst. ride the
bastard out. If I put you in the pool right now, sink like a goddamn
stone."
I was sure of it. Not even my lungs seemed to be functioning. I needed
artificial respiration, but I couldn't open my mouth to say so. I was
going to die. Just sitting there on the bed, unable to move . . . well
at least there's no pain.
Probably, I'll black out in a few seconds, and after that it won't
matter.
My attorney had gone back to watching television. The news was on
again. Nixon's face filled the screen, but his speech was hopelessly
garbled. The only word I could make out was "sacrifice." Over and over
again: "Sacrifice . . . sacrifice . . . sacrificeI could hear myself
breathing heavily. My attorney seemed to notice. "Just stay relaxed," he
said over his shoulder, with out looking at me. "Don't try to fight it, or
you'll start getting brain bubbles . . . strokes, aneurisms . . . you'll
just wither up and die." His hand snaked out to change channels.
 
 
It was after midnight when I finally was able to talk and move around
. . . but I was still not free of the drug; the voltage had merely
been cranked down from 220 to 110. I was a babbling nervous wreck,
flapping around the room like a wild animal, pouring sweat and unable
to concentrate on any one thought for more than two or three seconds at
a time.
My attorney put down the phone after making several calls. "There's only
one place where we can get fresh salmon," he said, "and it's closed on
Sunday."
"Of course," I snapped. "These goddamn Jesus freaks! They're multiplying
like rats!"
He eyed me curiously.
"What about the Process?" I said. "Don't they have a place here? Maybe
a delicatessen or something? With a few tables in back? They have a
fantastic menu in London. I ate there once; incredible food "
"Get a grip on yourself," he said. "You don't want to even mention the
Process in this town."
"You're right," I said. "Call Inspector Bloor. He knows about food. I
think he has a list."
"Better to call room service," he said. "We can get the crab looey and
a quart of Christian Brothers muscatel for about twenty bucks.
"No!" I said. "We must get out of this place. I need air. Let's drive up
to Reno and get a big tuna fish salad . . . hell, it won't take long. Only
about four hundred miles; no traffic out there on the desert . . . "
"Forget it," he said. "That's Army territory. Bomb tests, nerve gas -
we'd never make it."
We wound up at a place called The Big Flip about halfway downtown. I had a
"New York steak" for $1.88. My attorney ordered the "Coyote Bush Basket"
for $2.09 . . . and after that we drank off a pot of watery "Golden West"
coffee and watched four boozed-up cowboy types kick a faggot half to
death between the pinball machines.
"The action never stops in this town," said my attorney as we shuffled
out to the car. "A man with the right contacts could probably pick up all
the fresh adrenochrome he wanted, if he hung around here for a while."
I agreed, but I wasn't quite up to it, right then. I hadn't slept for
something like eighty hours, and that fearful ordeal with the drug
had left me completely exhausted . . . tomorrow we would have to get
serious. The drug conference was scheduled to kick off at noon . . . and
we were still not sure how to handle it. So we drove back to the hotel
and watched a British horror film on the late show.
 
6. Getting Down to Business . . . Opening Day at the Drug Convention
 
"On behalf of the prosecuting attorneys of this county, I welcome you."
We sat in the rear fringe of a crowd of about 1500 in the main ballroom
of the Dunes Hotel. Far up in front of the room, barely visible from
the rear, the executive director of the National District Attorneys'
Association - a middle-aged, well-groomed, successful GOP businessman
type named Pat rick Healy-was opening their Third National Institute on
Narcotics and Dangerous Drugs. His remarks reached us by way of a big,
low-fidelity speaker mounted on a steel pole in our corner. Perhaps
a dozen others were spotted around the room, all facing the rear and
looming over the crowd . . . so hat no matter where you sat or even
tried to hide, you were ways looking down the muzzle of a big speaker.
This produced an odd effect. People in each section of the Lroom tended
to stare at the nearest voice-box, instead of watching the distant figure
of whoever was actually talking up front, on the podium. This 1935 style
of speaker placement totally depersonalized the room. There was something
is and authoritarian about it.
Whoever set up that system was probably some kind of Sheriff's auxiliary
technician on leave from a drive-in theater in Muskogee, where the
management couldn't afford individual car speakers and relied on ten
huge horns, mounted ontelephone poles in the parking area. 
A year earlier I had been to the Sky River Rock Festival in rural
Washington, where a dozen stone-broke freaks from the Seattle Liberation
Front had assembled a sound sys tem that carried every small note of an
acoustic guitar - even a cough or the sound of a boot dropping on the
stage - to half - deaf acid victims huddled under bushes a half mile
away.
But the best technicians available to the National DAs' convention in
Vegas apparently couldn't handle it. Their sound system looked like
something Ulysses S. Grant might have triggered up to address his troops
during the Seige of Vicksburg. The voices from up front crackled with a
fuzzy, high-pitched urgency, and the delay was just enough to keep the
words disconcertingly out of phase with the speaker's ges tures.
"We must come to terms with the Drug Culture in this
country! . . . country . . . country . . ." These echoes drifted back
to the rear in confused waves. "The reefer butt is called a 'roach'
because it resembles a cockroach . . .cockroach . . . cockroach ..
"What the fuck are these people talking about?" my attorney
whispered. "You'd have to be crazy on acid to think a joint looked like
a goddamn cockroach!"
I shrugged. It was clear that we'd stumbled into a prehis toric
gathering. The voice of a "drug expert" named Bloomquist crackled out
of the nearby speakers: ". .. about these flashbacks, the patient never
knows; he thinks it's all over and he gets himself straightened out for
six months . . . and then, darn it, the whole trip comes back on him."
Gosh darn that fiendish LSD! Dr. E. R. Bloomquist, MD, was the keynote
speaker, one of the big stars of the conference. He is the author of
a paperback book titled Marijuana, which - according to the cover -
"tells it like it is." (He is also the inventor of the roach/cockroach
thoery . . . )
According to the book jacket, he is an "Associate Clinical Professor of
Surgery (Anesthesiology) at the University of Southern Cllfcruia School of
Medicine" . . . and also "a well known authority on the abuseof dangerous
drugs.: Dr. Bllomquist "has also appeared on national network television
panles, has served as a consultant for government agencies, was a member
of the Committee on Narcotics Addiction and Alcoholism of the Council
on Mental Health of the American Medical Association." His wisdom is
massively reprinted and distributed, says the publisher. He is clearly
one of the heavies on that circuit of second-rate academic hustlers who
get paid anywhere from $500 to $1000 a hit for lecturing to cop crowds. 
Dr. Bloomquist's book is a compendium of state bullshit. On page
49 he explains, the "four states of being" in the cannabis society:
"Cool, Groovy, Hip & Square" - in that descending order. "The square is
seldom if ever cool," says Bloomquist. "He is 'not with it,' that is,
he doesn't know 'what's happening.' But if he manages to figure it out,
he moves up a notch to 'hip.' And if he can bring himself to approve of
what's happening, he becomes 'groovy.' And after that, with much luck
and perseverence, he can rise to the rank of 'cool."'
Bloomquist writes like somebody who once bearded Tim Leary in a campus
cocktail lounge and paid for all the drinks. And it was probably somebody
like Leary who told him, with a straight face, that sunglasses are known
in the drug culture as "tea shades."
This is the kind of dangerous gibberish that used to be posted, in the
form of mimeographed bulletins, in Police Department locker rooms.
 
Indeed: KNOW YOUR DOPE FIEND. YOUR LIFE MAY DEPEND ON IT! You will not
be able to see his eyes because of Tea-Shades, but his knuckles will be
white from inner tension and his pants will be crustedwith semen from
constantly jacking off when he can't find a rape victim. He will staggerr
and babble when questioned. He will not respect your badge. The Dope Fiend
fears nothing. He will attack, for no reason, with every weapon at his
command - includtng yours. BEWARE. Any officer apprehending a suspected
marijuana addict should use all necessary force immedately. One stitch
in time (on him) wil usually save nine on you. Good luck. 
The Chief.
Indeed. Luck is always important, especially in Las Vegas . . . and ours
was getting worse. It was clear at a glance that this Drug Conference was
not what we'd planned on. It was far too open, too mixed. About a third of
the crowd looked like they'd just stopped by, for the show, en route to a
Frazier-Ali rematch at the Vegas Convention Center across town. Or maybe
a benefit bout, for Old Smack Dealers, between Liston and Marshal Ky.
The room fairly bristled with beards, mustaches and super- Mod dress. The
DAs' conference had obviously drawn a goodly contingent of undercover
narcs and other twilight types. An assistant DA from Chicago wore a
light-tan sleeve less knit suit: His lady was the star of the Dunes
casino; she flashed through the place like Grace Slick at a Finch College
class reunion. They were a classic couple; stone swingers.
Just because you're a cop, these days, doesn't mean you can't be With
It. And this conference attracted some real peacocks. But my own costume
- $40 FBI wingtips and a Pat Boone madras sportcoat - was just about
right for the mass median; because for every urban-hipster, there were
about twenty crude-looking rednecks who could have passed for assistant
football coaches at Mississippi State.
These were the people who made my attorney nervous. Like most
Californians, he was shocked to actually see these people from The
Outback. Here was the cop-cream from Middle America . . . and, Jesus,
they looked and talked like a gang of drunken pig farmers!
 
I tried to console him. "They're actually nice people," I said, "once
you get to know them."
He smiled: "Know them? Are you kidding? Man, I know these people in my
goddamn blood!"
"Don't mention that word around here," I said. "You'll get them excited."
He nodded. "You're right. I saw these bastards in Easy Rider, but I
didn't believe they were real. Not like this. Not hundreds of them!"
My attorney was wearing a duoble-breasted blue pinstripe suit, a far more
stylish outfit than my own.., but it made him exceedingly nervous. Because
to be stylishly dressed in this crowd meant that you were probably an
undercover cop, and my attorney makes his living with people who are very
sensitive in that area. "This is a fucking nightmare!" he kept muttering.
"Here I am infiltrating a goddamn Pig confer ence, but sure as hell
there's some dope-dealing bomb freak in this town who's going to recognize
me and put the word out that I'm out here partying with a thousand cops!'
We all wore name tags. They came with the $100 "registra tion fee." Mine
said I was a "private investigator" from L.A. - which was true, in
a sense; and my attorney's name-tag identified him as an expert in
"Criminal Drug Analysis." Which was also true, in a sense.
But nobody seemed to care who was what, or why. Security was too loose
for that kind of gritty paranoia. But we were also a bit tense because
we'd given the registrar a bad check for our dual registration fee. It
was a check from one of my attorney's pimp/drug underworld clients that
he assumed, from long experience, was absolutely worthless.
 
7. If You Don't Know, Come To Learn . . . If You Know, Come To Teach
 
The first session - the opening remarks - lasted most of the afternoon. We
sat patiently through the first two hours, al though it was clear from
the start that we weren't going to Learn anything and it was equally
clear that we'd be crazy to try any Teaching. It was easy enough to sit
there with a head full of mescaline and listen to hour after hour of
irrelevant gibberish. . . There was certainly no risk involved. These
poor bastards didn't know mescaline from macaroni.
I suspect we could have done the whole thing on acid. . . for some of the
people; there were faces and bodies in that group who would have been
absolutely unendurable on acid. The sight of a 344-pound police chief
from Waco, Texas, necking openly with his 290-pound wife (or whatever
woman he had with him) when the lights were turned off for a Dope Film
was just barely tolerable on mescaline-which is mainly sensual/surface
drug that exaggerates reality, instead of altering it - but with head
full of acid, the sight of two fantastically obese human beings far
gone in a public grope while a thousand cops all around them watched
a movie about of the "dangers of marijuana" would not be emotionally
acceptable. The brain would reject it:
The medulla would attempt to close itself off from the signals it was
getting from the frontal lobes. . . and the middle-brain, meanwhile, would
be trying desperately to put a different interpretation on the scene,
before passing it back to the medulla and the risk of physical action.
Acid is a relatively complex drug, in its effects, while mesca line
is pretty simple and straightforward - but in a scene like this, the
difference was academic. There was simply no call, at this conference,
for anything but a massive consumption of Downers: Reds, Grass and Booze,
because the whole program had apparently been set up by people who had
been in a Seconal stupor since 1964.
Here were more than a thousand top-level cops telling each other "we
must come to terms with the drug culture," but they had no idea where
to start. They couldn't even find the goddamn thing. There were rumors
in the hallways that maybe the Mafia was behind it. Or perhaps the
Beatles. At one point somebody in the audience asked Bboomquist if he
thought Margaret Mead's "strange behavior," of late, might possibly be
explained by a private marijuana addiction.
"I really don't know," Bboomquist replied. "But at her age, if she did
smoke grass, she'd have one hell of a trip."
The audience roared with laughter at this remark.
 
My attorney leaned over to whisper that he was leaving. "I'll be down
in the casino," he said. "I know a hell of a lot better ways to waste my
time than listening to this bullshit." He stood up, knocking his ashtray
off the arm of his chair, and plunged down the aisle toward the door.
The seats were not arranged for random movement. People tried to make
a path for him, but there was no room to move.
"Watch yourself!" somebody shouted as he bulled over them.
"Fuck you!" he snarled.
"Down in front!" somebody else yelled.
By now he was almost to the door. "I have to get out!" he shouted.. "I
don't belong here!"
"Good riddance," said a voice.
He paused, looking around - then he seemed to think better of it,
and kept moving. By the time he got to the exit the whole rear of the
room was in turmoil. Even Bloomquist, far up front on the stage, seemed
aware of a distant trouble. He stopped talking and peered nervously in
the direction of the noise. Probably he thought a brawl had erupted -
maybe a racial conflict of some kind, something that couldn't be helped.
I stood up and plunged toward the door. It seemed like as good a time as
any to flee. "Pardon me, I feel sick," I said to the first leg I stepped
on. It jerked back, and I said it again:
"Sorry, I'm about to be sick . . . sorry, sick.., beg pardon, yes,
feeling sick . . . 
This time a path opened very nicely. Not a word of protest. Hands actually
helped me along. They feared I was about to vomit, and nobody wanted it -
at least not on them. I made it to the door in about forty-five seconds.
 
My attorney was downstairs at the bar, talking to a sporty - looking cop
about forty whose plastic name - tag said he was the DA from someplace
in Georgia. "I'm a whiskey man, myself," he was saying. "We don't have
much problem with drugs down where I come from."
"You will," said my attorney. "One of these nights you'll wake up and
find a junkie tearing your bedroom apart."
"Naw!" said the Georgia man. "Not down in my parts." I joined them and
ordered a tall glass of rum, with ice.
"You're another one of these California boys," he said. Your friend
here's been tellin' me about dope fiends."
"They're everywhere," I said. "Nobody's safe. And sure as not in the
South. They like the warm weather."
They work in pairs," said my attorney. "Sometimes in gangs. They'll
climb right into your bedroom and sit on your chest, with big Bowie
knives." He nodded solemniy. '"They might even sit your wife's chest -
put the blade right down on her throat."
"Jesus god almighty," "said the southerner. "What the hell's goin'
on in this country?"
"You'd never believe it," said my attorney. "In L.A. it's out of
control. First it was drugs, now it's witchcraft."
"Witchcraft? Shit, you can't mean it!"
"Read the newspapers," I said. "Man, you don't know trouble until you have
to face down a bunch of these addicts gone crazy for human sacrifice!"
"Naw!" he said. "That's science fiction stuff!"
"Not where we operate," said my attorney. "Hell, in Malibu alone, these
goddamn Satan-worshippers kill six or eight people every day." He paused
to sip his drink. "And all they want is the blood," he continued. "They'll
take people right off the street if they have to." He nodded. "Hell,
yes. Just the other day we had a case where they grabbed a girl right
out of a McDonald's hamburger stand. She was a waitress. About six teen
years old . . . with a lot of people watching, too!"
"What happened?" said our friend. "What did they do to her?" He seemed
very agitated by what he was hearing.
"Do?" said my attorney. "Jesus Christ man. They chopped her goddamn head
off right there in the parking lot! Then they cut all kinds of holes in
her and sucked out the blood!"
"God almighty!" The Georgia man exclaimed . . . "And nobody did
anything?"
"What could they do?" I said. "The guy that took the head was about
six-seven and maybe three hundred pounds. He was packing two Lugers,
and the others had M-16s. They were all veterans. "
"The big guy used to be a major in the Marines," said my attorney. "We
know where he lives, but we can't get near the house."
"Naw!" our friend shouted. "Not a major!"
"He wanted the pineal gland," I said. "That's how he got so big. When
he quit the Marines he was just a little guy."
"0 my god!" said our friend. "That's horrible!"
"It happens every day," said my attorney. "Usually it's whole
families. During the night. Most of them don't even wake up until they
feel their heads going - and then, of course, it's too late." 
The bartender had stopped to listen. I'd been watching him. His expression
was
not calm.
"Three more rums," I said. "With plenty of ice, and maybe a handful of
lime chunks."
He nodded, but I could see that his mind was not on his work. He was
staring at our name-tags. "Are you guys with that police convention
upstairs?" he said finally.
"We sure are, my friend," said the Georgia man with a big smile.
The bartender shook his head sadly. "I thought so," he said. "I never
heard that kind of talk at this bar before. Jesus Christ! How do you
guys stand that kind of work?"
My attorney smiled at him. "We like it," he said. "It's groovy."
The bartender drew back; his face was a mask of repug nance.
"What's wrong with you?" I said. "Hell, somebody has to do it."
He stared at me for a moment, then turned away.
"Hurry up with those drinks," said my attorney. "We're thirsty." He
laughed and rolled his eyes as the bartender glanced back at him. "Only
two rums," he said. "Make mine a Bloody Mary."
The bartender seemed to stiffen, but our Georgia friend didn't notice. His
mind was somewhere else. "Hell, I really hate to hear this," he said
quietly. "Because everything that happens in California seems to get down
our way, sooner or later. Mostly Atlanta, but I guess that was back when
the goddamn bastards were peaceful. It used to be that all we had to do
was keep 'em under surveillance. They didn't roam around much . . . ." He
shrugged. "But now, Jesus, nobody's safe. They could turn up anywhere."
"You're right," said my attorney. "We learned that in California. You
remember where Manson turned up, don't you? Right out in the middle of
Death Valley. He had a whole army of sex fiends out there. We only got
our hands on a few.
Most of the crew got away; just ran off across the sand dimes, like big
lizards . . . and every one of them stark naked, except for the weapons."
'They'll turn up everwhere, pretty soon." OI said. "And let's hope we'll
be ready for them."
The Georgia man whacked his fist on the bar. "But we can't just lock
ourselves in the house and be prisoners!" he ex aimed. "We don't even
know who these people are! How do you recognize them?
"You can't," my attorney replied. "The only way to do it is to take the
bull by the horns - go to the mat with this scum!"
"What do you mean by that?" he asked.
"You know what I mean," said my attorney. "We've done it before, and we
can damn well do it again."
"Cut their goddamn heads off," I said. "Every one of them. That's what
we're doing in California."
"What?"
"Sure," said my attorney. "It's all on the Q.T., but everybody who
matters is with us all the way down the line."
"God! I had no idea it was that bad out there!" said our friend.
"We keep it quiet," I said. "It's not the kind of thing you'd to talk
about upstairs, for instance. Not with the press around."
Our man agreed. "Hell no!" he said. "We'd never hear the ~goddamn end
of it."
"Dobermans don't talk," I said.
"What?"
"Sometimes it's easier to just rip out the backstraps," said attorney.
"They'll fight like hell if you try to take the I without dogs."
"God almighty!"
We left him at the bar, swirling the ice in his drink and not smiling. He
was worried about whether or not to tell his wife It it. "She'd never
understand," he muttered. "You know women are."
I nodded. My attorney was already gone, scurrying through of slot machines
toward the front door. I said goodbye end, warning him not to say anything
about what him. 
 
8. Back Door Beauty . . . & Finally a Bit of Serious Drag Racing on the
Strip
Sometime around midnight my attorney wanted coffee. He bad been vomiting
fairly regularly as we drove around the Strip, and the right flank of
the Whale was badly streaked. We were idling at a stoplight in front of
the Silver Slipper beside a big blue Ford with Oklahoma plates . . . two
hoggish- looking couples in the car, probably cops from Muskogee using
the Drug Conference to give their wives a look at Vegas. They looked like
they'd just beaten Caesar's Palace for about $38 at the blackjack tables,
and now they were headed for the Circus-Circus to whoop it up . . . .
but suddenly, they found themselves next to a white Cadillac convertible
all covered with vomit and a 300-pound Samoan in a yellow fishnet T-shirt
yelling at them: "Hey there! You folks want to buy some heroin?"
No reply. No sign of recognition. They'd been warned about this kind of
crap: Just ignore it . . . 
'Hey, honkies!" my attorney screamed. "Goddamnit, I'm serious! I want to
sell you some pure fuckin' smack!" He was hanging out of the car, very
close to them. But still nobody an swered. I glanced over, very briefly,
and saw four middle Americanan faces frozen with shock, staring straight
ahead.
We were in the middle lane. A quick left turn would be ille would have to
go straight ahead when the light en escape at the next corner. I waited,
tapping the accelerator nervously . . . 
My attorney was losing control: "Cheap heroin!" he was shouting. "This
is the real stuff You won't get hooked! God damnit, I know what I have
here!" He whacked on the side of the car, as if to get their attention..,
but they wanted no part of us.
"You folks never talked to a vet before?" said my attorney. "I just got
back from Veet Naam. This is scag, folks! Pure scag!"
Suddenly the light changed and the Ford bolted off like a rocket. I
stomped on the accelerator and stayed right next to them for about two
hundred yards, watching for cops in the mirror while my attorney kept
screaming at them:
"Shoot! Fuck! Scag! Blood! Heroin! Rape! Cheap! Communist! Jab it right
into your fucking eyeballs!"
We were approaching the Circus-Circus at high speed and the Oklahoma
car was veering left, trying to muscle into the turn lane. I stomped
the Whale into passing gear and we ran fender to fender for a moment. He
wasn't up to hitting me; there was horror in his eyes.
The man in the back seat lost control of himself . . . lunging across
his wife and snarling wildly: "You dirty bastards! Pull over and I'll
kill you! God damn you! You bas tards!" He seemed ready to leap out
the window and into our car, crazy with rage. Luckily the Ford was a
two-door. He couldn't get out.
We were coming up to the next stoplight and the Ford was still trying to
move left. We were both running full bore. I glanced over my shoulder
and saw that we'd left the other traffic far behind; there was a big
opening to the right. So I mashed on the brake, hurling my attorney
against the dash board, and in the instant the Ford surged ahead I cut
across his tail and zoomed into a side-street. A sharp right turn across
three lanes of traffic. But it worked. We left the Ford stalled in the
middle of the intersection, hung in the middle of a screeching left
turn. With a little luck, he'd be arrested for reckless driving.
My attorney was laughing as we careened in low gear, with the light
sout, through a dusty tangle of backstreets behind the Desert Inn. "Jesus
Christ," he said. "Those Okies were getting excited. That guy in the back
seat was trying to bite me! Shit, he was frothing at the mouth." He nodded
solemnly. "I should have maced the fucker . . . a criminal psychotic,
total breakdown . . . you never know when they're likely to explode."
I swung the Whale into a turn that seemed to lead out of the maze -
but instead of skidding, the bastard almost rolled.
"Holy shit!" my attorney screamed. "Turn on the fucking lights!" He was
clinging to the top of the windshield . . . and suddenly he was doing
the Big Spit again, leaning over the side.
I refused to slow down until I was sure nobody was following us -
especially that Oklahoma Ford: those people were definitely dangerous,
at least until they calmed down. Would they report that terrible quick
encounter to the police? Probably not. It had happened too fast, with
no witnesses, and the I were pretty good that nobody would believe them
anyway. The idea that two heroin pushers in a white Cadillac convertible
would be dragging up and down the Strip, abusing total strangers at
stoplights, was prima facie absurd. Not even Sonny Liston ever got that
far out of control.
We made another turn and almost rolled again. The Coupe de Ville
is not your ideal machine for high speed cornering in residential
neighborhoods. The handling is very mushy . . . 
unlike the Red Shark, which had responded very nicely to situations
requiring the quick four-wheel drift. But the Whale Bad of cutting loose
at the critical moment - had a tendency to dig in, which accounted for
that sickening "here we go' sensation.
At first I thought it was only because the tires were soft, so I took
it into the Texaco station next to the Flamingo and had the tires pumped
up to fifty pounds each - which alarmed the attendant, until I explained
that these were "experimental" tires.
But fifty pounds each didn't help the cornering, so I swent back a few
hours later and told him I wanted to try seventy five. He shook his head
nervously. "Not me," he said, handing me the air hgose. "Here. They're
your tires. You do it."
"What's wrong?" I asked. "You think they can't take seventy-five?"
He nodded, moving away as I stooped to deal with the left front. "You're
damn right," he said. "Those tires want twenty eight in the front and
thirty two in the rear. Hell, fifty's dangerous, but seventy five is
crazy. They'll explode!"
I shook my head and kept filling the left front. "I told you," I said,
"Sandoz laboratories designed these tires. They're special. I could load
them up to a hundred.
"God almighty!" he groaned. "Don't do that here."
"Not today," I replied. "I want to see how they corner with
seventy-five."
He chuckled. "You won't even get to the corner, Mister."
"We'll see," I said, moving around to the rear with the air- hose. In
truth, I was nervous. The two front ones were tighter than snare drums;
they felt like teak wood when I tapped on them with the rod. But what
the hell? I thought. If they ex plode, so what? It's not often that
a man gets a chance to run terminal experiments on a virgin Cadillac
and four brand- new $80 tires. For all I knew, the thing might start
cornering like a Lotus Elan. If not, all I had to do was call the VIP
agency and have another one delivered . . . maybe threaten them with
a lawsuit because all four tires had exploded on me, while driving in
heavy traffic. Demand an Eldorado, next time, with four Michelin Xs. And
put it all on the card . . . charge it to the St Louis Browns.
As it turned out, the Whale behaved very nicely with the altered tire
pressures. The ride was a trifle rough; I could feel every pebble on
the highway, like being on roller skates in a gravel pit.., but the
thing began cornering in a very stylish manner, very much like driving a
motorcycle at top speed in a hard rain: one slip and ZANG, over the high
side, cartwheel ing across the landscape with your head in your hands. 
 

 
About thirty minutes after our brush with the Okies we pulled into an
all-night diner on the Tonopah highway, on the kirts of a mean/scag
ghetto called "North Las Vegas." Which is actually outside the city
limits of Vegas proper. North Vegas is where you go when you've fucked
up once too often on the Strip, and when you're not even welcome in the
cut-rate downtown places around Casino Center.
This is Nevada's answer to East St. Louis - a slum and a graveyard,
last stop before permanent exile to Ely or Winnemuca. North Vegas is
where you go if you're a hooker turning thirty and the syndicate men
on the Strip decide you're no longer much good for business out there
with the high rollers .. . or if you're a pimp with bad credit at the
Sands . . . or what they still call, in Vegas, "a hophead." This can
mean almost anything from a mean drunk to a junkie, but in terms of
commercial acceptability, it means you're finished all the right places.
The big hotels and casinos pay a lot of muscle to make sure high rollers
don't have even momentary hassles with "undesirables." Security in a place
like Caesar's Palace is super tense and strict. Probably a third of the
people on the floor at given time are either shills or watchdogs. Public
drunks known pickpockets are dealt with instantly - hustled out parking
lot by Secret Service type thugs and given a impersonal lecture about the
cost of dental work and of trying to make a living with two broken erms.
The "high side" of Vegas is probably the most closed society west of
Sicily - and it makes no difference, in terms of the lay life-style
of the place, whether the Man at the Top is Lucky Luciano or Howard
Hughes. In an economy where Tom Jones can make $75,000 a week for two
shows a night at Caeser's, the palace guard is indispensable, and they
don't care who signs their paychecks. A gold mine like Vegas breeds it's
own army, like any other gold mine. Hired muscle tends to accumulate
in fast layers around money/power poles . . . and big money, in Vegas,
is synonymous with the Power to protect it.
So once you get blacklisted on the Strip, for any reason at all, you
either get out of town or retire to nurse your act along, on the cheap,
in the shoddy limbo of North Vegas . . . out there with the gunsels,
the hustlers, the drug cripples and all the other losers. North Vegas,
for instance, is where you go if you need to score smack before midnight
with no refer ences.
But if you're looking for cocaine, and you're ready up front with some
bills and the proper code words, you want to stay on the Strip and get
next to a well-connected hooker, which will take at least one bill for
starters.
And so much for all that. We didn't fit the mold. There is no formula
for finding yourself in Vegas with a white Cadillac full of drugs and
nothing to mix with properly. The Fillmore style never quite caught on
here. People like Sinatra and Dean Martin are still considered "far out"
in Vegas. The "underground newspaper" here - the Las Vegas Free Press -
is a cautious echo of The People's World, or maybe the National Guardian.
A week in Vegas is like stumbling into a Time Warp, a regression to the
late fifties. Which is wholly understandable when you see the people who
come here, the Big Spenders from places like Denver and Dallas. Along
with National Elks Club conventions (no niggers allowed) and the All-West
Volunteer Sheepherders' Rally. These are people who go abso lutely crazy
at the sight of an old hooker stripping down to her pasties and prancing
out on the runway to the big-beat sound of a dozen 50-year-old junkies
kicking out the jams on "September Song."
 
It was some time around three when we pulled into the parking lot of the
North Vegas diner. I was looking for a copy of the Los Angeles Times, for
news of the outside world, but a quick glance at the newspaper racks amde
a bad joke of that notion. They don't need the Times in North Vegas. No
news is good news.
"Fuck newspapers," said my attorney. "What we need now is coffee."
I agreed, but I stole a copy of the Vegas Sun anyway. It yesterday's
edition, but I didn't care. The idea of entering a coffee shop without
a newspaper in my hands made me nervous. There was always the Sports
Section; get wired on baseball scores and pro-football rumors: "Bart Starr
Beaten by Thugs in Chicago Tavern; Packers Seek Trade" . . . "Namath
Quits Jets to be Governor of Alabama" . . . and a speculative piece
on page 46 about a rookie sensation Harrison Fire, out of Grambling:
runs the hundred in nine flat, 344 pounds and still growing.
"This man Fire has definite promise," says the coach. "Yesterday, before
practice, he destroyed a Greyhound Bus with bare hands, and last night
he killed a subway. He's a natural for color TV. I'm not one to play
favorites, but it looks like i'll have to make room for him."
Indeed. There is always room on TV for a man who can beat people to
jelly in nine flat . . . But not many of these gathered, on this night,
in the North Star Coffee Lounge. We had the place to ourselves - which
proved to be fortunate, because we'd eaten two more pellets of mescaline
on way over, and the effects were beginning to manifest.
My attorney was no longer vomiting, or even acting sick. He ordered
coffee with the authority of a man long accustmed to quick service. The
waitress had the appearance of a hooker who had finally found her place
in life. She was definitely in charge here, and she eyed us with obvious
disapproval as we settled onto our stools.
I was'nt paying much attention. The North Star Coffee Lounge seemed
like a fairly safe haven from our storms. There are some you go into -
in this line of work - that you know will be heavy. The details don't
matter. All you know, for sure, is that your brain starts humming with
brutal vibes as you approach the front door. Something wild and evil is
about to happen; and it's going to involve you.
But there was nothing in the atmosphere of the North Star to put me on
my guard. The waitress was passively hostile, but I was accustomed to
that. She was a big woman. Not fat, but large in every way, long sinewy
arms and a brawler's jawbone. A burned-out caricature of Jane Russell:
big head of dark hair, face slashed with lipstick and a 48 Double-E
chest that was probably spectacular about twenty years ago when she might
have been a Mama for the Hell's Angels chapter in Berdoo . . . but now
she was strapped up in a giant pink elastic brassiere that showed like
a bandage through the sweaty white rayon of her uniform.
Probably she was married to somebody, but I didn't feel like
speculating. All I wanted from her, tonight, was a cup of black coffee
and a 29 cent hamburger with pickles and onions. No hassles, no talk -
just a place to rest and re - group. I wasn't even hungry.
My attorney had no newspaper or anything else to compel his attention. So
he focused, out of boredom, on the waitress. She was taking our orders
like a robot when he punched through her crust with a demand for "two
glasses of ice water - with ice."
My attorney drank his in one long gulp, then asked for an other. I
noticed that the waitress seemed tense.
Fuck it, I thought. I was reading the funnies.
About ten minutes later, when she brought the hamburg ers, I saw my
attorney hand her a napkin with something printed on it. He did it very
casually, with no expression at all on his face. But I knew, from the
vibes, that our peace was about to be shattered.
"What was that?" I asked him.
He shrugged, smiling vaguely at the waitress who was standing about
ten feet away, at the end of the counter, keeping her back to us while
she pondered the napkin. Finally she turned and stared . . . then she
stepped resolutely forward and tossed the napkin at my attorney.
"What is this?" she snapped.
"A napkin," said my attorney.
There was a moment of nasty silence, then she began screaming: "Don't
give me that bullshit! I know what it is! You goddamn fat pimp bastard!"
My attorney picked up the napkin, looked at what he'd written, then
dropped it back on the counter. "That's the name of a horse I used to
own," he said calmly. "What's wrong with you?"
"You sonofabitch!" she screamed. "I take a lot of shit in place, but I
sure as hell don't have to take it off a spic pimp!"
Jesus! I thought. What's happening? I was watching the woman's hands,
hoping she wouldn't pick up anything sharp and heavy. I picked up the
napkin and read what the bastard printed on it, in careful red letters:
"Back Door Beauty?" The question mark was emphasized.
The woman was screaming again: "Pay your bill and get hell out! You want
me to call the cops?"
I reached for my wallet, but my attorney was already on feet, never
taking his eyes off the woman . . . then he reached under his shirt,
not into his pocket, coming up suddenly with the Gerber Mini-Magnum,
a nasty silver blade the the waitress seemed to understand instantly.
She froze: her eyes fixed wildly on the blade. My attorney, watching
her, moved about six feet down the aisle and the receiver off the hook
of the pay phone. He sliced it off, then brought the receiver back to
his stool and sat down.
The waitress didn't move. I was stupid with shock, not whether to run
or start laughing.
"How much is that lemon meringue pie?" my attorney's voice was casual,
as if he had
just wandered into and was debating what to order.
"Thirty five cents!" the woman blurted. Her eyes were turgid with fear but
her brain was apparently functioning on some basic motor survival leveL
My attorney laughed. "I mean the whole pie," he said.
She moaned.
My attorney put a bill on the counter. "Let's say it's five dollars,"
he said. "OK?"
She nodded, still frozen, watching my attorney as he walked around the
counter and got the pie out of the display case. I prepared to leave.
The waitress was clearly in shock. The sight of the blade, jerked out
in the heat of an argument, had apparently triggered bad memories. The
glazed look in her eyes said her throat had been cut. She was still in
the grip of paralysis when we left.
 
9. Breakdown on Paradice Blvd.
 
EDITOR'S NOTE:
At this point in the chronology, Dr. Duke appears to have broken down
completely; the original manuscript is so splintered that we were forced
to seek out the original tape record ing and transcribe it verbatim. We
made no attempt to edit this section, and Dr. Duke refused even to read
it. There was only one way to reach him. The only address/contact we had,
during this period, was a mobile phone unit somewhere on Highway 61 - and
all efforts to reach Duke at that number proved futile. In the interests
of journalistic purity, we are publishing the following section just as
it came off the tape - one of many that Duke submitted for purposes of
verification - along with manuscript. According to the tape, this section
follows an episode involving Duke, his attorney and a waitress at an all -
diner in North Vegas. The rationale for the following section appears to
be based on a feeling - shared by both Duke and his attorney - that the
American Dream would to be sought out somewhere far beyond the dreary
confines District Attorneys' Confrrence on Narcotics and Dangerous Drugs.
The transcription begins somewhere on the Northeast out of Las Vegas -
zooming along Paradise Road in the White Whale . . . 
 
Att'y: Boulder City is to the right. Is that a town?
Duke: Yeah
Att'y: Let's go to Boulder City.
Duke: All right. Let's get some coffee somewhere . . . 
Att'y: Right up here, Terry's Taco Stand, USA. I could go for a taco. Five
for a buck.
Duke: Sounds horrible. I'd rather go somewhere where's there's one for
5O cents.
Att'y: No . . . this might be the last chance we get for tacos.
Duke:. . . I need some coffee.
Att'y: I want tacos
Duke: Five for a buck, that's like . . . five hamburgers for a buck.
Att'y: No . . . don't judge a taco by its price.
Duke: You think you might make a deal?
Att'y: I might. There's a hamburger for 29 cents. Tacos are 29 cents. It's
just a cheap place, that's all.
Duke: Go bargain with them..
[Only garbled sounds here.-Ed.]
Att'y:. . . Hello.
Waitress: May I help you?
Att'y: Yeah, you have tacos here? Are they Mexican tacos or just regular
tacos? I mean, do you have chili in them and things like that?
Waitress: We have cheese and lettuce, and we have sauce, you know,
put on them.
Att'y: I mean do you guarantee that they are authentic Mexican tacos?
Waitress: . . . I don't know. Hey Lou, do we have authentic Mexican
tacos?
Woman's voice from kitchen: What?
Waitress: Authentic Mexican tacos.
Lou: We have tacos. I don't know how Mexican they are.
Att'y: Yeah, well, I just want to make sure I get what I'm paying
for. 'Cause they're five for a dollar? I'll take five of them.
Duke: Taco burger, what's that?
(Sound. of diesel engine truck. -Ed.]
Att'y: That's a hamburger. with a taco in the middle.
Duke: A taco on a bun.
Att'y: I betcha your tacos are just hamburgers with a shell sad of a bun.
Waitress: I don't know
Att'y: You just started working here?
Waitress: Today.
Att'y: I thought so, I've never saw you here before. You go school around
here?
Waitress: No, I don't go to school.
Duke: Oh? Why not? Are you sick?
Att'y: Never mind that. We came here for tacos.
[Pause.]
Att'y: As your attorney I advise you to get the chiliburger. a hamburger
with chili on it.
Duke: That's too heavy for me.
Att'y: Then I advise you to get a taco burger, try that one. 
Duke: . . . the taco has meat in it. I'll try that one. And coffee
now. Right now. So I can drink it while I'm waiting.
Waitress: That's all you want, one taco burger? 
Duke: Well, I'll try it, I might want two. 
Att'y: Are your eyes blue or green?
Waitress: Pardon?
Att'y: Blue or green?
Waitress: They change.
Att'y: Like a lizard?
Waitress: Like a cat.
Att'y: Oh, the lizard changes the color of his skin . . . 
Waitress: Want anything to drink?
Att'y: Beer. And I have beer in the car. Tons of it. The back seat's
full of it.
Duke: I don't like mixing coconuts up with beer and ham - let's smash
the bastards.. right in the middle of the highway . . . Is Boulder City
somewhere around
Waitress: Boulder City? Do you want sugar?
Duke: Yeah.
Att'y: We're in Boulder City, huh? Or very close to it?
Duke: I don't know.
Waitress: There it is. That sign says Boulder City, OK. Aren't you from
Nevada?
Att'y: No. We've never been here before. Just traveling through.
Waitress: You just go straight up this road here.
Att'y: Any action up there in Boulder City?
Waitress: Don't ask me. I don't . . . 
Att'y: Any gambling there?
Waitress: I don't know, it's just a little town.
Duke: Where is the casino?
Waitress: I don't know.
Att'y: Wait a minute, where are you from?
Waitress: New York.
Att'y: And you've just been here a day.
Waitress: No, I've been here for a while.
Att'y: Where do you go around here? Say you wanted to go swimming or
something like that?
Waitress: In my backyard.
Att'y: What's the address?
Waitress: Um, go to the . . . ah . . . the pool's not open yet.
Att'y: Let me explain it to you, let me run it down just briefly
if I can. We're looking for the American Dream, and we were told it
was somewhere in this area . . . . Well, we're here looking for it,
'cause they sent us out here all the way from San Francisco to look for
it. That's why they gave us this white Cadillac, they figure that we
could catch up with it in that . . . 
Waitress: Hey Lou, you know where the American Dream is?
Att'y (to Duke): She's asking the cook if he knows where the American
Dream is.
Waitress: Five tacos, one taco burger. Do you know where the American
Dream is?
Att'y: Well, we don't know, we were sent out here from Francisco to look
for the American Dream, by a magazine to cover it.
Lou: Oh, you mean a place.
Att'y: A place called the American Dream.
Lou: Is that the old Psychiatrist's Club?
Waitress: I think so.
Att'y: The old Psychiatrist's Club?
Lou: Old Psychiatrist's Club, it's on Paradise . . Are you serious?
Att'y: Oh, no honest, look at that car, I mean, do I look like own a
car like that?
Lou: Could that be the old Psychiatrist's Club? It was a discoteque
place . . . 
Att'y: Maybe that's it.
Waitress: It's on Paradise and what?
Lou: Ross Allen had the old Psychiatrist's Club. Is he the owner now?
Duke: I don't know.
Att'y: All we were told was, go till you find the American Dream. Take
this white
Cadillac and go find the American Dream. It's somewhere in the Las Vegas
area. 
Lou: That has to be the old . . .
Att'y: . . . and it's a silly story to do, but you know, that's we get
paid for.
Lou: Are you taking pictures of it, or . . . 
Att'y: No, no--no pictures.
Lou: . . . or did somebody just send you on a goose chase?
Att'y: It's sort of a wild goose chase, more or less, but personally
we're dead serious.
Lou: Thas to be the old Psychiatrist's Club, but the only people who hang
out there is a bunch of pushers, peddlers, up wners, and all that stuff.
Att'y: Maybe that's it. Is it a night-time place or is it an all day...
Lou: Oh, honey, this never stops. But it's not a casino.
Att'y: What kind of place is it?
Lou: It's on Paradise, uh, the old Psychiatrist's Club's on Paradise.
Att'y: Is that what it's called, the old Psychiatrist's Club?
Lou: No, that is what it used to be, but someone bought it . . . but
I didn't hear about it as the American Dream, it was something like,
associated with, uh . .. it's a mental joint, where all the dopers hang
out.
Att'y: A mental joint? You mean like a mental hospital? 
Lou: No, honey, where all the dope peddlers and all the pushers, everybody
hangs out. It's a place where all the kids are potted when they go in, and
everything . . . but it's not called what you said, the American Dream.
Att'y: Do you have any idea what it might be called? Or more or less
where it might be located?
Lou: Right off of Paradise and Eastern.
Waitress: But Paradise and Eastern are parallel.
Lou: Yeah, but I know I come off of Eastern, and then I go to Paradise
Waitress: Yeah I know it, but then that would make it off Paradise around
the Flamingo, straight up here. I think somebody's handed you a
Att'y: We're staying at the Flamingo. I think this place you're talking
about and the way you're describing it, I think that maybe that's it.
Lou: It's not a tourist joint.
Att'y: Well, that's why they sent me. He's the writer: I'm the
bodyguard. 'Cause I figure it will be . . . 
Lou: These guys are nuts . . . these kids are nuts.
Att'y: That's OK.
Waitress: Yeah, they got new laws.
Duke: Twenty-four-hour-a-day violence? Is that what we're saying?
Lou: Exactly. Now here's the Flamingo . . . Oh, I can't show you this;
I can tell you better my way. Right up here at the first gas station is
Tropicana, take a right.
Att'y: Tropicana to the right.
Lou: The first gas station is Tropicana. Take a right on Tropicana and
take this way . . . right on Tropicana, right on Paradice, you'll see
a big black building, it's all painted black real weird looking.
Att'y: Right on Tropicana, right on Paradise, black building...
Lou: And there's a sign on the side of the building that says
Psychiatrist's Club, but they're completely remodeling it and everything.
Att'y: All right, that's close enough
Lou: If there's anything I can do for ya, honey. . . I don't know if
that's even it or not. But it sounds like it is. I think you boys are
on the right track.
Att'y: Right. That's the best lead we've had for two days, we've been
asking people all around.
Lou: . . . I could make a couple calls and sure as hell find out.
Att'y: Could you?
Lou: Sure I'll call Allen and ask him.
Att'y: Gee, I'd appreciate that if you could.
Waitress: When you go down to Tropicana, it's not the first gas station,
the second.
Lou: There's a big sign right down the street here, it says Tropicana
Avenue. Make a right, and when you get to Paradice make another right.
Att'y: OK. Big black building, right on Paradise: twenty-four-hour-a-day
violence, drugs
Waitress: See, here's Tropicana, and this is Boulder Highway that goes
clear down like that.
Duke: Well, that's pretty far into town then.
Waitress: Well, here's Paradise split up somewhere around there. There's
Paradice. Paradise. Yeah, we're down in here. See, this is Boulder
Highway . . . and Tropicana.
Lou: Well, that's not it, that bartender in there is a pothead too...
Att'y: Yeah, well, it's a lead.
Lou: You gonna be glad you stopped here, boys.
Duke: Only if we find it.
Att'y: Only if we write the article and get it in.
Waitress: Well, why don't you come inside and sit down?
Duke: We're trying to get as much sun as we can.
Att'y: She's going to make a phone call to find out where it Is.
Duke: Oh. OK, well, let's go inside. 
EDITOR'S NOTE (cont.):
Tape cassettes for the next sequence were impossible to transcribe due to
some viscous liquid encrusted behind the heads. There is a certain
consistency
in the garbled sounds however, indicating that almost two hours later Dr.
Duke and his attorney finally located what was left of the "Old
Psychiatrist's
Club"-a huge slab of cracked, scorched concrete in a vacant lot full of
tall
weeds. The owner of a gas station across the road said the place had
"burned
down about three years ago."
 
10. Heavy Duty at the Airport . . . Ugly Peruvian Flashback . . ."No! It's
Too Late! Don't Try It!"
My attorney left at dawn. We almost missed the first flight to LA. because
I couldn't find the airport. It was less than thirty minutes from the
hotel. I was sure of that. So we left the Flamingo at exactly seven-thirty
. . . but for some reason we failed to make the turnoff at the stoplight
in front of the Tropicana. We kept going straight ahead on the freeway,
that parallels the main airport runway, but on the opposite from the
terminal . . . and there is no way to get across legally.
"Goddamnit! We're lost!" my attorney was shouting. What are we doing
out here on this godforsaken road? The airport is right over there!" He
pointed hysterically across the tundra.
"Don't worry," I said. "I've never missed a plane yet." I smiled as the
memory came back. "Except once in Peru," I added. "I was already checked
out of country, through customs, but I went back to the bar to chat with
this Bolivian cocaine dealer . . . and all of a sudden I heard those
big 707 engines starting up, so I ran out to the runway and tried to get
aboard but the door was right behind the engines and they'd already rolled
the ladder away. Shit, those afterburners would have fried me like bacon
. . . but I was completely out of my head: I was desperate to get aboard.
"The airport cops saw me coming, and they gathered into a knot at the
gate. I was running like a bastard, straight at them. The guy with me
was screaming: 'No! It's too late! Don't try it!'
"I saw the cops waiting for me, so I slowed down like maybe I'd changed
my mind . . . but when I saw them relax, I did a quick change of pace
and tried to run right over the bastards." I laughed. "Jesus, it was like
running full bore into a closet full of gila monsters. The fuckers almost
killed me. All I remember is seeing five or six billyclubs coming down
on me at the same time, and a lot of voices screaming: 'No! No! It's
suicide! Stop the crazy gringo!'
"I woke up about two hours later in a bar in downtown Lima. They'd
stretched me out in one of those half-moon leather booths. My luggage
was all stacked beside me. No body had opened it . . . so I went back
to sleep and caught the first flight out, the next morning."
My attorney was only half listening. "Look," he said, "I'd really like
to hear more about your adventures in Peru, but not now. Right now all
I care about is getting across that god damn runway."
We were flashing along at good speed. I was looking for an opening, some
kind of access road, some lane across the run way to the terminal. We
were five miles past the last stop light and there wasn't enough time
to turn around and go back to it.
There was only one way to make it on time. I hit the brakes and eased
the Whale down into the grassy moat between the two freeway lanes. The
ditch was too deep for a head-on run, so I took it at an angle. The
Whale almost rolled, but I kept the wheels churning and we careened
up the opposite bank and into the oncoming lane. Fortunately, it was
empty. We came out of the moat with the nose of the car up in the air
like a hydroplane.. . then bounced on the freeway and kept on going into
the cactus field on the other side. I recall running over a fence of some
kind said dragging it a few hundred yards, but by the time w e got to the
runway way we were under control . . . screaming along about 60 miles an
in low gear, and it looked like a wide-open run all the to the terminal.
My only worry was the chance of getting crushed like a roach by an
incoming DC-8, which we probably wouldn't see until it was right on top
of us. I wondered if they could see us in the tower. Probably so, but why
worry? I kept the thing floored. There was no point in turning back now.
My attorney was hanging onto the dashboard with both nds. I glanced over
and saw fear in his eyes. His face appeared to be grey, and I sensed
he was not happy with this move, but we were going so fast across the
runway - then cactus, then runway again - that I knew he understood our
situation: We were past the point of debating the wisdom of is move;
it was already done, and our only hope was to get the other side.
I looked at my skeleton-face Accutron and saw that we had three minutes
and fifteen seconds before takeoff. "Plenty of time," I said. "Get your
stuff together. I'll drop you right next the plane." I could see the big
red and silver Western jetliner about 1000 yards ahead of us . . . and
by this time we were skimming across smooth asphalt, past the incoming
runway.
"No!" he shouted. "I can't get out! They'll crucify me. I'll have to
take the blame!"
"Rediculous," I said. "Just say you were hitchhiking to the airport
and I picked you up. You never saw me before. Shit, thos town is full
of white Cadillac convertibles . . . and I plan to go through there so
fast that nobody will even glimpse the goddamn license plate."
We were approaching the plane. I could see passengers but so far nobody
had noticed us . . . approaching from this unlikely direction. "Are you
ready?" I said.
"Why not? But for Christ's sake, let's do it fast! He was scanning the
loading area, then he pointed: "Over there!" he said. "Drop me behind
that big van. Just pull in behiond it ad I'll jump out where they can't
see me, then you can make a run for it."
I nodded. So far, we had all the room we needed. No sign of alarm or
pursuit. I wondered if maybe this kind of thing hap pened all the time
in Vegas-cars full of late-arriving passengers screeching desperately
across the runway, dropping off wild-eyed Samoans clutching mysterious
canvas bags who would sprint onto planes at the last possible second
and then roar off into the sunrise.
Maybe so, I thought. Maybe this kind of thing is standard procedure in
this town
I swung in behind the van and hit the brakes just long enough for
my attorney to jump out. "Don't take any guff from these swine,"
I yelled. "Remember, if you have any trouble you can always send a
telegram to the Right People."
He grinned. "Yeah . . . Explaining my Position," he said. "Some asshole
wrote a poem about that once. It's probably good advice, if you have
shit for brains." He waved me off.
"Right," I said, moving out. I'd already spotted a break in the
big hurricane fence-and now, with the Whale in low gear, I went for
it. Nobody seemed to be chasing me. I couldn't understand it. I glanced
in the mirror and saw my attorney climbing into the plane, no sign of
a struggle . . . and then I was through the gate and out into the early
morning traffic on Paradise Road.
 
I took a fast right on Russell, then a left onto Maryland Parkway
. . . and suddenly I was cruising in warm anonym ity past the campus of
the University of Las Vegas . . . no tension on these faces; I stopped
at a red light and got lost, for a moment, in a sunburst of flesh in the
cross-walk: fine sinewy thighs, pink mini-skirts, ripe young nipples,
sleeveless blouses, long sweeps of blonde hair, pink lips and blue eyes-
all the hallmarks of a dangerously innocent culture.
I was tempted to pull over and start mumbling obscene en treaties:
"Hey, Sweetie, let's you and me get weird. Jump into this hotdog Caddy
and we'll flash over to my suite at the Flamingo, load up on ether and
behave like wild animals in my private, kidney-shaped pool .."
Sure we will, I thought. But by this time I was far down the parkway,
easing into the turn lane for a left at Flamingo Road. Back to the
hotel, to take stock. There was every reason to believe I was heading
for trouble, that I'd pushed my luck a bit far. I'd abused every rule
Vegas lived by-burning locals, abusing the tourists, terrifying the help.
The only hope now, I felt, was the possibility that we'd gone to such
excess, with our gig, that nobody in a position to bring the hammer down
on us could possibly believe it. Particularily not since we'd signed
in with the Police Conference. When you bring an act into this town,
you want to bring it in heavy. Don't waste any time with cheap shucks
and misde minors. Go straight for the jugular. Get right into felonies.
The mentality of Las Vegas is so grossly atavistic that a really massive
crime often slips by unrecognized. One of my neighbors recently spent
a week in the Vegas jail for "vagrancy." He's about twenty years old:
Long hair, Levi jacket, napsack - an out-front drifter, a straight
Road Person. Totally harmless; he just wanders around the country
looking whatever it was that we all thought we'd nailed down in in the
Sixties-sort of an early Bob Zimmerman trip.
On a trip from Chicago to L.A., he got curious about Vegas and decided to
have a look at it. Just passing through, strolling and digging the sights
on the Strip . . . no hurry, why rush? He was standing on a street-corner
near the Circus Circus, watching the multi-colored fountain, when the
cop-cruiser pulled up.
Wham. Straight to jail. No phone call, no lawyer, no charge. "They put
me in the car and took me down to the station." he said. "They took me
into a big room full of people to take off all my clothes before they
booked me. I was standing in front of a big desk, about six feet tall,
with a cop sitting behind it and looking down at me like some kind of
medieval judge.
"The room was full of people. Maybe a dozen prisoners; twice that many
cops, and about ten policewomen. You had to walk out in the middle of
the room, then take everything out of your pockets and put it up on the
desk and then strip naked-with everybody watching you.
"I only had about twenty bucks, and the fine for vagrancy was twenty-five,
so they put me over on a bench with the peo ple who were going to
jail. Nobody hassled me. It was like an assembly line.
"The two guys right behind me were longhairs. Acid people. They'd been
picked up for vagrancy, too. But when they started emptying their pockets,
the whole room freaked. Between them, they had $130,000, mostly in big
bills. The cops couldn't believe it. These guys just kept pulling out
wads of money and dumping it up there on the desk-both of them naked
and kind of hunched over, not saying anything.
 
"The cops went crazy when they saw all that money. They started whispering
to each other; shit, there was no way they could hold these guys for
'vagrancy."' He laughed. "So they charged them with 'suspicion of evasion
of income taxes.'
"They took us all to jail, and these two guys were just about nuts. They
were dealers, of course, and they had their stash back in their hotel
room-so they had to get out before the cops found out where they were
staying.
"They offered one of the guards a hundred bucks to go out and get the
best lawyer in town . . . and about twenty minutes later there he was,
yelling about habeas corpus and that kind of shit . . . hell, I tried
to talk to him myself, but this guy had a one-track mind. I told him
I could make bail and even pay him something if they'd let me call my
father in Chicago, but he was too busy hustling for these other guys.
"About two hours later he came back with a guard and said 'Let's go.' They
were out. One of the guys had told me, while they were waiting, that it
was going to cost them $30,000 . . . and I guess it did, but what the
hell? That's cheap, compared to what would have happened If they hadn't
got themselves sprung.
"They finally let me send a telegram to my old man and he wired me 125
bucks . . .but it took seven or eight days. I'm not sure how long I was
in there, because the place didn't have any windows and they fed us every
twelve hours . . . You lose track of time when you can't see the sun. 
"They had seventy-five guys in each cell-big rooms with a bowl out in
the middle. They gave you a pallet when came in, and you slept wherever
you wanted. The guy next to me had been in there for thirty years,
for robbing a gas station.
"When I finally got out, the cop on the desk took another twenty-five
bucks out of what my father sent me, on top of what I owed for the
vagrancy fine. What could I say? He just took it. Then he gave me the
other $75 and said they had a cab waiting for me outside, for the ride
to the airport . . . and when I got in the cab the driver said, 'We're
not making any stops, fella, and you'd better not move until we get to
the terminal.'
"I didn't move a goddamn muscle. He'd have shot me. I'm sure of that. I
went straight to the plane and I didn't say a word to anybody until I
knew we were out of Nevada. Man, it's one place I'll never go back to."
 
11. Fraud? Larcent? Rape? . . . A Brutal Connection with the Alice from
Room Service
I was brooding on this tale as I eased the White Whale into Flamingo
parking lot. Fifty
bucks and a week in jail for standing on a corner and acting curious
. . . Jesus, what kind of incredible penalties would they spew out on
me? I eked off the various charges-but in skeleton, legal-lan re form
they didn't seem so bad:
Rape? We could surely beat that one. I'd never even coveted the goddamn
girl, much
less put my hands on her flesh. Fraud? Larceny? I could always offer to
"settle." Pay
it off. Say I was sent out here by Sports Illustrated and then drag the
Time. Inc. lawyers
into a nightmare lawsuit. Tie them up for years with a blizzard of writs
and appeals.
Attach all their assets in places like Juneau and Houston, then constantly
file for change
of venue to Quito, Nome and Aruba . . . keep the thing moving, run them
in circles,
force them into conflict with the accounting department:
 
TIME SHEET FOR ABNER H. DODGE,
 
CHIEF COUNSEL
Item $44,066.12. . . Special outlay, to wit: We pursued the defendant,
R. Duke, throughtout the Western Hemosphere and finally brought him to
bay in a village on the north shore of an island known as Culebra in
the Caribbean, where his attorney obtained a ruliong that all further
proceedings should be conducted in the language of the Carib tribe. We
sent three men to Berlitz for this purpose, but nineteen hours before
the date scheduled for opening arguments, the defendant fled to Colombia,
where he established residence in a fishing village called Guajira near
the Venezuelan border, where the official language of jurisprudence is
an obscure dialect known as "Guajiro." After many monthe we were able to
establish 3urls- diction in this place, but by that time the defendant had
moved his residence to a virtually inaccessible port at the headwaters of
the Amazon River, where he cultivated powerful connec tions with a tribe
of headhunters called '"Jibaros." Our stringer in Manaus was dispatched
upriver, to locate and hire a native attorney conversant in Jibaro, but
the search has been hampered by serious communications problems. There
is in fact grave concern, in our Rio office, that the widow of the
aforementioned Manaus stringer might obtain a ruinous judgment-due to
bias in local courts-far larger than any thing a jury in our own country
would consider reasonable or even sane.
Indeed. But what is sane? Especially here in "our own country"-in this
doomstruck era of Nixon. We are all wired into a survival trip now. No
more of the speed that fueled the Sixties. Uppers are going out of
style. This was the fatal flaw in Tim Leary's trip. He crashed around
America selling "con sciousness expansion" without ever giving a thought
to the grim meat-hook realities that were lying in wait for all the
people who took him too seriously. After West Point and the Priesthood,
LSD must have seemed entirely logical to him . . . but there is not
much satisfaction in knowing that he blew it very badiy for himself,
because he took too many oth ers down with him.
Not that they didn't deserve it: No doubt they all Got What Was Coming
To Them. All those pathetically eager acid freaks who thought they could
buy Peace and Understanding fot three bucks a hit. But their failure is
ours, too.
 
What Leary took down with him was the central illusion of a whole
life-style that he helped to create . . . a generation of permanent
cripples, failed seekers, who never understood the essential old-mystic
fallacy of the Acid Culture: the desperate assumption that somebody-or
at least some force-is tending that Light at the end of the tunnel.
 
 
This is the same cruel and paradoxically benevolent bullshit has kept
the Catholic
Church going for so many centuries. It is also the military ethic . . . a
blind faith in
some higher and wiser "authority." The Pope, The General, The Prime
Minister . . . all the
way up to "God."
One of the crucial moments of the Sixties came on that day when the
Beatles cast their lot with the Maharishi. It was like Dylan going to
the Vatican to kiss the Pope's ring.
First "gurus." Then, when that didn't work, back to Jesus. And now,
following Manson's primitive/instinct lead, a whole new wave of clan-type
commune Gods like Mel Lyman, ruler Avatar, and What's His Name who runs
"Spirit and Flesh."
Barger never quite got the hang of it, but he'll never iw how close
he was to a king-hell breakthrough. The An- blew it in 1965, at the
Oakland-Berkeley line, when they acted on Barger's hardhat, con-boss
instincts and attacked the front ranks of an anti-war march. This proved
to be an historic schism in the then Rising Tide of the Youth Movement
of the Sixties. It was the first open break between the Greasers and the
Longhairs, and the importance of that break can be read in the history
of SDS, which eventually destroyed in the doomed effort to reconcile the
interests of the 'working class biker/dropout types and the upper/mid
Berkeley/student activists.
Nobody involved in that scene, at the time, could possibly have foreseen
the Implications of the Ginsberg/Kesey failure to pursuade the Hell's
Angels to join forces with the radical Left from Berkeley. The final
split came at Altamont, four years later, but by that time it had long
been clear to everybody except a handful of rock industry dopers and the
national press. The orgy of violence at Altamont merey dramatized the
problem. The realities were already fixed; the illness was understood to
be terminal, and the energies of The Movement were long since aggressively
dissipated by the rush to self-preservation.
Ah; this terrible gibberish. Grim memories and bad flash backs, looming
up through the time/fog of Stanyan Street . . . no solace for refugees,
no point in looking back. The question, as always, is now . . .?
I was slumped on my bed in the Flamingo, feeling dangerously out of phase
with my surroundings. Something ugly was about to happen. I was sure of
it. The room looked like the site of some disastrous zoological experiment
involving whiskey and gorillas. The ten-foot mirror was shattered, but
still hanging together - bad evidence of that afternoon when my attorney
ran amok with the coconut hammer, smashing mirror and all the lightbulbs.
We'd replaced the lights with a package of red and blue Christmas tree
lights from Safeway, but there was no hope of saving the mirror. My
attorney's bed looked like a burned- rat's nest. Fire had consumed the top
half, and the rest a mass of wire and charred stuffing. Luckily, the maids
had'nt come near the room since that awful confrontation on Tuesday.
I been asleep when the maid came in that morning. We'd forgotten to
hang out the "Do Not Disturb" sign . . . so she wandered into the room
and startled my attorney, who kneeling, stark naked, in the closet,
vomiting into his shoes . . . thinking he was actually in the bathroom,
and then suddenly looking up to see a woman with a face like Mickey Rooney
staring down at him, unable to speak, trembling with fear and confusion.
She was holding that mop like an axe-handle," he said "So I came out of
the closet in a kind of running crouch, vomiting, and hit her right at
the knees . . . it was pure instinct; I thought she was ready to kill me
. . . and then, she screamed, that's when I put the icebag on her mouth."
I remembered that scream . . . one of the most terrifiying sounds I'd ever
heard. I woke up and saw my attorney grappling desperately on the floor
right next to my bed with what appeared to be an old woman. The room was
full of electric noise. The TV set, hissing at top volume on a nonexistent
channel. I could barely hear the woman's cries as she struggled to get the
icebag away from her face . . . but she was no match for my attorney's
naked bulk, and he finally managed to pin her in a corner behind the TV
set, clamping his hands on her throat while she babbled I . . . "Please
. . . please . . . I'm only the maid, I did'nt mean anything..."
I was out of bed in a flash, grabbing my wallet and waving the gold
Policemen's Benevolent Assn. press badge in front of her face."You're
under arrest!" I shouted.
 
"No!" she groaned. "I just wanted to clean up!"
My attorney got to his feet, breathing heavily. "She must have used a
pass key," he said. "I was polishing my shoes in the closet when I noticed
her sneaking in-so I took her." He was trembling, drooling vomit off his
chin, and I could see at a glance that he understood the gravity of this
situation. Our behavior, this time, had gone far past the boundaries of
private kinkiness. Here we were, both naked, staring down at a terrified
old woman - a hotel employee - stretched out on the floor of our suite
in a paroxysm of fear and hysteria. She would have to be dealt with.
"What made you do it?" I asked her. "Who paid you off?"
"Nobody!" she wailed. "I'm the maid!"
"You're lying!" shouted my attorney. "You were after the evidence! Who
put youup to this - the manager?"
"I work for the hotel," she said. "All I do is clean up the rooms."
I turned to my attorney. "This means they know what we have," I said. "So
they sent this poor old woman up here to steal it."
"No!" she yelled. "I don't know what you're talking about!"
"Bullshit!" said my attorney. "You're just as much a part of it as they
are."
"Part of what?"
"The dope ring," I said. "You must know what's going on in this hotel. Why
do you think we're here?"
She stared at us, trying to speak but only blubbering. "I know you're
cops," she said finally. "But I thought you were just here for that
convention. I swear! All I wanted to do was clean up your room. I don't
know anything about dope!"
My attorsey laughed. "Come on, baby. Don't try to tell us you never
heard of the Grange Gorman."
"No!" she yelled. "No! I swear to Jesus I never heard of that stuff!"
My attorney seemed to think for a moment, then he leaned to help the old
lady to her feet. "Maybe she's telling the he said to me. "Maybe she's
not part of it."
"No! I swear I'm not!" she howled.
"Well .. ." I said. "In that case, maybe we won't have to put her away
. . . maybe she can
help."
"Yes!" she said eagerly. "I'll help you all you need! I hate dope!"
"So do we, lady," I said.
"I think we should put her on the payroll," said my attorney. "Have her
checked out,
then line her up for a Big One each month, depending on what she comes
up with." 
The old woman's face had changed markedly. She no longer seemed disturbed
to find
herself chatting with two naked men, one of whom had tried to strangle
her just a few
moments earlier.
"Do you think you could handle it?" I asked her.
"What?"
"One phone call every day," said my attorney. "Just tell us what you've
seen." He patted her on the shoulder. "Don't worry if it doesn't add
up. That's our problem."
She grinned. "You'd pay me for that?"
"You're damn right," I said. "But the first time you say anything about
this, to anybody - you'll go straight to prison for the rest of your
life."
She nodded. "I'll help any way that I can," she said. "But who should
I call?"
"Don't worry," said my attorney. "What's your name?" 
"Alice." she said. "Just ring Linen Service and ask for Alice."
"You'll be contacted," I said. "It'll take about a week. But keep your
eyes open and try to act normal. Can you do that?"
"Oh, yes sir!" she said. "Will I see you gentlemen again?" She grinned
sheepishly. "After this, I mean..
"No," said my attorney. "They sent us down from Carson City. You'll be
contacted by Inspector Rock. Arthur Rock. He'll be posing as a politician,
but you won't have any trouble recognizing him."
She seemed to be shuffling nervously.
"What's wrong?" I said. "Is there something you haven't told us?"
"Oh no!" she said quickly. "I was just wondering - who's going to pay
me?"
"Inspector Rock will take care of that," I said. "It'll all be in cash:
a thousand dollars on the ninth of every month."
"Oh Lord!" she exclaimed. "I'd do just about anything for that!"
"You and a lot of other people," said my attorney. "You'd be surprised
who we have on the payroll - right here in this same hotel."
She looked stricken. "Would I know them?"
"Probably," I said. "But they're all undercover. The only way you'll
ever know is if something really serious happens and one of them has to
contact you in public, with the pass word."
"What is it?" she asked.
"'One Hand Washes the Other,"' I said. "The minute you hear that, you say:
'I fear nothing.' That way, they'll know you."
She nodded. repeating the code several times, while we listened tomake
sure she had it right. 
"OK," said my attorney. "That's it for now. We probably won;t be seeing
you again until the hammer comes down. You'll be better off ignoring us
until we leave. Don't bother to make up the room. Just elave a pile of
towels and soap outside the door, exactly at modnight." He smiled. "That
way, we won;t have to risk another one of these little incidents, will
we?"
She moved towards the door. "Whatever you say gentlemen. I can;t tell
you how sorry I am about what happened . . . but it was only because I
didn't realize."
My attorney ushered her out. "We understand," he said "But it's all over
now. Thank God for the decent people."
She smiled as she closed the door behind her.
 
She nodded, repeating the code several times, while we lis tened to make
sure she
had it right.
 
"OK," said my attorney. "That's it for Dow. We probably won't be seeing
you
again until the hammer comes down. You'll be better off ignoring us
until we
leave. Don't bother to make up the room. Just leave a pile of towels
and soap
outside the door, exactly at midnight." lie smiled. "That way, we won't
have to risk another one of theep little incidents, will we?"
 
12. Return to the Circus - Circus . . . Looking for the Ape . . . to
Hell with the American Dream
Almost seventy-two hours had passed since that strange encounter, and no
maid had set foot in the room. I wondered what Alice had told them. We
had seen her once, trundling a laundry cart across the parking area as
we rolled up in the Whale but we offered no sign of recognition and she
seemed understand.
But it couldn't last much longer. The room was full of used towels;
they were hanging everywhere. The bathroom floor was about six inches
deep with soap bars, vomit, and grape fruit rinds, mixed with broken
glass. I had to put my boots on every I went in there to piss. The nap of
the mottled grey rug was so thick with marijuana seeds that it appeared
to be turning green.
The general back-alley ambience of the suite was so rotten, so incredibly
foul, that I figured I could probably get away with claiming it was some
kind of "Life-slice exhibit" that we'd brought down from Haight Street,
to show cops from other parts of the country how deep into filth and
degeneracy the drug people will sink, if left to their own devices.
But what kind of addict would need all these coconut husks and crushed
honeydew rinds? Would the presence of junkies account for all these
uneaten french fries? These puddles of glazed catsup on the bureau?
Maybe so. But then why all this booze? and these crude pornographic
photos, ripped out of pulp magazines like Whores of Sweden and Orgies
in the Casbah, that were plastered on the broken mirror with smears of
mustard that had dried to a hard yellow crust . . . and all these signs
of violence, these strange red and blue bulbs and shards of broken glass
embedded in the wall plaster . . .
No, these were not the hoofprints of your normal, godfearing junkie. It
was far too aggressive. There was evidence, in this room, of excessive
consumption of almost every type of drug known to civilized man since
1544 A.D. It could only be explained as a montage, a sort of exaggerated
medical exhibit, put together very carefully to show what might happen
if twenty-two serious drug felons - each with a different addiction -
were penned up together in the same room for five days and nights,
without relief.
Indeed. But of course that would never happen in Real Life, gentlemen. We
just put this thing together for demonstration purposes . . . 
Suddenly the phone was ringing, jerking me out of my fantasy stupor. I
looked at it. Riiiinnnnnggggggg . . . Jesus, what now? Is this it? I
could almost hear the shrill voice of the Manager, Mr. Heem, saying
the police were on their way up to my room and would I please not shoot
through the door when they began kicking it down.
Riinnnngggg . . . No, they wouldn't call first. Once they decided to
take me, they would probably set an ambush in the elevator: first Mace,
then a gang-swarm. It would come with no warning.
So I picked up the phone. It was my friend Bruce Innes, calling from
the Circus-Circus. He had located the man who wanted to sell the ape
I'd been inquiring about. The price was $750.
"What kind of a greedhead are we dealing with here?" I said. "Last night
it was four hundred."
"He claims he just found out it was housebroken," said Bruce. "He let
it sleep in the trailer last noght, and the thing actually shiot in the
shower stall."
"That doesn't mean anything," I said. "Apes are attracted to water. Next
time it'll shit in the sink."
"Maybe you should come down and argue with the guy," said Bruce. "He's
here in the bar with me. I told him you really wanted the ape and that
you could give it a fine home. I think he'll negotiate. He's really
attached to the stinking thing. It's here in the bar with us, sitting
up on a goddamn stool, slobbering into a beer schooner."
"Okay," I said. "I'll be there in ten minutes. Don't let the bastard
get drunk. I want to meet him under natural conditions."
 
When I got to the Circus-Circus they were loading an old man into an
ambulance outside the main door. "What happened?" I asked the car-keeper.
"I'm not sure," he said. "Somebody said he had a stroke. But I noticed
the back of his head was all cut up." He slid into the Whale and handed
me a stub. "You want me to save your drink for you?" he asked, holding
up a big glass of tequila that was on the seat of the car. "I can put
it in the cooler if want."
I nodded. These people were familiar with my habits. I had been in and
out of the place so often, with Bruce and the and members, that the
car-keepers knew me by name - although I'd never introduced myself,
and nobody had ever asked me. I just assumed it was all part of the gig
here; that that they'd probably rifled the glove compartment and found
a notebook with my name on it.
The real reason, which didn't occur to me at the time, was that I was
still wearing my ID/badge from the District Attorney's Conference. It was
dangling from the pocket-flap of my multi-colored bird-shooting jacket,
but I'd long since forgotten about it. No doubt they all assumed I was
some kind of super wierd undercover agent . . . or maybe not; maybe they
were just humoring me because they figured anybody crazy enough to pose
as a cop while driving around Vegas in a white Cadillac convertible with
a drink in his hand almost had to be Heavy, and perhaps even dangerous. In
a scene where, nobody with any ambition is really what he appears to be,'
there's not much risk in acting like a king-hell freak. The, overseers
will nod wisely at each other and mutter about "these goddamn no-class
put-ons."
The other side of that coin is the "Goddamn! Who's that?" syndrome. This
comes from people like doormen and floor- walkers who assume that anybody
who acts crazy, but still tips big, must be important-which means he
should be hu mored, or at least treated gently.
But none of this makes any difference with a head full of mescaline. You
justblunder around, doing anything that seems to be right, and it
usually is. Vegas is so full of natural freaks-people who are genuinely
twisted-that drugs aren't really a problem, except for cops and the
scag syndicate. Psychedelics are almost irrelevant in a town where you
can wan der into a casino any time of the day or night and witness the
crucifixion of a gorilla-on a flaming neon cross that suddenly turns
into a pinwheel, spinning the beast around in wild cir cles above the
crowded gambling action.
 
I found Bruce at the bar, but there was no sign of the ape. "Where is
it?" I demanded. "I'm ready to write a check. I want to take the bastard
back home on the plane with me. I've already reserved two first-class
seats - R. Duke and Son."
"Take him on the plane?"
"Hell yes," I said. "You think they'd say anything? Call at tention to
my son's infirmities?"
He shrugged. "Forget it," he said. "They just took him away. He attacked
an old man right here at the bar. The creep started hassling the bartender
about 'allowing barefoot rabble in the place' and just about then the
ape let out a shriek-so the loud the guy threw a beer at him, and the
ape went crazy, came out of his seat like a jack-in-the box and took a
big bite out of the old man's head . . . the bartender had to call an
ambulance, then the cops came and took the ape away."
"Goddamnit," I said. "What's the bail? I want that ape."
"Get a grip on yourself," he said. "You better stay clear of that
jail. That's all they need to put the cuffs on you. Forget that ape. You
don't need him."
I gave it some thought, then decided he was probably right. There was
no sense blowing everything just for the sake of some violent ape I'd
never met. For all I knew, hed take a bite out of my head if I tried to
bail him out. It would take him a while to calm down, after the shock
of being put behind bars, and I couldnt afford to wait around. 
"When are you taking off?" Bruce asked.
"As soon as possible," I said. No point hanging around this town any
lobger. IU have all I need. Anything else would only confuse me."
He seemed suprised. "You found the American Dream?" he said. "In this
town?"
I nodded. "We're sitting on the main nerve rightnow," I said. "You
remember that story the manager told us about the owner of this place? How
he always wanted to run away and join the circus when he was a kid?"
Bruce ordered two more beers. He looked over the casino for a moment,
then shrugged. "Yeah, I see what you mean," he said. "Now the bastard has
his own circus, and a license to steal, too." He nodded. "You're right -
he's the model."
"Absolutely," I said. "It's pure Horatio Alger, all the way down to
his attitude. I tried to tell the woman that I agreed with everything
he stood for, but she said if I knew what was good for me I'd get the
hell out of town and not even think about bothering the Boss. "He really
hates reporters" she said. "I don't mean this to sound like a warning,
bit if I were you I'd take it that way . . . ""
Bruce nodded. The Boss was paying him a thousand bucks a week to work
two sets a night in the Leopard Lounge, andanother two grand for the
group. All they had to do was make a hell of a lot of noise for two hours
every night. The Boss didn't give a flying fuck what kind of songs they
sang, just as long as the beat was heavy and the amps were turned up
loud enough to lure people into the bar.
It was strange to sit there in Vegas and hear Bruce singing powerful
stuff like "Chicago" and "Country Song." If the management had bothered
to hear the lyrics, the whole band would have been tarred and feathered.
Several months later, in Aspen, Bruce sang the same songs in a club
jammed with tourists and a former Astronaut* and when the last set was
over, ___ came over to our table and began yelling all kinds of drunken,
super-patriot gibber ish, hitting on Bruce about "What kind of nerve
does a god damn Canadian have to come down here and insult this country?"
"Say man," I said. "I'm an Amei-ican. I live here, and I agree with
every fucking word he says."
At this point the hash-bouncers appeared, grinning inscrutably and saying:
"Good evening to you gentlemen. The I Ching says it's time to be quiet,
right? And nobody hassles the musicians in this place, is that clear?"
The Astronaut left, muttering darkly about using his in fluence to "get
something done, damn quick," about the Immigration Statutes. "What's
your name?" he asked me, as the hash-bouncers eased him away.
"Bob Zimmerman," I said. "And if there's one thing I hate in this world,
it's a goddamn bonehead Polack."
"You think I'm a Polack?" he screamed. "You dirty gold bricker! You're
all shit! You don't represent this country."
"Christ, let's hope to hell you don't." Bruce Mmuttered. ____ was still
raving as they muscled him out to the street.
T^he nest noght, in another restaurant, the Astronaut was scarfing his
chow - stone soer - when a fourteen year old boy approached the table
to ask for an autograph. ____ acted coy moment, feigning embarrassment,
then he scrawled his signature on the small piece of paper the boy handed
him. The boy looked at it for a moment, then tore it into small pieces and
dropped it in -____'s lap. "Not everybody loves you, man." he said. Then
he went back and sat down at his own table about six feet away.
The Astronaut's party was speechiess. Eight or ten people - wives,
managers and favored senior engineers, showing a good time in fabulous
Aspen. Now they looked like somebody had just sprayed their table with
shit-mist. Nobody a word. They ate quickly, and left without tipping.
So much for Aspen and astronauts. _____ would never have kind of trouble
in LasVegas.
A little bit of this town goes a very long way. After five in Vegas you
feel like you've been here for five years. Some people say they like
it - but then some people like Nixon, too. He would have made a perfect
Mayor for this town; with John Mitchell as Sheriff and Agnew as Master
of Sewers.
 
13. End of the Road . . .Death of the Whale . . . Soaking Sweats in the
Airport.
 
When I tried to sit down at the baccarat table the bouncers the arm
on me. "You don't belong here," one of them said quietly. "Let's go
outside."
"Why not?" I said.
They took me out to the front entrance and signaled for the Whale to be
brought up.
"Where's your friend?" they asked, while we waited.
'What friend?"
'The big spic."
"Look," I said. "I'm a Doctor of Journalism. You'd never me hanging
around this place with a goddamn spic."
They. laughed. "Then what about this?" they said. And they confronted me
with a big photograph of me and my attorney at a table in the floating
bar.
I srugged. "That's not me," I said. "That's a guy named Thompson. He works
for Rolling Stone . . . a really vicious, crazy kind of person. And that
guy sitting next to him is a hit man for the Mafia in Hollywood. Shit,
have you studied this photograph? What kind of a maniac would roam around
wearing one black glove."
"We noticed that." They said. "Where is he now?"
I shrugged. "He moves around pretty fast. " I said. His oerders come
out of St. Loius."
They stared at me. "How do you know all this stuff?"
I showed them my gold PBA badge, flashing it quickly with my back to
the crowd. "Act natural," I whispered. "Don't put me on the spot."
They were still standing there when I drove off in the Whale. The geek
had brought it up at exactly the right moment. I gave him a five-dollar
bill and hit the street with a stylish screech of rubber.
It was all ovet now. I drove across to the Flamingo and loaded all
my luggage into the car. I tried to put the top up, for privacy, but
something was wrong with the motor. The generator light had been on, fiery
red, ever since I'd driven the thing into Lake Mead on a water test. A
quick run along the dashboard disclosed that every circuit in the car
was to tally fucked. Nothing worked. Not even the headlights-and when I
hit the air conditioner button I heard a nasty explosion under the hood.
The top was jammed about halfway up, but I decided to try for the
airport. If this goddamn junker wouldn't run right, I could always abandon
it and call a cab. To hell with this gar bage from Detroit. They shouldn't
be allowed to get away with it.
The sun was coming up when I got to the airport. I left the Whale in
the VIP parking lot. A kid about fifteen years old checked it in, but I
refused to answer his questions. He was very excited about the overall
condition of the vehicle. "Holy God!" he kept shouting. "How did this
happen?" He kept moving around the car, pointing at various dents,
rips and crushed places.
"I know," I said. "They beat the shit out of it. This is a ter rible
goddamn town for driving around in convertibles. The worst time was
right out on the Boulevard in front of the Sahara. You know that corner
where all the junkies hang out? Jesus, I couldn't believe it when they
all went crazy at once."
The kid was none too bright. His face had gone blank early on, and now
heseemed in a state of mute fear.
"Don't worry," I said. "I'm insured." I showed him the contract, pointin
to the small-print clause where it said I was insured against ALL damages,
for only two dollars a day.
The kid was still nodding when I fled. I felt a bit guilty about leaving
him to deal with the car. There was no way explain the massive damage. It
was finished, a wreck, totaled out. Under normal circumstances I would
have been seized and arrested when l tried to turn it in . . . but not
at this of the morning, with only this kid to deal with. I was, all, a
"VIP." Otherwise, they would never have chartered the car to me in the
first place . . . ..
Let the chickens come home to roost, I thought as I hurried into the
airport. It was still too early to act normal, so I hunkered down in
the coffee shop behind the LA. Times. Some where down the corridor a
jukebox was playing "One Toke Over the Line." I listened for a moment,
but my nerve ends no longer receptive. The only song I might have been
to relate to, at that point, was "Mister Tambourine ." Or maybe "Memphis
Blues Again . . . 
"Aww, mama.. . can this really. . . be the end . . . ?"
My plane left at eight, which meant I had two hours to kill. Feeling
desperately visible. There was no doubt in my mind they were looking
for me; the net was closing down . . . only a matter of time before they
ran me down like some kind of rabid animal.
I checked all my luggage through the chute. All but the satchel,
which was full of drugs. And the .357. Did they have the goddamn metal
detector system in this airport? I strolled around to the boarding gate
and tried to look casual while I cased the area for black boxes. None
were visible. I to take the chance-just zip through the gate with a
big smile on my face, mumbling distractedly about "a bad slump in the
hardware market. ..
Just another failed salesman checking out. Blame it all on that bastard
Nixon. Indeed. I decided it might look more natural if I found somebody
to chat with-a routine line of small talk, between passengers:
"Hy're yew, fella! I huess you're probably wonderin' what make sme sweat
like this? Yeah! Well, god damn, man! Have you read the newspapers
today? . . . You'd never believe what those dirty bastards have doen
this time!"
I figured that would cover it . . . But I could'nt find anybody who looked
safe enough to talk to. The whole airport was full of people who looked
like they might go for my float ing rib if I made a false move. I felt
very paranoid . . . like some kind of criminal skullsucker on the lam
from Scotland Yard.
Everywhere I looked I saw Pigs . . . because on that morn ing the Las
Vegas airport was full of cops: the mass exodus after the climax of the
District Attorneys' Conference. When I finally put this together I felt
much better about the health of my own brain
 
EVERYTHING
seems to be ready.
Are you Ready?
Ready?
 
Well, why not? This is a heavy day in Vegas. A thousand cops are checking
out of town, scurrying through the airport in groups of three and
six. They are heading back home. The drug conference is finished. The
Airport Lounge is humming with mean talk and bodies. Short beers and
Bloody Marys, here and there a victim of chest rash rubbing Mexsana
under the armpit straps of a thick shoulder holster. No point hiding this
business any longer. Let it all hang out . . . or at least get some air
to it.
Yes, thank you kindly. . I think I busted a button on my trousers. I
hope they don't fall down. You don't want my trousers to fall down now,
do you?
Fuck no. Not today. N ot right here in the middle of the Las Vegas
airport, on this sweaty -hard morning at the tail end of this mass
meeting on the Narcotics and Dangerous Drugs.
"When the train . . . come in the station . . . I looked her in the
eye. . . "
Grim music in the airport. 
"Yes, it's hard to tell it''s hard to tell, when all your love's in
Vain..."
 
Every now and then you run up on one of those days when everythings in
vain . . . a stone bummer from start to finish; if you know what's good
for you, on days like these you sortof hunker down in a safe corner and
watch. Maybe think a bit. Lay back on a cheap wooden chair, screened off
from traffic, and shrewdly rip the poptops out of five or eight Budweisers
. . . smoke off a pack of King Marlboros, eat a nut-butter sandwich, and
finally toward evening gobble a wad of good mescaline . .. then drive out,
later on, to the beach. Get out in the surf, in the fog, and slosh along
on numb-frozen feet about ten yards out from the tideline. . . stomping
through tribes of wild sandpeckers . . . riderunners, whorehoppers,
stupid little birds and crabs and saltsuckershere and there a big pervert
or woolly reject gimp off in the distance, wandering alone by themselves
behind dunes and driftwood. . . . 
These are the ones you will never be properly introduced to - at least
not if your luck holds. But the beach is less complicated than a boiling
fast morning in the Las Vegas airport.
I felt very obvious. Amphetamine psychosis? Paranoid dementia? - What
is it? My Argentine luggage? This crippled, walk that once made me a
reject from the Naval ROTC?"
Indeed. This man will never be able to walk straight, Captain! Because
one leg is longer than the other. . . . Not much. Three eighths of an
inch or so, which counted out to about two eights more than the Captain
could tolerate.
So we parted company. He accepted a command in the South China Sea,
and I became a Doctor of Gonzo Journalism . . . andmany years later,
killing time in the Las Vegas airport this terrible morning, I picked
up a newspaper and saw where teh Captain had fucked up very badly:
Ship Commander Butchered by Natives After "Accidental" Assault on Guam.
(AOP)-Aboard the USS. Crazy Horse: Somewhere in the Pactfic (Sept. 25)-The
entire 3485-man crew of this newest American aircraft carrier is in
violent mourning today, after five crewmen including the Captain were
diced uplike pineapple meat in a brawl with the Heroin Police at the
neutral port of Hong See. Dr. Bboor, the ship's chaplain, presided
over tense funeral services at dawn on the flight deck. The 4th Fleet
Service Choir sang "Tom Thumb's Blues" . . . and then, while the ship's
bells tolled frantically, the remains of the five were set afire in a
gourd and hurled into the Pacific by a hooded officer known only as "The
Commander." Shortly after the services ended, the crewmen fell to fighting
among themselves and all communications with the ship were severed for
an indefinite period. Official spokesmen at 4th Fleet Headquarters on
Guam said the Navy had "no comment" on the situation, pending the re
sults of a top-level investigation by a team of civilian specialists
headed by former New Orleans district attor ney James Garrison.
. . . Why bother with newspapers, if this is all they offer? Agnew
was right. The press is a gang of cruel faggots. Journalism is not a
profession or a trade. It is a cheap catch-all for fuckoffs and misfits-
a false doorway to the backside of life, a filthy piss-ridden little hole
nailed off by the building inspector, but just deep enough for a wine
to curl up from the sidewalk and masturbate like a chimp in a zoo-cage.
 
14. Farewell to Vegas . . . "God's Mercy on You Swine!"
 
I skulked around the airport, I realized that I was still wearing my
police ,identification badge. It was a flat orange rectangle, sealed
in clear plastic, that said: "Raoul Duke, Spe cial Investigator, Los
Angeles." I saw it in the mirror above urinal.
Get rid of this thing, I thought. Tear it off. The gig is finished.. . and
it proved nothing. At least not to me. And certainly not to my
attorney-who also had a badge-but he was back in Malibu, nursing his
paranoid sores.
It been a waste of time, a lame fuckaround that was only - in clear
retrospect - a cheap excuse for a thousand cops to spend a few days in
Las Vegas and lay the bill on the taxpayers. Nobody had learned anything-
or at least nothing except new. Except maybe me .. . and all I learned
was that the District Attorneys' Association is about ten years behind
the grim truth and harsh kinetic realities of what they just recently
learned to call "the Drug Culture" in tyhe Year of Our lord, 1971.
They are still burning the taxpayers for thousands of dollars to make
films about "the dangers of LSD," at a time when acid is widely known
- to everybody but cops-to be the Studenbaker of the drug market, the
popularity of psychedelics has fallen off so drastically drastically that
most voluime dealers no longer even handle qualioty acid or mescaline
except as a favor to special customers: Mainly jaded, over thirty drug
dilettantes - likeme, and my attorney.
The big market, these days, is in Downers. Reds and smack -Seconal and
heroin-and a hellbroth of bad domestic grass sprayed with everything from
arsenic to horse tranquillizers. What sells, today, is whateverFucks
You Up-whatever short-circuits your brain and grounds it out for the
longest possible time. The ghetto market has mushroomed into subur
bia. The Miltown man has turned, with a vengeance, to skin- popping
and even mainlining. . . and for every ex-speed freak who drifted, for
relief, into smack, there are 200 kids who went straight to the needle
off Seconal. They never even bothered to try speed.
Uppers are no longer stylish. Methedrine is almost as rare, on the 1971
market, as pure acid or DMT. "Consciousness Ex pansion" went out with
LBJ . . and it is worth noting, historically, that downers came in with
Nixon.
 
I limped onto the plane with no problem except a wave of ugly vibrations
from the other passengers . . . but my head was so burned out, by then,
that I wouldn't have cared if I'd had to climb aboard stark naked and
covered with oozing chancres. It would have taken extreme physical force
to keep me off that plane. I was so far beyond simple fatigue that I was
beginning to feel nicely adjusted to the idea of perma nent hysteria. I
felt like the slightest misunderstanding with the stewardess would cause
me to either cry or go mad . . . and the woman seemed to sense this,
because she treated me very gently.
When I wanted more Ice Cubes for my Bloody Mary, she brought them quickly
. . and when I ran out of cigarettes, she gave me a pack from her own
purse. The only time she seemed nervous was when I pulled a grapefruita
grapefruit out of my satchel and began slicing it up with a hunting
knife. I noticed her watching me closely, so I tried to smile. "I never
go anywhere without grapefruit,' "It's hard to get a really good one -
unless you're rich."
She nodded.
I flashed her the grimace/smile again, but it was hard to know what she
was thinking. It was entirely possible, I knew, that sge'd already decided
to have me taken off the plane iin a cage when we got to Denver. I stared
fixedly into her eyes for a time, but she kept herself under control. 
 
I was asleep when our plane hit the runway, but the jolt brought me
instantly awake. I looked out the window and saw the Rocky Mountains. What
the fuck was I doing here?I wondered. I t made so sense at all. I decided
to call my attorney as soon as possible. Have him iwre me some money
to buy a huge albino Doberman. Denver is a national clearinghouse for
stolen Dobermans; they come from all parts of the country.
Since i was already here, I though I might as well pick up a vicious
do. But first, something for my nerves. Immediately after the plane
landed I rushed up the corridor to the airport drugstore adn asked the
clerk for a box of amyls.
She began to fidget and shake her head. "Oh, no," she said finally. "I
can't sell you those things except by precription."
"I know," I said. "But you see, I'm a doctor. I don't need a
precription."
She was still fidgeting. "Well. . . you'll have to show me some I.D.,"
she moaned.
"Of course." I jerked out my wallet and let her see the police basge while
I flipped through the deck until I located my Ecclesiastical Discount
Card - which identifies me as a Doctor of Divinity, a certified Minister
of the Church of the New Truth.
She inspected it carefully, then handed it back. I sensed a new respect
in her manner. Her eyes grew warm. She seemed to want to touch me. "I
hope you'll forgive me, Doctor." she said with a fine smile. "But I had
to ask. We get some real freaks in this place. All kinds of dangerous
addicts. You'd never believe it."
"Don't worry," I said. "I understand perfectly. but I have a bad heart,
and I hope - "
"Certainly!" she exclaimed-and within seconds she was back with a dosen
amyls. I paid without quibbling about the ecclesiastical discount. Then
I opened the box and cracked one under my nose immediately, while she
watched.
"Just be thankful your heart is young and strong," I said. "If I were
you I would never . . . ah . . . holy shit! . . . what? Yes, you'll have
to excuse me now; I feel it coming on." I turned away and reeled off in
the general direction of the bar.
"God's mercy on you swine!" I shouted at two Marines com ing out of the
men's room.
They looked at me, but said nothing. By this time I was laughing
crazily. But it made no difference. I was just an other fucked-up cleric
with a bad heart. Shit, they'll love me down at the Brown Palace. I took
another big hit off the amyl, and by the time I got to the bar my heart
was full of joy. I felt like a monster reincarnation of Horatio Alger
. . . a Man on the Move, and just sick enough to be totally confident.
 
---

